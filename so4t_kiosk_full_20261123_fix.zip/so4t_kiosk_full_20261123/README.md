# 소4트 키오스크 전체 패키지 (2026-11-23)

1. **먼저 `KIOSK_FULL_SPEC.md`를 읽으세요** — 키오스크·아두이노·ESP32·파이·네트워크·현장 환경·알려진 버그·Cursor 프롬프트가 다 있습니다.
2. 노트북에서 켜기: `kiosk/` 폴더에서 `python -m pip install -r requirements.txt` → `.\start_kiosk_sim.ps1` → Chrome에서 `http://127.0.0.1:8000/kiosk.html`
   - 화면 한 번 터치 → 안내 끝나면 F(=큰 버튼, 주문 시작) / T(글자 주문) / U(모의 결제 승인)
3. Cursor: `KIOSK_FULL_SPEC.md` 14.3의 프롬프트를 그대로 붙여넣기 (버그 1·2가 최우선).
4. 비밀번호/PIN/API 키는 전부 `<HOTSPOT_PASSWORD>` 같은 자리표시자입니다. 채우는 곳은 SPEC 12장. 실제 값은 Cursor 채팅에 넣지 마세요.
5. 학습 Whisper 모델은 용량 때문에 빠져 있음 → `kiosk/models/README_모델넣기.txt`.

6. **11/23 고침 설치(파이)**: `pi_setup/README_setup_pi_1123.txt` — `bash ~/so4t_kiosk_full_20261123/pi_setup/setup_pi_1123.sh` 한 번(핫스팟 비밀번호는 실행 중 입력). 보드는 `pi_setup/esp32_hotspot_1117/README_esp32_hotspot.txt` [1].

폴더: kiosk/ (파이 ~/kiosk_project 최신 통합본) · arduino/ (Mega v8.5) · esp32/ (직원 호출 벨) · pi_setup/ (네트워크·ESP32 중계·11/17 수정) · sim_tools/ (헤드리스 시뮬레이터)
