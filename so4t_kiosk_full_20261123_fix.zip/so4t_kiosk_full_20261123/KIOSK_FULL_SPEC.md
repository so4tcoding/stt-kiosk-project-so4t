# 소4트 배리어프리 음성인식 키오스크 — 전체 사양서 (KIOSK_FULL_SPEC)

- 작성일: 2026-11-23 (KST)
- 목적: 이 zip 하나만 Cursor AI에 넣고 **시뮬레이션 + 버그 원인 찾기**를 돌릴 수 있게, 키오스크·아두이노·ESP32·라즈베리파이·네트워크·현장 환경을 한 곳에 정리.
- 근거 원칙: 모든 내용은 **zip 안의 코드/파일** 또는 팀 작업 기록(메모)에 근거함. 확인 못 한 것은 **`미확인`**이라고 적음. 숫자를 지어내지 않음.
- 줄 번호(`kiosk.html:12345`)는 이 zip 안의 `kiosk/kiosk.html`(39,516줄) 기준. 파일이 바뀌면 함수 이름으로 다시 찾을 것.
- 비밀값(와이파이 비번, 관리자 PIN, API 키)은 **전부 자리표시자**로 바꿔 둠 → 「12. 비밀값 채우는 곳」 참고.

---

## 0. 한눈에 보기

| 부품 | 무엇 | 위치(zip 안) |
|---|---|---|
| 라즈베리파이 4 (8GB) + 터치화면(PIPAD LITE, DSI-1) | 키오스크 본체. STT 서버 + 크롬 키오스크 화면 | `kiosk/`, `pi_setup/` |
| Jabra Speak2 55 (USB) | 마이크 + 스피커 일체형 (TTS도 여기서 나옴) | — |
| 아두이노 Mega 2560 (CH341 USB, `/dev/ttyUSB0`) | 큰 아케이드 버튼 + 버튼 LED. 버튼 = **주문 시작**, 2초 길게 = 직원 호출 | `arduino/kiosk_button_led/` |
| ESP32-S3 (AA건전지 4개) | **박스 밖에 두는 직원 호출 벨 보드** (부저 + LED + 끄기 버튼) | `esp32/so4t_call_sta/` |
| 폰 핫스팟 `AndroidHotspot3054` (2.4GHz, WPA2) | 대회장에서 파이·ESP32가 같이 붙는 네트워크 | `pi_setup/net_autoconnect_1117/` |
| 학교 와이파이 `yc_yc_hs_P` | 학교에서 쓰는 와이파이 | `pi_setup/legacy_wifi_persist/` |
| 노트북(Windows) | 개발/시뮬레이션. PowerShell에서 `$env:` 로 환경변수 | `kiosk/start_kiosk.ps1`, `kiosk/start_kiosk_sim.ps1` |

브라우저 규칙: **키오스크 화면은 Google Chrome만 사용** (팀 규칙). 단, `kiosk/pi/kiosk_launcher.sh`는 아직 chromium을 띄우는 코드라 규칙과 다름 → 「11. 알려진 차이/빈칸」.

---

## 1. 전체 구조와 데이터 흐름

```
[손님 목소리] → Jabra 마이크 → Chrome(kiosk.html)
   ├─ 1차: Web Speech API(크롬 음성인식, 인터넷 필요) → 글자
   └─ 2차(필요할 때): 최근 약 7초 PCM → POST /transcribe → stt_server.py(faster-whisper, 팀 학습 모델) → 글자
        → 무관 발화 필터(KIOSK_RELEVANCE) → 의도 라우터(KIOSK_INTENTS.route) → 단계(stage)별 처리
        → 화면 갱신 + TTS(speechSynthesis, 파이에서는 speech-dispatcher) → Jabra 스피커

[큰 버튼] → 아두이노 Mega → USB 시리얼 9600 "WAKE_BUTTON\n" / 2초 "STAFF_CALL\n"
   → stt_server.py 시리얼 브리지(pyserial) → SSE /api/button-events → kiosk_serial_bridge.js
   → __kioskSleepGate.press() → 절전 해제 → forceStartOrderByF() → 주문 시작 안내 TTS
   (반대 방향) 화면 상태 → POST /api/button-command → 시리얼 "LED:IDLE/LISTEN/SLEEP/WAKE" 등 → 버튼 LED

[직원 호출] (목소리 "직원 불러줘" / 버튼 2초 / 화면 오른쪽 위 버튼)
   → 화면 "직원을 부르고 있어요" + 서버 /staff_call 기록
   → esp32_call.js v2 → http://127.0.0.1:8020/call (파이 so4t_call_relay.py)
   → so4t_call.sh 가 ESP32 주소 찾기 → http://<ESP32>/call → 부저 울림 (직원이 IO6 버튼으로 끔)
   (예비) 브라우저가 직접 http://192.168.4.1/call

[결제] 결제 단계 → payment.js v1.2 (driver: simulator) → "카드를 넣어 주세요" → U 키 = 모의 승인
   (local-agent 모드면 http://127.0.0.1:8010 payment_agent.py, 지금 backend=simulator)
```

---

## 2. 폴더 구성 (zip)

```
so4t_kiosk_full_20261123/
├─ KIOSK_FULL_SPEC.md          ← 이 문서
├─ README.md                   ← 빠른 시작
├─ kiosk/                      ← 파이 ~/kiosk_project 와 같은 구조 (최신 통합본)
│  ├─ kiosk.html               ← 키오스크 화면 전체(약 1.59MB, 39,516줄, 패치가 층층이 쌓여 있음)
│  ├─ stt_server.py            ← FastAPI 서버 (Whisper STT, 메뉴/설정/관리자/직원호출/버튼 SSE 등)
│  ├─ menu.json, kiosk_settings.json 등
│  ├─ js/  (kiosk_v89, kiosk_acoustic, kiosk_pi, kiosk_pi_perf, kiosk_talk, kiosk_v88, kiosk_assist,
│  │        kiosk_use_metrics, kiosk_customer, kiosk_shop, kiosk_presbyopia, kiosk_serial_bridge, three.min, ...)
│  ├─ static/ (order_start_menu, esp32_call(v2), payment(v1.2), payment_config.json, firebase_config(자리표시자),
│  │           firebase_kiosk, senior_plus, design_skin.js/.css, so4t_fix.js, corrections.json, menu_info.json, so4t_fonts, twemoji)
│  ├─ payment/ (payment_agent.py, payment_config.json)
│  ├─ pi/      (install.sh, kiosk-stt.service, so4t-payment.service, cpu-performance.service,
│  │            kiosk_launcher.sh, loading.html, labwc_autostart, wayfire_autostart.ini, lag_check.sh)
│  ├─ test/    (예전 E2E/브라우저 테스트 스크립트, PIN은 환경변수로 바꿈)
│  ├─ firebase_admin/ (관리자 웹, firestore.rules — 선택 기능, 지금 꺼짐)
│  ├─ docs_history/ (README_v8 ~ v8_9: 버전별 변경 기록)
│  ├─ models/  (비어 있음 — 학습 모델 넣는 곳, README 참고)
│  ├─ requirements.txt, start_kiosk.ps1(예전), start_kiosk_sim.ps1 / start_kiosk_sim.sh(이번에 추가)
├─ arduino/kiosk_button_led/kiosk_button_led.ino   ← v8.5 (최신, STAFF_CALL 포함)
├─ esp32/so4t_call_sta/so4t_call_sta.ino           ← 최신 (핫스팟 STA + 예비 AP)
├─ esp32/legacy_ap_only_so4t_call/so4t_call.ino    ← 예전 (AP 전용)
├─ pi_setup/
│  ├─ net_autoconnect_1117/   ← 핫스팟 우선 자동 연결 + ESP32 링크 (최신)
│  ├─ esp32_hotspot_1117/     ← 직원호출 중계(relay) + 주소찾기 + esp32_call.js v2 설치
│  ├─ kiosk_fix_1117/         ← 11/17 키오스크 수정(TTS 보장, 한 문장 주문 등) 설치/제거 스크립트 + 블록 원본
│  ├─ legacy_wifi_persist/    ← 예전 학교 와이파이 유지 스크립트
│  └─ labwc_autostart.example ← Chrome 자동 실행 줄 예시(재구성본)
└─ sim_tools/   ← 헤드리스 크롬 시뮬레이터 (가짜 TTS/음성인식/버튼)
```

어떤 소스가 최신인가: 「13. 출처/버전」 참고.

---

## 3. 서버 — `kiosk/stt_server.py`

### 3.1 실행
- 파이: `kiosk-stt.service` (systemd) → venv 의 `uvicorn stt_server:app --host 0.0.0.0 --port 8000 --no-access-log`, `WHISPER_CPU_THREADS=3`.
- 노트북: `python -m uvicorn stt_server:app --host 127.0.0.1 --port 8000` (또는 `start_kiosk_sim.ps1`).
- 이번 패키징 때 Whisper를 가짜 모듈로 바꿔 끼우고 켜 본 결과: `/kiosk.html`, `/menu.json`, `/kiosk_settings`, `/api/button-status`, `/staff` 200 응답 확인 (실제 Whisper 인식은 이 상자에서 안 돌려 봄).

### 3.2 환경변수 (코드 기본값)
| 변수 | 기본 | 뜻 |
|---|---|---|
| `WHISPER_MODEL` | `models/whisper-kiosk-ct2-int8` 이 있으면 그것, 없으면 `base` | Whisper 모델 |
| `WHISPER_COMPUTE_TYPE` | int8 | |
| `WHISPER_CPU_THREADS` | 3 | 파이 4코어 중 3 |
| `WHISPER_BEAM_SIZE` | 1 | (논문에는 3으로 적힌 곳 있음 → 코드와 다름) |
| `WHISPER_WAIT_READY_S` / `WHISPER_STALE_S` / `WHISPER_WARMUP` | 25 / 20 / 켜짐 | 모델 준비 대기·워밍업 |
| `KIOSK_SERVER_NICE` | 5 | 서버 우선순위 낮춤(화면 렉 줄이기) |
| `KIOSK_SAVE_RAW_AUDIO` | 0 | 손님 원본 음성 저장 안 함(개인정보) |
| `KIOSK_ADMIN_PIN` → `admin_pin.txt` → `KIOSK_ADMIN_PASSWORD` | `<ADMIN_PIN>` | 관리자 PIN (자리표시자) |
| `KIOSK_SERIAL_PORT` / `KIOSK_SERIAL_BAUD` / `KIOSK_SERIAL_BRIDGE` | 자동 / 9600 / 켜짐 | 아두이노 시리얼 브리지 |

### 3.3 경로(라우트)
- 화면: `/`, `/kiosk.html`, `/kiosk`, `/{이름}.js`(허용 목록만, BASE_DIR 또는 js/), `/static/*`
- STT: `POST /transcribe` (WAV → 글자)
- 데이터 수집(학습용): `/collect`, `/collect/`, `/collect/admin`, `/api/upload`, `/api/progress`, `/api/list`, `/download/all.zip`, `/download/audio/{f}`
- 모델: `/admin/model-info`, `/admin/upload-model`
- 직원 호출: `POST/GET /staff_call`, `/staff_call/{id}/done`, `/staff`(직원용 화면)
- 메뉴/설정/관리자: `/menu.json`, `/admin/login`, `/admin/menu`, `/kiosk_settings`, `/admin/settings`, `/admin`, `/events`, `/dashboard`
- 버튼: `/api/button-status`, `/api/button-events`(SSE), `POST /api/button-command`
- 기타: `/api/use-metrics`, `/api/acoustic-profile` (GET/POST/DELETE, 숫자만 저장)

### 3.4 시리얼 브리지 (서버 안)
- 포트 자동 찾기: `/dev/ttyUSB*` → `/dev/ttyACM*`. 포트 연 뒤 **처음 2초 입력 무시**(아두이노 리셋 잡음).
- 받는 줄(허용 목록): `WAKE_BUTTON`, `STAFF_CALL`, `START_BUTTON`, `BUTTON_PRESSED`, `TOGGLE_MIC` → SSE로 화면에 전달.
- 보내는 명령: `LED_*` 와 `LED:` 상태 명령만.
- pyserial 없으면 서버는 켜지고 버튼만 안 됨.

---

## 4. 키오스크 화면 — `kiosk/kiosk.html` + js/static

### 4.1 구조 주의 (Cursor가 꼭 알아야 할 것)
- 수십 번의 패치가 **같은 함수를 계속 덮어쓰는 구조**. 마지막에 덮어쓴 것이 실제로 동작함.
  - `speakText` 덮어쓰기 약 19곳: kiosk.html 4038, 4587, 5444, 8771, 10886, 18444, 19106, 19977, 21552, 21636, 22350, 23983, 24671, 29627, 31145, 36031 + `js/kiosk_customer.js:1384`, `js/kiosk_presbyopia.js:86`.
  - `showWelcomeScreen`: 2385, 3458, 23355, 24101, 24798, 36956(EXPLICIT_GUIDE) + senior_plus 감쌈.
  - `exitButtonSleepMode`: 10096, 23661, 25567.
- `<script src>` 로드 순서: three.min → kiosk_v89 → kiosk_acoustic → kiosk_pi → kiosk_pi_perf → kiosk_talk → kiosk_v88 → kiosk_assist → kiosk_use_metrics → kiosk_customer → kiosk_shop → kiosk_presbyopia → kiosk_serial_bridge → static/order_start_menu → static/esp32_call → static/payment → static/firebase_config → static/firebase_kiosk → static/senior_plus → static/design_skin → static/so4t_fix. 그 뒤 kiosk.html 맨 끝 인라인 블록 `SO4T_FIX_1117`(38929~) 과 `so4t-fix-1117-oneshot`(39168~).
- **기능 삭제 금지**(팀 규칙). 고칠 때는 덮어쓰기 순서를 지키며 최소 수정.

### 4.2 단계(stage, `currentStageName`)
`sleep`(절전) → `welcome` → `open_order_prompt`(메뉴 바로 말하기) → `category_select` → `menu_grid` → `taste_select_prompt` → `menu_confirm` → `temp`(온도) → `upsell` → `quantity` → `cup_size`(200/350/500ml) → `beverage_option_prompt` → `beverage_option_step` → `beverage_result` → `direct_drink_more_option_prompt` → `add_more_prompt` → `summary` → `summary_add_quantity` → `place`(매장/포장) → `payment` → `guidance` → `payment_confirm` → `done` → (3.5초 뒤) `sleep`.
기타: `shop_ask`(가게 종류), `admin_auth`, `admin_panel_open`, `guide`. 단계별 도움말 문장은 kiosk.html 약 1168줄 `DETAIL`.

### 4.3 켜짐 ~ 절전 ~ 주문 시작
1. 부팅: 첫 화면 오버레이를 **한 번 터치**해야 함(브라우저 소리 정책) → 그 뒤 터치 잠금, `sleep` 단계로 감.
2. 절전 안내 TTS: "절전 모드입니다. 주문을 시작하시려면 아래의 빛나는 버튼을 눌러주세요." 끝나면 버튼 LED 깜빡임(`BUTTON_LED_BLINK`) + 큐 문장.
3. `__kioskSleepGate` (kiosk.html 약 38000~38110): F 키/버튼은 **절전일 때만**, **안내가 끝난 뒤에만** 받음(안내 없이 절전에 들어간 경우는 TTS 안 할 때 바로 받음). `wake()` → `LED_READY`, `BUTTON_LED_ON` → `window.forceStartOrderByF()` (없으면 `exitButtonSleepMode`).
4. `forceStartOrderByF` (kiosk.html 22596~22745): `speechSynthesis.cancel()` → TTS 플래그 초기화 → `audioCtx.resume` → `initThreeJS` → 장바구니 비움 → `await startListening()` → `startOrder()` → `LED_BLINK`.
5. `recoveredStartOrder` (약 24820): `open_order_prompt` + TTS "무엇을 드시고 싶으신가요? 메뉴를 아시면 바로 말씀해주세요. 잘 모르시면 메뉴판 보여줘 또는 추천해줘 라고 말씀해주세요."
   - welcome 화면(약 24798) 글자: "주문을 시작하시겠습니까?" / 말: "메뉴 이름을 말씀해 주세요."
   - `static/order_start_menu.js`: "주문 시작" → 바로 `category_select`.
6. 주문 끝: "감사합니다. 맛있게 드세요." → 3.5초 뒤 `enterSleepMode` (kiosk_fix_1117이 TTS 끝날 때까지 미룸, 최대 12초).
7. 손님이 떠나면 자동 절전되는 **시간 타이머는 코드에서 못 찾음 → 미확인**. (아두이노는 SLEEP/PERSON_LEFT를 보내지 않음, 5장)

### 4.4 키보드 (테스트/운영)
| 키 | 기능 | 위치 |
|---|---|---|
| F (ㄹ, KeyF) | 큰 버튼과 같음 = 주문 시작(절전 해제) | sleep gate |
| T | 글자로 주문 넣기(prompt 창) → `isValidContext` → `processVoiceCommand` | kiosk.html 약 1592 |
| U (ㅕ, KeyU) | **모의 결제 승인** | static/payment.js v1.2 |
| Ctrl+Shift+P | 결제 테스트 패널 | payment.js |

### 4.5 음성 인식 (하이브리드 STT, kiosk.html 약 28100~29000)
- 1차 Web Speech(ko-KR) → `needsWhisper(text)`(28495)가 참이면 최근 약 7초 오디오를 `/transcribe`로 보냄:
  - 14글자 이상 / 옵션 단어(얼음·시럽·당도·휘핑·펄·크럼블·밥적게·밥많이·맵게·덜맵게) / 메뉴+개수
  - 단, 도움말 말이나 카테고리 이름이면 바로 처리
- `routeText`(28534): 정규화 → "B 말고 A" 처리 → **TTS 중이면 버림** → 에코(TTS 끝 1초 안) 버림 → 무관 발화 버림(`isRelated`) → `KIOSK_INTENTS.route` → 기존 흐름.
- Whisper 보내는 중에 또 말하면 `__so4tFixWhisperBusy`(so4t_fix.js)가 빠른 인식 결과로 처리.
- 같은 글자 짧은 시간 반복 → "HYBRID 중복 무시".
- 말 끝 침묵 750ms. 음향 적응(`js/kiosk_acoustic.js`, 숫자만 저장)이 최대 1600ms/10초까지 늘리는데, so4t_fix가 **1.0초 / 7초로 상한**.
- 오프라인: 10초 안에 Web Speech 오류 3번 → Whisper 전용 모드, 60초마다 다시 시험.
- TTS 중 마이크 차단: `muteMicForTTS` / `releaseMicAfterTts`(ttsGeneration 번호로 경쟁 방지).
- 수량(`KIOSK_QUANTITY`): "네" 단독은 대답, "네 개"=4. so4t_fix: 한개/한 개/하나/1개 등 철자 변형, 메뉴+개수 한 번에.
- 사투리/오인식 보정: senior_plus의 경상도 말 약 40개 + `static/corrections.json`(지금 비어 있음).

### 4.6 TTS (말하기)
- 실제로 쓰이는 사슬(마지막 덮어쓰기부터): 마스터 TTS(약 36031) → `resolveMasterTts` → `KioskTalk.resolveSpeak`(`js/kiosk_talk.js:283`, 관리자에서 저장한 문장/단계로 글을 바꿀 수 있음) → 31145 → 29627 → `recoveredSmoothSpeakText`(24671, 큐 + `_busy`, 직전과 같은 문장 버림, 안전 타이머 max(2500, 글자수×210)+1200ms).
- `js/kiosk_pi.js`(31~90줄): 파이 모드에서 `speechSynthesis.cancel/speak` 감쌈. 실제로 말하는 중이 아니면 cancel 무시, cancel 직후 GAP(파이 140ms) 안의 speak는 `pendingTimer`로 미룸.
- 접근성: 말 속도/글자 크기 음성 명령(senior_plus), 결제 전 주문 다시 읽어주기, 지난 주문 다시 하기.
- `localStorage kiosk_tts_gap_ms` 로 GAP 조정 가능.

### 4.7 메뉴 (`kiosk/menu.json` v1, 18개, 원)
- 국밥: 돼지국밥 9000, 순대국밥 9500, 소고기국밥 11000, 수육 백반 14000
- 불고기: 한우 불고기 18000, 불고기 덮밥 10500
- 햄버거: 치즈버거 6900, 불고기버거 7400
- 커피: 아메리카노 3500, 카페라떼 4300
- 음료: 딸기 라떼 4800, 오렌지 주스 4000, 레몬 에이드 4800, 쿠키 쉐이크 5300, 콜라 2000, 사이다 2000
- 디저트: 치즈 케이크 5500, 소프트 아이스크림 3000
- 가게 종류(`js/kiosk_shop.js`, `localStorage kiosk_shop_v1`): 국밥(18) / 카페(커피·음료·디저트 13 + 초코 케이크·당근 케이크·티라미수) / 버거(7 + 치킨버거) / 꽃집 6 / 문구 5 / 선물 4 = 합계 53 (논문 70.4만 명 시뮬레이션의 53개 메뉴와 같음).
- `menu.json`은 2분마다 다시 불러옴. 관리자 화면(`/admin`)에서 수정.
- 세트: 가격 +2000원.

### 4.8 옵션 (`generateDrinkOptions`, kiosk.html 약 1936)
- 단계 값 1~5 = 없음/적게/보통/많이/가득 (화면 표기 `["", "1단계 없음", "2단계 적게", "3단계 보통", "4단계 많이", "5단계 가득"]`, 9037·24244).
- 커피: 샷, 시럽, **얼음은 온도가 '아이스(ICE)'일 때만**.
- 탄산(콜라·사이다): 옵션 없음.
- 디저트 계열 음료: 얼음·당도·크럼블·휘핑. 과일 계열: 얼음·당도·시럽·휘핑·펄·과일.
- 기본값(21190, 22980): 샷 1, 커피 시럽 1, 핫이면 얼음 1, 크럼블 1, 나머지 3.
- 컵: 200/350/500ml. 음식: 밥 양(riceAmount), 맵기(spicyLevel). 버거: 채소·피클·소스·치즈·양파·토마토.

### 4.9 한 문장 주문 (`so4t-fix-1117-oneshot`, kiosk.html 39168~)
- 받는 단계(ENTRY): welcome, open_order_prompt, category_select, menu_grid, add_more_prompt.
- 제외: 취소·처음·말고·메뉴판·추천·얼마 등이 들어가면 한 문장 주문 안 함(`shouldOneShot`, 39420).
- 조건: 메뉴가 **정확히 1개** + 채울 칸(slot) 1개 이상. 개수만 있으면 단위(개/잔 등)가 있어야 함.
- 별칭: 아아 = 아이스 아메리카노, 뜨아 = 뜨거운 아메리카노.
- `lvl()`(39215): 빼고=1, 적게=2, 보통=3, 많이/추가=4, 가득=5. `parse`(39225), `applyOpts`(39303), `answerFor`(39312), `hookRoute`(39433).
- 동작: `selectSpecificItem`으로 메뉴 고른 뒤, 이후 단계 질문에 자동으로 대답(온도/수량/컵/옵션/포장…), 그동안 TTS 묵음. 25초 제한. 모르는 칸이 나오면 멈추고 그 질문을 손님에게 함(40초 안에 대답하면 이어감).
- 끄기: `localStorage so4t_oneshot_off=1`.

### 4.10 결제 (`static/payment.js` v1.2 + `static/payment_config.json`)
- driver `simulator`(기본) / `off`(예전처럼 4초 뒤 완료) / `local-agent`(파이 `payment_agent.py` :8010, `/pay` `/cancel` `/status`).
- timeoutSec 20, simulator autoResult `manual` → **U 키로 승인**.
- 문장: "카드를 넣어 주세요" / 시간 초과 "카드가 확인되지 않았어요…" / 거절 "결제가 안 됐어요. 다시 하거나 직원을 불러 드릴까요?" / 승인 "결제가 완료되었습니다. 카드를 빼 주세요."
- 단계가 guidance/payment/payment_confirm 을 벗어나면 결제 대기 중단.
- 실제 카드 단말기 연동: 없음(`terminal` 항목 비어 있음, 포트 기본값 `/dev/ttyUSB0`은 아두이노와 겹침 → 실제 단말 붙일 때 바꿔야 함).

### 4.11 직원 호출 (kiosk.html 약 38480 V8 블록 + `static/esp32_call.js` v2)
- 말: "직원 불러줘", "사람 불러줘", "도와주세요" / 버튼 2초 / 화면 오른쪽 위 버튼.
- 화면 "직원을 부르고 있어요" + 차임, 서버 기록, 20초 뒤 닫힘, 10초 안 중복 무시.
- esp32_call.js v2: `window.__kioskStaffCall` 감쌈 → 먼저 `http://127.0.0.1:8020/call`(파이 중계) → 실패 시 `http://192.168.4.1/call`. 쿨다운 5초, 타임아웃 2.5초. 손 시험: 콘솔에서 `window.__esp32Call()`.

### 4.12 그 밖의 기능
- `js/kiosk_assist.js`, `kiosk_customer.js`(음성 장바구니 고치기 "[A] 말고 [B]로" 등), `kiosk_presbyopia.js`(노안 큰 글씨), `kiosk_use_metrics.js`(사용 통계 → `/api/use-metrics`), `/events` 통계.
- `static/senior_plus.js`: 속도·글자 크기, 지난 주문 다시, 읽어주기, 맵기/알레르기 안내(`menu_info.json` 지금 비어 있음), 사투리 보정.
- `static/design_skin.js/.css`: 요리사 모자 마스코트 SVG, 아이보리/코랄, Pretendard 글꼴(`static/so4t_fonts`). 이모지는 로컬 twemoji.
- `static/so4t_fix.js` v1.0: 수량 철자, 메뉴+수량, "처음으로" 초기화, 음향 적응 상한.
- SO4T_FIX_1117 블록(38929~): 아래쪽 #senior-bar 숨김, 핵심 문장 TTS 감시(재시도 최대 2번), not-allowed면 다음 터치 때 다시, 절전 해제 후 확인(afterWake), 작별 인사 끝난 뒤 절전, 수량 미룸, 옵션 중복 제거, add_more에서 앞 상품 유지. 로그 `[kfix1117]`, `window.__so4tFix1117.log / stats`.
- Firebase(`static/firebase_kiosk.js`): `apiKey`가 `PASTE`로 시작하면 자동 꺼짐 → 지금 꺼짐.
- 파이 모드/성능: `?pi=1`(3D 끄고 2D, 애니메이션·그림자 끔), `?lite=1/0`, `?debug=1`, localStorage `kiosk_pi_mode`, `kiosk_pi_off`, `kiosk_perf_off`, `kiosk_acoustic_off`, `kiosk_tts_gap_ms`, `so4t_fix_off`, `so4t_oneshot_off`, `kiosk_shop_v1`.

---

## 5. 아두이노 Mega 2560 — `arduino/kiosk_button_led/kiosk_button_led.ino` (v8.5)

- 보드: Mega 2560 호환(CH341 USB 칩 → 파이에서 `/dev/ttyUSB0`), 9600 baud.
- 핀: 버튼 `22`(INPUT_PULLUP), 버튼 GND 대용 `50`(LOW 출력), 버튼 LED `9`(PWM), 상태 LED `13`.
- 버튼 처리: 디바운스 30ms, 다시 누름 방지 400ms.
  - 누르는 순간 `WAKE_BUTTON\n` 1번 → 화면에서 **주문 시작**.
  - 2000ms 계속 누르면 `STAFF_CALL\n` 1번 + LED 900ms 빠른 깜빡임(75ms 간격) → 직원 호출.
  - 그 밖의 말은 보내지 않음 (화면이 SLEEP/PERSON_LEFT 가 들어간 줄을 절전 명령으로 보기 때문).
- LED 명령(파이 → 아두이노):
  - 새 방식 `LED:IDLE`(숨쉬듯 15~90 밝기, 3초 주기) / `LED:LISTEN`(켜짐) / `LED:SLEEP`(꺼짐) / `LED:WAKE`(0.3초 깜빡임).
  - 예전 방식 `BUTTON_LED_BLINK`/`LED_WAKE_PROMPT`=깜빡임, `LED_SLEEP`/`LED_OFF`=끔, `LED_READY`/`BUTTON_LED_ON`/`LED_ON`=켬, `LED_BLINK`=숨쉬기(2초).
  - `LED:` 명령을 받은 뒤 8초 동안은 예전 방식 명령 무시(서로 덮어쓰기 방지). 한 줄 최대 40바이트.
- 예비(대체) 설계: ESP32를 버튼 보드로 쓸 때 버튼 GPIO4, LED GPIO5 (지금 쓰는 건 Mega).
- 예전 v7.3(STAFF_CALL 없음)은 zip에 넣지 않음.

---

## 6. ESP32-S3 직원 호출 벨 — `esp32/so4t_call_sta/so4t_call_sta.ino`

- 놓는 곳: **키오스크 박스 밖**(직원 쪽). 전원: AA 건전지 4개.
- 연결: STA로 폰 핫스팟 `AndroidHotspot3054`(WiFiMulti, 선택 `WIFI2` 하나 더 넣을 수 있음). 호스트 이름/mDNS `so4t-call`.
- 30초 안에 못 붙으면 예비 AP `SO4T-CALL2`(192.168.4.1, 채널 6, 최대 4대)도 같이 켬(AP+STA).
- HTTP: `/call`(부저 2000Hz 150ms 켬/끔 반복 + IO7 LED), `/stop`, `/ping`("ok"), `/`(상태).
- 핀: 부저 IO5, 끄기 버튼 IO6(→GND), LED IO7. 연결되면 2500Hz 삑 1번.
- 시리얼 115200(디버그), Wi-Fi 절전 끔, 3초마다 재접속(AP 켠 뒤 10초).
- 상태: **컴파일만 확인, 실제 보드에서 시험 안 함(미확인)**.
- 예전 버전 `esp32/legacy_ap_only_so4t_call/so4t_call.ino`: AP 전용(파이가 ESP32 AP에 직접 붙는 방식).

---

## 7. 라즈베리파이 설정

### 7.1 기본
- Pi 4 8GB, 사용자 `so4t`, 호스트 `so4t.local`, 프로젝트 `~/kiosk_project`, Python venv `~/kiosk_project/venv`.
- 데스크톱 labwc(Wayland). 화면 DSI-1(터치), HDMI는 끔(HDMI 때문에 흰 화면 나던 문제 해결 이력).
- 화면 회전: 런처 기본 `KIOSK_ROTATE=270`(V8.9.1: 예전 90에서 180도 더). 실제 파이 autostart에 들어간 값은 **미확인**.
- 소리: 기본 출력 음량 100%(런처), TTS는 Chrome `--enable-speech-dispatcher` → speech-dispatcher/espeak-ng (`pi/install.sh` 가 설치).

### 7.2 systemd
| 서비스 | 내용 |
|---|---|
| `kiosk-stt.service` | STT 서버 :8000 |
| `so4t-payment.service` | payment_agent :8010 (템플릿 `__USER__`/`__DIR__` 를 설치 때 바꿈) |
| `cpu-performance.service` | CPU performance 거버너 |
| `so4t-call-relay.service` | ESP32 직원호출 중계 :8020 (esp32_hotspot_1117 설치) |
| `so4t-esp32-link.service` | ESP32 링크 확인 (net_autoconnect_1117) |
| `so4t-wifi-autoconnect.timer` | 부팅 20초 뒤, 그 뒤 20초마다 핫스팟 자동 연결 확인 |

### 7.3 키오스크 브라우저 자동 실행
- `kiosk/pi/kiosk_launcher.sh`(labwc autostart에서 실행): 화면 설정 → `loading.html?pi=1` → 서버 뜨면 `http://localhost:8000/kiosk?pi=1`, 꺼지면 5초 뒤 재실행, 원격 디버깅 9222. **chromium 사용(규칙과 다름)**.
- 실제 파이 autostart에는 google-chrome-stable 줄이 있음(11/17 kiosk_fix 설치 스크립트가 그 줄에 `--autoplay-policy=no-user-gesture-required` 추가). 정확한 내용 **미확인** → `pi_setup/labwc_autostart.example`(설치 스크립트가 안내한 줄로 재구성).
  - 주의: 이 Chrome 줄은 주소에 `?pi=1` 이 없음 → 파이 모드는 UA 판정(`js/kiosk_pi.js:20`, `Linux`+`aarch64|arm`)에 의존. 최근 Chrome은 리눅스 UA를 `x86_64`로 고정해 보내는 경우가 있어 **파이 모드가 안 켜질 수 있음(미확인)** → 버그 1과 관련 가능.

### 7.4 설치 묶음 (pi_setup)
- `kiosk_fix_1117/`: `install_kiosk_fix_1117.sh`(kiosk.html 끝에 `so4t_fix_1117_block.html` 넣고 autostart Chrome 줄에 autoplay 플래그), `uninstall_...`.
- `esp32_hotspot_1117/`: relay(`so4t_call_relay.py`), `so4t_call.sh`, `esp32_call.js` v2 설치.
- `net_autoconnect_1117/`: 핫스팟 우선 연결, ESP32 링크, `net_check.sh`(상태 점검).
- `legacy_wifi_persist/`: 예전 학교 와이파이 유지(타이머 재접속, 절전 끔).

---

## 8. 네트워크 (학교 와이파이 · 핫스팟 · 보드 연결)

- **대회장/기본**: 폰 핫스팟 `AndroidHotspot3054`(2.4GHz, WPA2 필수 — ESP32가 5GHz 못 붙음).
  - NetworkManager 프로필 `so4t-competition-hotspot`: 우선순위 = max(100, 다른 프로필 최대+10), wlan0 MAC에 묶음, autoconnect-retries 0(무한), powersave 2(끔).
  - 수동: `sudo nmcli con up so4t-competition-hotspot`
  - 핫스팟 데이터가 한정 → Web Speech(구글 서버) 사용량 주의. 핫스팟 끊기면 10초 안 오류 3번 → Whisper 전용(오프라인) 모드.
- **학교**: `yc_yc_hs_P` (NM 이름 `yc_yc_hs_P 1`, 우선순위 20). 예전 `hotspot` 프로필 우선순위 10.
- **ESP32 연결 경로**: 파이에 USB 와이파이 동글 **없음** → 파이(wlan0)와 ESP32가 **같은 핫스팟**에 붙어서 통신.
  - `so4t_call.sh` 주소 찾기 순서: wlan1 192.168.4.1(동글 있을 때) → 저장된 IP(`~/.so4t_esp32_ip`, `/tmp/so4t_esp32_ip`) → mDNS `so4t-call.local`(getent/avahi-resolve) → 192.168.4.0/24 경로 확인 → wlan0 /24 전체 병렬 스캔(0.6초, 64개씩, `/ping`=ok 찾기).
  - relay(:8020)는 60초마다 주소 캐시 데움. `/call`, `/stop`(큐), `/find`, `/status`, `/ping`.
  - 예비 프로필 `so4t-esp32-call`: wlan1, 192.168.4.3/24, never-default, 우선순위 50(동글 있을 때만 의미).
- 전역 Wi-Fi 절전 끔(`98-so4t-powersave.conf`), 다른 프로필은 내장 MAC에 묶고, ESP SSID는 자동연결 끔.
- 학교 와이파이에서 ESP32를 쓰는 방법: ESP32에 `WIFI2`로 학교 SSID를 넣으면 같은 망 스캔으로 찾을 수 있음(학교망이 기기 간 통신을 막으면 안 됨 — **미확인**).

---

## 9. 물리 환경 · 현장 소음

- 본체: 아크릴 키오스크 모양 케이스(설계도 v5). 화면은 케이스 안(위로 안 튀어나옴), 아두이노·배선이 보임, 아두이노와 마이크 선은 화면 아래쪽에 연결. 맨 왼쪽 버튼 박스(기둥에 연결), 그 위에 큰 아케이드 버튼, 박스 안에 회로.
- 마이크/스피커: Jabra Speak2 55(USB 스피커폰, 마이크+스피커 일체). 예전 마오노 USB 다이내믹 마이크는 소음·스펀지 위생 문제로 교체.
- 소음 조건(7월 시험): 카페 음악을 휴대폰 최대 음량으로 마이크 바로 옆에서 재생. 대응: 새 마이크 + Whisper 학습 모델(1,000개 단위로 모아 한 번에 학습, 화자 분리 안 함) + 무관 발화 필터 + TTS 중 마이크 차단 + 에코 1초 차단 + 음향 적응.
- 대회장 걱정 1순위: **오프라인 모드로 떨어지는 것**과 **화면 렉**. (그래서 파이 모드 2D, CPU performance, 서버 nice 5, Whisper 스레드 3)
- 사용자: 고령층/저시력 손님 → 큰 글씨, 느린 말, 한 문장 주문, 버튼 하나로 시작.
- 현장 소음 데시벨, 대회장 Wi-Fi 상태, 실제 손님 연령대 분포: **미확인**.

---

## 10. 현재 알려진 버그 (Cursor가 원인 찾아 수정할 것)

> 아래 두 개는 **아직 안 고쳐진 상태로 zip에 그대로 들어 있음**. Cursor가 원인을 찾아 고칠 것. 기능 삭제 금지.

### 버그 1 — 큰 버튼으로 절전 해제한 뒤 '주문 시작 안내' TTS가 안 나옴
- 증상(실제 파이): 버튼(또는 F) → 화면은 주문 단계로 넘어감 → "무엇을 드시고 싶으신가요? …" 안내가 **안 들림**. 그런데 이때 "메뉴판 보여줘", "추천해줘"라고 말하면 **인식은 잘 됨**(= 마이크·단계 전환은 정상, TTS만 사라짐). 절전 안내 TTS 자체는 나옴.
- 이미 해 본 것(효과 없음): kiosk_fix_1117의 재시도/감시(watchdog, afterWake) + Chrome `--autoplay-policy=no-user-gesture-required`. 헤드리스 시뮬레이터에서는 통과했지만 실제 파이에서는 그대로.
- 관련 코드:
  - 버튼 경로: `js/kiosk_serial_bridge.js:43~50` (`WAKE[msg]` → `__kioskSleepGate.press("bridge:WAKE_BUTTON")`, 게이트 없으면 `exitButtonSleepMode`)
  - `__kioskSleepGate` `press`/`wake`/`announce`/`showCue` — kiosk.html 약 38040~38110
  - `forceStartOrderByF` — kiosk.html 22596~22745 (cancel → audio resume → initThreeJS → `await startListening()` → `startOrder()`)
  - `recoveredStartOrder` — 약 24820 / `recoveredWelcomeScreen` — 약 24798
  - TTS 사슬: 36031(마스터) → `KioskTalk.resolveSpeak`(js/kiosk_talk.js:283) → 31145 → 29627 → `recoveredSmoothSpeakText`(24671)
  - `js/kiosk_pi.js:31~90` speechSynthesis cancel/speak 감싸기 (GAP, pendingTimer)
  - SO4T_FIX_1117: `watchdog`(38981), `afterWake`(39036), `wrapSleep`(39105)
- 원인 후보 (확인 필요, 가능성 높은 순서 아님):
  1. **cancel 경쟁으로 큐가 지워짐**: `forceStartOrderByF`가 절전 문장을 `speechSynthesis.cancel()` → 그 발화의 `onerror('interrupted'/'canceled')`가 **비동기로 늦게** 와서 `recoveredSmoothSpeakText`의 onerror가 `_queue.length = 0; _busy=false` → 그 사이 큐에 들어간 새 안내 문장이 지워짐. (파이의 speech-dispatcher는 이벤트가 더 늦게 옴 → 헤드리스에서는 재현 안 됨)
  2. **kiosk_pi.js 지연 speak가 조용히 버려짐**: cancel 뒤 140ms(GAP) 안의 speak는 `pendingTimer`로 미뤄지는데, 그 사이 누가 또 `cancel()`(마이크 시작, 단계 전환, 다른 패치) 하거나 또 `speak()` 하면 pendingTimer가 지워져 **이벤트(start/end/error) 없이 사라짐** → `_busy`가 안전 타이머(이 문장 길이면 십몇 초)까지 막혀 다음 문장도 밀림.
  3. **마이크 시작/상태 전환이 TTS를 끊음**: `await startListening()` 과 `startOrder()` 순서, `muteMicForTTS`/`releaseMicAfterTts`, welcome·order_start_menu 쪽 `speechSynthesis.cancel()`.
  4. **사용자 활성화(autoplay) 정책**: 버튼은 시리얼→SSE라 브라우저 입장에서 '사용자 동작'이 아님. 부팅 때 한 번 터치로 얻은 sticky activation이 페이지 이동(loading.html → kiosk, 재시작 루프)이나 새로고침으로 사라졌을 수 있음. 단, 절전 안내는 나오므로 우선순위 낮음.
  5. **목소리(voices) 미로딩**: `speechSynthesis.getVoices()`가 비어 있을 때 ko-KR 목소리 지정 실패/무음.
  6. **패치 덮어쓰기 순서**: speakText/showWelcomeScreen/exitButtonSleepMode가 여러 번 덮어써져, 1117 블록이 감싼 함수가 실제 경로가 아닐 수 있음(예: wake가 1117이 감싼 것보다 먼저 잡아둔 `startOrder` 참조를 씀).
  7. **afterWake가 성공을 잘못 판정**: `start` 이벤트(K.lastStartAt)를 성공으로 보는데, 파이 speech-dispatcher는 소리 없이 start가 올 수 있음. watchdog은 3.5초 안에 start가 없을 때만 다시 말함, cancel이 섞이면 감시 자체가 끝남.
  8. **파이 모드 판정**: Chrome 줄에 `?pi=1`이 없고 UA가 x86_64로 나오면 `isPi=false` → GAP·lite 동작이 시뮬레이터와 다름(미확인).
- 확인 방법(파이에서): Chrome 원격 디버깅(런처는 9222, Chrome autostart 줄에는 `--remote-debugging-port=9222` 추가 필요) 또는 `?debug=1` 콘솔에서
  - `[kfix1117] 절전 해제 감지` → `주문 시작 안내 정상 재생` / `다시 말함` 로그가 나오는지
  - `window.__so4tFix1117.log`, `window.__so4tFix1117.stats`
  - `speechSynthesis.getVoices().length`, `speechSynthesis.speaking/pending`
  - speakText 사슬과 kiosk_pi.js 에 임시 `console.log`(cancel 호출자 `new Error().stack`, pendingTimer 지워짐, onerror 종류, `_queue` 길이)
- 고칠 때 기준: 버튼/F 한 번에 **안내 문장이 끝까지 1번** 들려야 하고, 두 번 겹쳐 말하지 않을 것. 안내 중엔 마이크 차단, 끝나면 바로 인식.

### 버그 2 — 포스터 예시 '아메리카노 시럽 추가 얼음 적게' 한 문장 주문이 실제 재시험에서 불안정
- 증상: 포스터에 적힌 대로 말하면 어떤 때는 되고 어떤 때는 옵션이 빠지거나 흐름이 멈춤/다른 단계로 감. (정확한 실패 모양은 **미확인** → 콘솔 로그로 확인할 것)
- 시뮬레이터 테스트(`sim_tools/t_one.json` 41개)에는 **이 문장 그대로는 없음**(시럽 테스트 0개). "아이스 아메리카노 1개 얼음 많이 포장해서 줘", "아메리카노 차갑게 샷 추가해서 세 잔" 등은 통과.
- 이 문장이 지나가는 길(정상이라면):
  1. Web Speech 1차 → `needsWhisper`(28495): '시럽/얼음' + 14자 이상 → `sendWhisper` → `/transcribe` → `routeText`(28534)
  2. `routeText`: TTS 중이면 버림, 에코, `isRelated` → `KIOSK_INTENTS.route` → oneshot `hookRoute`(39433) → `shouldOneShot`(39420) → `parse`(39225)
  3. parse 결과 기대값: 메뉴 아메리카노, 온도 '얼음' 단어로 차갑게 추정, 옵션 `syrup=4`(추가→많이), `ice=2`(적게), 수량·포장 없음
  4. `selectSpecificItem` → 단계마다 `answerFor`(39312): temp=차갑게, quantity=없음 → **손님에게 수량 질문하고 멈춤** → 40초 안 대답하면 이어감 → beverage_option_prompt는 옵션이 있으므로 "아니요" → `applyOpts`(39303)가 `tempItem.beverageOptions`에 합침
- 원인 후보:
  1. **말을 끊어 인식**: 천천히 말하면 Web Speech가 "아메리카노"만 먼저 확정 → 옵션 없는 일반 흐름 시작 → 뒤의 "시럽 추가 얼음 적게"는 다음 단계(temp/quantity)에서 들어와 무시/오인식.
  2. **Whisper 늦은 결과와 자동 진행 충돌**: oneshot 자동 진행 중에 다른 인식 결과(Whisper 늦은 응답, so4t_fix 의 WhisperBusy 처리, 중복)가 들어오면 "손님 말 → 자동 진행 중단"으로 끊김. 파이에서 Whisper는 몇 초 걸려 헤드리스 시뮬(가짜 STT)에서는 안 나타남.
  3. **옵션 단어 오인식**: "시럽"→"시험/씨럽", "적게"→"저게/적개" 등 → `lvl()` 정규식이 못 잡음. `corrections.json` 비어 있음, Whisper 학습 데이터/초기 프롬프트에 옵션 단어가 충분한지 미확인.
  4. **온도/얼음 순서**: 커피는 '아이스(ICE)'일 때만 얼음 옵션이 생김. 온도 답이 늦게 들어가거나 HOT으로 들어가면 `ice` 키가 없어 '얼음 적게'가 버려짐. 문장에 온도가 없어 temp 단계 질문이 끼어들 수 있음.
  5. **기본값 덮어쓰기**: 21190 근처는 옵션 단계 진입 때 `tempItem.beverageOptions = defaultOpts`로 **통째로 바꿈**(22980 근처는 빈 칸만 채움). 자동 대답 순서에 따라 applyOpts 값이 기본값(시럽 1, 얼음 3)으로 덮일 수 있음. 옵션 중복 제거(1117)와도 충돌 확인.
  6. **'시럽 추가'의 뜻**: 코드상 '추가'=4단계(많이). 확인 문장에 "시럽 많이"로 나와 손님/심사위원이 틀렸다고 느낄 수 있음(커피 시럽 기본 1=없음). 기대 동작을 팀과 맞출 것.
  7. **필터/차단**: TTS 중 말하면 `routeText`가 버림(안내 끝나기 전에 말한 경우). `shouldOneShot` 제외 단어, 단계가 ENTRY가 아닐 때(예: menu_confirm, temp에서 말함)는 한 문장 주문 안 됨.
  8. **수량 없음**: 이 문장엔 수량이 없어 반드시 수량 질문에서 멈춤 → 손님이 "한 잔" 대신 다른 말을 하면 이어가기 실패.
- 확인 방법: T 키로 글자 주문 "아메리카노 시럽 추가 얼음 적게" (STT 빼고 파서/흐름만 시험) → 콘솔의 oneshot 로그, 최종 `cart`의 `beverageOptions`(syrup=4, ice=2, temp=아이스) 확인 → 그다음 실제 말로 시험해 Web Speech 1차/Whisper 2차 글자를 비교.
- 고칠 때 기준: 이 문장(띄어쓰기·말 속도 달라도)으로 **아메리카노 아이스, 시럽 많이(4), 얼음 적게(2)**가 장바구니에 들어가고, 모르는 칸(수량·포장)만 한 번씩 물을 것. `sim_tools/t_one.json`에 이 문장 테스트를 추가해 통과시킬 것.

---

## 11. 알려진 차이 · 빈칸 · 시험 안 된 것 (미확인 포함)

1. `kiosk/pi/kiosk_launcher.sh`·`pi/install.sh`는 **chromium** 사용 → 팀 규칙(Chrome만)과 다름. 실제 파이는 Chrome autostart 줄 사용(정확한 내용 미확인).
2. 화면 회전 실제 값(90/270) 미확인.
3. ESP32-S3 벨: 컴파일만, 실기 시험 안 함. 학교 와이파이에서 ESP32 동작 미확인.
4. 실제 카드 단말 연동 없음(모의 결제만). 단말 포트 기본값이 아두이노와 같은 `/dev/ttyUSB0`.
5. 자동 절전(손님이 떠나면) 타이머 코드 못 찾음 → 미확인.
6. `menu_info.json`(맵기/알레르기), `corrections.json` 비어 있음.
7. Firebase 꺼짐(설정 자리표시자). 쓰려면 `static/firebase_config.js`에 값 넣기.
8. 학습 Whisper 모델은 zip에 없음(`kiosk/models/README_모델넣기.txt`).
9. `WHISPER_BEAM_SIZE` 코드 1 vs 논문 3.
10. 파이 TTS(speech-dispatcher) 음질/지연, 대회장 소음 수준 미확인.
11. GitHub `cursor/staff-talk-tts-9c77` 브랜치는 이 zip보다 **예전 버전**(10/09). 덮어쓰지 말 것.

---

## 12. 비밀값 채우는 곳 (zip에는 자리표시자만 있음)

| 자리표시자 | 파일 | 뜻 |
|---|---|---|
| `<HOTSPOT_PASSWORD>` | `esp32/so4t_call_sta/so4t_call_sta.ino` (HOT_PASS), `pi_setup/net_autoconnect_1117/install_net_autoconnect.sh` (HOT_PSK) | 폰 핫스팟 비번 |
| `<ESP32_AP_PASSWORD>` | `esp32/so4t_call_sta/so4t_call_sta.ino` (AP_PASS), `esp32/legacy_ap_only_so4t_call/so4t_call.ino`, `install_net_autoconnect.sh` (ESP_PSK) | ESP32 예비 AP 비번(8자 이상) |
| `<SCHOOL_WIFI_PASSWORD>` | (파일에 원래 없음) 파이에서 `nmcli`로 직접 | 학교 와이파이 |
| `<ADMIN_PIN>` | `kiosk/stt_server.py` 기본값, `kiosk/pi/kiosk-stt.service` 주석, 시뮬 스크립트 | 관리자 PIN. 환경변수 `KIOSK_ADMIN_PIN` 또는 `kiosk/admin_pin.txt` 로 넣는 게 좋음 |
| `PASTE_<FIREBASE_API_KEY>` 등 | `kiosk/static/firebase_config.js`, `kiosk/firebase_admin/admin/firebase_config.js` | Firebase(선택) |

실제 값은 팀 내부에서만 공유. Cursor 채팅에 붙여넣지 말 것.
(11/23) 파이 쪽 핫스팟 비밀번호는 `pi_setup/setup_pi_1123.sh` 실행 중 입력하면 됨(화면에 안 보임, 파일 수정 필요 없음).

---

## 13. 출처 · 버전

- 키오스크: 파이 상태 기준 통합본(11/17 수정 `SO4T_FIX_1117` + 한 문장 주문 블록 포함, payment.js v1.2 = U 키 승인, esp32_call.js v2) → 이 zip이 가장 최신.
- 아두이노: v8.5 (11,404바이트, STAFF_CALL 포함). 예전 v7.3은 제외.
- ESP32: 11/17 핫스팟 STA 버전. 네트워크: 11/17 net_autoconnect.
- GitHub 브랜치(10/09)에서는 `requirements.txt`, `start_kiosk.ps1`만 가져옴.
- 이번에 바꾼 것: 비밀값 → 자리표시자, sim_tools 경로를 상대경로/`CHROME_PATH`로, 새 파일(requirements.txt, start_kiosk_sim.*, models README, labwc_autostart.example, README). **키오스크 동작 코드는 안 바꿈**(버그 2개도 그대로).

---

## 14. Cursor 시뮬레이션 가이드

### 14.1 노트북에서 켜기
```powershell
cd so4t_kiosk_full_20261123\kiosk
python -m pip install -r requirements.txt
# 학습 모델 없으면:
$env:WHISPER_MODEL = "base"
$env:KIOSK_SERIAL_BRIDGE = "0"      # 아두이노 안 꽂았으면
python -m uvicorn stt_server:app --host 127.0.0.1 --port 8000
# 또는 .\start_kiosk_sim.ps1
```
- **Google Chrome**으로 `http://127.0.0.1:8000/kiosk.html` (파이처럼 보려면 `?pi=1`, 로그 보려면 `?debug=1`)
- 처음 한 번 화면 터치 → 절전 안내 끝난 뒤 **F** = 버튼(주문 시작), **T** = 글자 주문, **U** = 모의 결제 승인, **Ctrl+Shift+P** = 결제 패널.
- 직원 호출 시험: 콘솔 `window.__esp32Call()` (노트북엔 relay가 없어 실패 로그가 정상)
- 버튼 시리얼 흉내: `POST /api/button-command`는 LED 쪽, 버튼 입력은 sim_tools 서버의 `/sim/press` 사용.

### 14.2 자동 시뮬레이터 (`sim_tools/`)
- 필요: `pip install playwright` + Chrome. `CHROME_PATH` 환경변수로 크롬 위치 지정(없으면 Playwright 기본 Chromium).
- `server.py`: 가짜 서버(`/sim/press` = 버튼 누름 흉내). `stub.js`: 가짜 speechSynthesis/음성인식(이벤트 타이밍을 바꿔 파이처럼 늦게 만들 수 있음).
- `slot.py`/`flow.py`/`extras.py` + `t_*.json`: 시나리오 실행, `evalr.py`: 결과 채점. `f_*.json`: 이전 결과.
- 주의: 가짜 TTS/STT라 **버그 1·2가 재현 안 될 수 있음** → stub.js에 실제 파이처럼 "onerror('interrupted') 늦게 보내기", "start만 오고 소리 없음", "Whisper 2~5초 지연", "말 중간 끊김(두 번 나눠 final)"을 넣어서 재현할 것.

### 14.3 Cursor에 그대로 붙여넣을 프롬프트

```
너는 이 저장소(소4트 배리어프리 음성인식 키오스크)의 개발자야. 먼저 KIOSK_FULL_SPEC.md 를 끝까지 읽어.

규칙:
- 기능 삭제 금지. 데이터/숫자 지어내지 말 것. 모르면 '미확인'이라고 써.
- 키오스크 브라우저는 Google Chrome만. 큰 버튼 = 주문 시작(시리얼 WAKE_BUTTON = 키보드 F), 2초 길게 = 직원 호출.
- U = 모의 결제 승인, T = 글자 주문. ESP32-S3는 박스 밖 직원 호출 벨.
- kiosk.html 은 같은 함수를 여러 번 덮어쓰는 구조. 마지막 덮어쓰기와 로드 순서(SPEC 4.1)를 확인하고, 새 패치는 맨 끝(SO4T_FIX_1117 블록 근처)에 최소로 추가해.
- 비밀값 자리표시자(<HOTSPOT_PASSWORD> 등)는 건드리지 마.

최우선 과제 1 (버그 1): 큰 버튼/F로 절전 해제한 뒤 "무엇을 드시고 싶으신가요? …" 주문 시작 안내 TTS가 실제 라즈베리파이에서 안 나옴.
 음성 인식(메뉴판 보여줘/추천해줘)은 됨. 11/17 재시도 패치와 Chrome autoplay 플래그로도 안 고쳐짐.
 - SPEC 10장 버그 1의 코드 위치(forceStartOrderByF 22596~22745, recoveredSmoothSpeakText 24671의 onerror 큐 비우기,
   js/kiosk_pi.js 31~90 pendingTimer, __kioskSleepGate, SO4T_FIX_1117 watchdog/afterWake, kiosk_serial_bridge.js)를 읽고
   원인 후보 1~8을 하나씩 검증해.
 - sim_tools/stub.js 를 고쳐서 파이 speech-dispatcher처럼 (a) cancel 뒤 onerror('interrupted')가 100~600ms 늦게 옴,
   (b) start 이벤트는 오는데 소리/end가 늦음, (c) getVoices()가 처음엔 빈 배열 을 흉내 내고, 버튼 누름(/sim/press)으로 재현해.
 - 원인을 찾으면 왜 그런지 설명 + 최소 수정 + 재현 테스트 통과 + '[kfix1117]' 같은 로그로 파이에서 확인하는 방법을 써.
 - 성공 기준: 버튼 한 번에 안내 문장이 끝까지 정확히 1번 재생, 겹침 없음, 안내 끝나면 바로 인식.

최우선 과제 2 (버그 2): 포스터 예시 "아메리카노 시럽 추가 얼음 적게" 한 문장 주문이 실제 재시험에서 불안정.
 - 경로: needsWhisper(28495) → sendWhisper → routeText(28534) → KIOSK_INTENTS.route → oneshot hookRoute(39433)
   → shouldOneShot(39420) → parse(39225)/lvl(39215) → answerFor(39312) → applyOpts(39303),
   그리고 옵션 기본값 덮어쓰기(kiosk.html 21190 근처 'tempItem.beverageOptions = defaultOpts'), generateDrinkOptions(1936, 커피는 ICE일 때만 얼음).
 - SPEC 10장 버그 2의 원인 후보 1~8을 검증해. 특히 (1) Web Speech가 '아메리카노'만 먼저 확정하는 경우,
   (2) Whisper 늦은 결과가 자동 진행을 끊는 경우, (4) 온도 단계와 얼음 옵션 순서, (5) 기본값 덮어쓰기.
 - T 키 글자 입력으로 먼저 파서/흐름을 시험하고, stub.js로 '두 번 나눠 들어오는 인식', 'Whisper 3초 지연'을 흉내 내서 재현해.
 - sim_tools/t_one.json 에 이 문장(띄어쓰기 변형 '시럽추가 얼음적게', '아메리카노 시럽 추가하고 얼음은 적게', 수량 대답 '한 잔' 포함) 테스트를 추가.
 - 성공 기준: 장바구니에 아메리카노 아이스(ICE), syrup=4, ice=2. 수량/포장처럼 모르는 것만 한 번씩 묻기.

그다음 과제:
 3) sim_tools 전체 시나리오(t_*.json)를 다시 돌려 기존 통과 항목이 깨지지 않았는지 확인(회귀 테스트).
 4) 결제(U 승인/시간 초과/거절), 직원 호출(말/버튼 2초/화면 버튼, 10초 중복 무시), 오프라인 모드 전환, 작별 인사 뒤 절전 흐름을 시뮬레이션하고 표로 결과 정리.
 5) 바꾼 파일·줄, 파이에 옮기는 방법(scp so4t@so4t.local:~/kiosk_project/), 되돌리는 방법을 한국어로 정리.
```

---

## 15. 파이에 반영하는 방법 (참고)
- 노트북 PowerShell: `scp kiosk.html so4t@so4t.local:~/kiosk_project/` → 파이에서 `sudo systemctl restart kiosk-stt` 후 Chrome 재시작(또는 재부팅).
- 바꾸기 전 백업: 파이에서 `cp ~/kiosk_project/kiosk.html ~/kiosk_project/kiosk_backup_$(date +%m%d_%H%M).html`
- 11/17 수정 되돌리기: `bash uninstall_kiosk_fix_1117.sh`.
- **11/23 고침은 `pi_setup/setup_pi_1123.sh` 한 번으로 반영** (16장).

---

## 16. 11/23 고침 (Cursor, 헤드리스 시뮬레이터 기준)

### 16.1 주문 (kiosk.html `SO4T_FIX_1117` 블록 안 한 문장 주문 부분, `pi_setup/kiosk_fix_1117/so4t_fix_1117_block.html` 도 같은 내용)
- 말 끊김: "아메리카노" → (다음 단계에서) "시럽 추가 얼음 적게" → 앞에서 고른 메뉴의 옵션으로 기억하고 이어감. 온도·수량·컵·세트·포장도 같은 방식.
- 조사·꾸밈말: "얼음은 적게", "시럽은 좀 많이", "고기도 많이" 처럼 은/는/이/가/을/를/도/양 + 좀/약간 이 붙어도 옵션으로 읽음.
- 국밥 "고기 많이/적게": `foodOptions.meatAmount` 로 저장, 옵션 글자·주문 내역에 "고기 많이".
- 단계별 주문에서 다른 단계 대답: 온도 질문에 "한 잔", 수량 질문에 "큰 거로 두 개"/"두 개 포장" → 같이 기억.
- 한 문장에 메뉴 2~4개: "돼지국밥 하나랑 콜라 두 개", "아이스 아메리카노 두 잔이랑 따뜻한 카페라떼 한 잔 포장" → 앞 메뉴 담고 다음 메뉴 이어서.
- 온도 단계 없는 음료(에이드 등) "시원하게/따뜻하게" → 아이스/핫으로 담음.
- 옵션 단계·"추가 메뉴 있나요" 단계에서 고른 메뉴의 옵션만 말해도("고기 많이 주세요") 무관 발화로 버리지 않음. 사람에게 하는 말 차단은 그대로 먼저.
- 메뉴판(menu_grid)에서 "불고기 버거": 시뮬에서 정상 동작. 처음 실패로 적은 것은 시험 스크립트가 안내 TTS 중에 말해서 차단된 것(키오스크 설계대로).

### 16.2 안내 문장 (js/kiosk_pi.js)
- cancel 직후 GAP(파이 140ms) 안에 speak 가 두 번 오면 앞 문장이 소리 없이 버려지던 것 → 대기열로 순서대로 말함. 한 문장 주문의 확인 문장("…담았어요/할게요")이 이 때문에 안 들렸음. 10장 버그 1 원인 후보 2와 같은 부분.

### 16.3 메뉴 그림
- `js/kiosk_icons.js`(트위모지 SVG 105개를 파일 안에 넣음) + kiosk.html 그림 함수: 그림 파일을 못 받아도 글자로 바뀌지 않음. 목록에 없는 그림은 접시 그림. `stt_server.py` `_KIOSK_JS` 에 `kiosk_icons.js` 추가.

### 16.4 직원 호출 벨 (선생님 핫스팟)
- 보드(`esp32/so4t_call_sta`)와 파이 중계(`so4t_call_relay.py`)가 UDP 방송으로 서로 찾음(보드→4210, 파이→4211). 호출은 파이→보드 `/call?id=` 와 보드→파이 `:8021/bell` 확인 두 길. 같은 호출 id 는 한 번만 울림, 15초 지난 호출은 안 울림.
- 보드: 핫스팟 비밀번호가 자리표시자면 바로 예비 AP(SO4T-CALL2) → `http://192.168.4.1/setup` 에서 핫스팟 저장 가능. '삑' 1번 = 핫스팟, '삑삑' 2번 = 파이 찾음.
- 파이: 학교 와이파이에 붙어 있어도 핫스팟이 보이면 핫스팟으로 옮김(실패하면 5분 동안 다시 안 옮김). 핫스팟 비밀번호는 설치 중 입력(`SO4T_HOT_PSK` 환경변수도 가능), 파일의 `<HOTSPOT_PASSWORD>` 자리표시자는 그대로.
- 스케치 컴파일: ESP32 코어 2.0.17 / 3.0.7 / 4.0.0 모두 통과 (ESP32S3 Dev Module).

### 16.5 시험 결과와 미확인
- 확인 말을 이미 한 뒤, 손님이 "아니요"처럼 새로 더한 내용이 없는 답을 하면 그 확인 말을 다시 하지 않음.
- 시뮬레이터(헤드리스 Chrome, 글자 입력) 다시 돌린 결과: `t_fix1123` 23/23, `t_one` 41/41, `t_oneA` 21/21, `t_oneB` 20/20, `t_poster` 6/6. 단계만 보는 `t_cs` `t_base` `t_am` `t_check_grid` `t_extra_now` 도 페이지 오류 없이 통과. 큰 버튼 절전 해제 뒤 "무엇을 드시고 싶으신가요" 안내가 끝까지 1번 재생(시뮬). 카드 승인(U)·20초 무응답("카드가 확인되지 않았어요")·결제 실패 후 다시·감사 인사 뒤 절전·직원 호출(잠든 중/주문 중)도 동작.
- 직원 호출: 가짜 보드(`sim_tools/fake_esp32.py`)+실제 중계 코드로 말/버튼 → 부저 켜짐, 파이→보드 직접 길을 막아도 `/bell` 길로 울림, 중계·보드 재시작 뒤 잘못 울림 없음.
- **미확인**: 실제 파이·ESP32 보드·선생님 폰 핫스팟에서 시험 안 함. 폰 핫스팟이 기기끼리 통신/방송을 막는지 미확인(막히면 중계가 60초마다 `so4t_call.sh find` 로 찾음). 버그 1(실제 파이에서 주문 시작 안내 안 들림)이 16.2로 해결됐는지 미확인. Whisper 실제 음성 인식(시뮬은 글자 입력).
