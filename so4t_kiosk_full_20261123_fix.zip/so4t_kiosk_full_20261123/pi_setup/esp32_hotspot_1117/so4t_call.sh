#!/bin/bash
# 소4트 직원 호출 보드(ESP32-S3) 찾기/호출   사용: so4t_call.sh call|stop|find|ping
#  찾는 순서: (wlan1 있으면) 192.168.4.1 → 저장된 IP → so4t-call.local(mDNS) → wlan0 같은 대역 /24 전체 스캔
#  찾은 IP 는 ~/.so4t_esp32_ip 와 /tmp/so4t_esp32_ip 에 저장
CMD="${1:-call}"
CACHE_HOME="${SO4T_ESP_CACHE:-$HOME/.so4t_esp32_ip}"
CACHE_TMP=/tmp/so4t_esp32_ip
WIF="${SO4T_WIFI_IF:-wlan0}"

is_board() { # ip [iface]  → /ping 이 ok 면 0
  local r
  if [ -n "${2:-}" ]; then r=$(curl -s --interface "$2" -m "${T:-1}" "http://$1/ping" 2>/dev/null)
  else r=$(curl -s -m "${T:-1}" "http://$1/ping" 2>/dev/null); fi
  [ "$r" = "ok" ]
}
save() { echo "$1" > "$CACHE_HOME" 2>/dev/null; echo "$1" > "$CACHE_TMP" 2>/dev/null; chmod 666 "$CACHE_TMP" 2>/dev/null; true; }

find_board() { # 출력: "ip iface" (iface 비면 기본 경로)
  local ip c base self
  # 1) wlan1(USB 동글) 예전 방식
  if ip link show wlan1 >/dev/null 2>&1 && T=1 is_board 192.168.4.1 wlan1; then echo "192.168.4.1 wlan1"; return 0; fi
  # 2) 저장된 IP
  for c in "$CACHE_TMP" "$CACHE_HOME"; do
    ip=$(head -n1 "$c" 2>/dev/null | tr -dc '0-9.')
    if [ -n "$ip" ] && T=1 is_board "$ip"; then save "$ip"; echo "$ip"; return 0; fi
  done
  # 3) mDNS
  ip=$(getent ahostsv4 so4t-call.local 2>/dev/null | awk 'NR==1{print $1}')
  [ -z "$ip" ] && command -v avahi-resolve >/dev/null 2>&1 && \
    ip=$(timeout 3 avahi-resolve -4 -n so4t-call.local 2>/dev/null | awk '{print $2}')
  if [ -n "$ip" ] && T=1 is_board "$ip"; then save "$ip"; echo "$ip"; return 0; fi
  # 4) 예전 AP 에 wlan0 가 직접 붙어 있는 경우
  if ip -4 route 2>/dev/null | grep -q '^192\.168\.4\.0/24' && T=1 is_board 192.168.4.1; then save 192.168.4.1; echo "192.168.4.1"; return 0; fi
  # 5) wlan0 대역 스캔 (/24, 병렬)
  self=$(ip -4 -o addr show "$WIF" 2>/dev/null | awk '{print $4}' | head -n1 | cut -d/ -f1)
  [ -z "$self" ] && return 1
  base=${self%.*}
  local tmp; tmp=$(mktemp -d)
  for i in $(seq 1 254); do
    c="$base.$i"; [ "$c" = "$self" ] && continue
    ( r=$(curl -s -m 0.6 "http://$c/ping" 2>/dev/null); [ "$r" = "ok" ] && echo "$c" > "$tmp/hit.$i" ) &
    # 동시 64개까지
    if (( i % 64 == 0 )); then wait; ls "$tmp"/hit.* >/dev/null 2>&1 && break; fi
  done
  wait
  ip=$(cat "$tmp"/hit.* 2>/dev/null | head -n1); rm -rf "$tmp"
  if [ -n "$ip" ]; then save "$ip"; echo "$ip"; return 0; fi
  return 1
}

case "$CMD" in
  find|ping)
    if R=$(find_board); then echo "ESP32 찾음: $R"; exit 0; else echo "ESP32 못 찾음 (보드 전원/핫스팟 확인)"; exit 1; fi ;;
  call|stop)
    if R=$(find_board); then
      read -r ip ifc <<<"$R"
      if [ -n "$ifc" ]; then out=$(curl -s --interface "$ifc" -m 3 "http://$ip/$CMD")
      else out=$(curl -s -m 3 "http://$ip/$CMD"); fi
      echo "$CMD → $ip ${ifc:+($ifc)}: ${out:-응답없음}"
      [ -n "$out" ] && exit 0
      rm -f "$CACHE_TMP"; exit 1
    else echo "ESP32 못 찾음 (보드 전원/핫스팟 확인)"; exit 1; fi ;;
  *) echo "사용: $0 call|stop|find"; exit 2 ;;
esac
