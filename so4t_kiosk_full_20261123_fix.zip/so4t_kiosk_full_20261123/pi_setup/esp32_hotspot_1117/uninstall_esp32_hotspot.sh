#!/bin/bash
# 소4트 ESP32 핫스팟 방식 제거 → 예전(192.168.4.1 직접) 방식으로 되돌림
set -uo pipefail
K="${KIOSK_DIR:-$HOME/kiosk_project}"; BK="$HOME/esp32_hotspot_backup"
sudo systemctl disable --now so4t-call-relay.service >/dev/null 2>&1
sudo rm -f /etc/systemd/system/so4t-call-relay.service; sudo systemctl daemon-reload
for f in "$K/static/esp32_call.js" "$K/js/esp32_call.js" /usr/local/bin/so4t_call; do
  b="$BK/$(echo "$f" | tr '/' '_')"
  if [ -f "$b" ]; then sudo rm -f "$f"; sudo cp -a "$b" "$f"; echo "복구: $f"; fi
done
# 이 설치가 추가한 태그 줄만 제거
[ -f "$K/kiosk.html" ] && grep -q 'SO4T-ESP32-HOTSPOT' "$K/kiosk.html" && \
  python3 - "$K/kiosk.html" <<'PY2' && echo "kiosk.html 태그 제거"
import sys
p=sys.argv[1]; tag='<script src="/static/esp32_call.js"></script><!-- SO4T-ESP32-HOTSPOT -->\n'
s=open(p,encoding="utf-8").read(); open(p,"w",encoding="utf-8").write(s.replace(tag,"").replace(tag.strip(),""))
PY2
rm -f "$HOME/.so4t_call_relay.py" /tmp/so4t_esp32_ip
echo "제거 완료 (~/so4t_call.sh 는 남겨 둠). sudo reboot"
