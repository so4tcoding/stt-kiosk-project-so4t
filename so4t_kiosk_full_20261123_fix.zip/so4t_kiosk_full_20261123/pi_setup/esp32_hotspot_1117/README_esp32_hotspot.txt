소4트 직원 호출 보드(ESP32-S3) - 대회 핫스팟 방식 (2026-11-23 갱신)

보드와 파이가 같은 핫스팟에 붙으면 서로 자동으로 찾음:
  보드 → 2초마다 UDP 4210 "SO4T-CALL <ip>"   /   파이 → 2초마다 UDP 4211 "SO4T-PI"
호출은 두 길로 감 (둘 중 하나만 돼도 부저 울림):
  1) 파이 → http://<보드>/call   2) 보드가 1초마다 http://<파이>:8021/bell 확인

[1] ESP32 에 새 스케치 올리기 (노트북 Arduino IDE)
  - esp32/so4t_call_sta/so4t_call_sta.ino 열기
  - HOT_PASS 줄의 <HOTSPOT_PASSWORD> 를 핫스팟 비밀번호로 직접 바꾸기 (팀 내부에서만, 채팅에 붙여넣지 말 것)
    AP_PASS 줄의 <ESP32_AP_PASSWORD> 는 예비 와이파이 비밀번호(8자 이상)
  - 보드: ESP32S3 Dev Module / 포트: ESP32 COM 포트
  - (시리얼 모니터에 글이 안 보이면) Tools > USB CDC On Boot: Enabled
  - 업로드 → 시리얼 모니터 115200: "핫스팟 접속 OK ... IP=..." + '삑' 1번 → "파이 찾음" + '삑삑' 2번
  - 폰 핫스팟은 2.4GHz(또는 '호환성 최대화'), 보안 WPA2 (ESP32 는 5GHz 못 잡음)

[1-2] 스케치를 다시 올리지 않고 핫스팟 바꾸기
  - 보드가 30초 안에 핫스팟을 못 찾으면 예비 와이파이 SO4T-CALL2 를 켬
    (HOT_PASS 가 자리표시자 그대로면 바로 켬)
  - 폰을 SO4T-CALL2 에 연결(비밀번호 = AP_PASS 값) → 브라우저 http://192.168.4.1/setup
  - 핫스팟 이름/비밀번호 입력 → 저장 → 보드가 다시 시작하고 그 핫스팟에 붙음 (보드에 저장됨)
  - 지우기: http://192.168.4.1/forget

[2] 파이 설치: pi_setup/README_setup_pi_1123.txt (setup_pi_1123.sh 한 번 실행)
    이 폴더만 따로 설치: bash install_esp32_hotspot.sh && sudo reboot

[3] 테스트 (파이)
  curl -s 127.0.0.1:8020/status   → board=192.168.x.x (beacon/poll, 몇 초 전)
  curl -s 127.0.0.1:8020/call     → 부저 울림
  curl -s 127.0.0.1:8020/stop     → 멈춤 (보드의 끄기 버튼 IO6 로도 멈춤)
  bash ~/so4t_call.sh find / call / stop   (예전 방법도 그대로 됨)
  키오스크 화면에서 직원 호출 → 부저 울림

[보드 상태]
  '삑' 1번 = 핫스팟 접속, '삑삑' 2번 = 파이 찾음
  LED(IO7): 1초마다 깜빡 = 핫스팟 못 찾음, 3초마다 짧게 = 파이 못 찾음, 꺼짐 = 다 됨

[되돌리기] bash ~/uninstall_esp32_hotspot.sh && sudo reboot
