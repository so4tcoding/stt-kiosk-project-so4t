#!/usr/bin/env python3
# 소4트 직원 호출 중계 v3 (127.0.0.1:8020) - SO4T-ESP32-HOTSPOT (2026-11-23)
# 키오스크 화면(브라우저)은 ESP32 IP 를 모르므로 여기로 보내면 보드에 전달.
#   GET /call  /stop  → 바로 "queued" 응답, 뒤에서 보드로 전달
#   GET /find  /status → 현재 찾은 IP / 상태
# 보드 찾기 (핫스팟에서 IP 가 바뀌어도 됨)
#   - 보드가 2초마다 UDP 4210 으로 "SO4T-CALL <ip>" 방송 → 들은 IP 저장
#   - 이 중계가 2초마다 UDP 4211 로 "SO4T-PI" 방송 → 보드가 파이 IP 를 알게 됨
#   - 보드가 1초마다 http://<파이>:8021/bell 확인 → 새 호출이면 보드가 스스로 울림 (파이→보드 길이 막혀도 동작)
#   - 그래도 모르면 so4t_call.sh (저장된 IP → mDNS → 대역 스캔)
import os, socket, subprocess, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SH = os.path.expanduser("~/so4t_call.sh")
CACHE = [os.path.expanduser("~/.so4t_esp32_ip"), "/tmp/so4t_esp32_ip"]
LOCAL_PORT = int(os.environ.get("SO4T_RELAY_PORT", "8020"))
BELL_PORT = int(os.environ.get("SO4T_BELL_PORT", "8021"))
BEACON_PORT = int(os.environ.get("SO4T_BEACON_PORT", "4210"))   # 보드 → 파이
PI_PORT = int(os.environ.get("SO4T_PI_PORT", "4211"))           # 파이 → 보드
lock = threading.Lock()
state = {"last": "", "at": 0, "board": "", "board_seen": 0, "board_how": "", "poll_seen": 0,
         "call_id": "0", "call_at": 0}

def log(*a):
    print("[relay]", *a, flush=True)

def read_cache():
    for p in CACHE:
        try:
            ip = open(p).read().strip().split()[0]
            if ip.count(".") == 3:
                return ip
        except Exception:
            pass
    return ""

def save_board(ip, how):
    if not ip or ip.startswith("127."):
        return
    changed = ip != state["board"]
    state["board"] = ip; state["board_seen"] = time.time(); state["board_how"] = how
    if changed:
        for p in CACHE:
            try:
                with open(p, "w") as f:
                    f.write(ip + "\n")
                if p.startswith("/tmp/"):
                    os.chmod(p, 0o666)
            except Exception:
                pass
        log("보드 IP %s (%s)" % (ip, how))

def push(cmd, ip):
    url = "http://%s/%s?id=%s&src=relay" % (ip, cmd, state["call_id"])
    try:
        with urllib.request.urlopen(url, timeout=1.5) as r:
            return (r.read(64).decode("utf-8", "ignore").strip() or "응답없음")
    except Exception:
        return None

def run_sh(cmd, timeout=15):
    with lock:
        try:
            r = subprocess.run(["bash", SH, cmd], capture_output=True, text=True, timeout=timeout)
            out = (r.stdout or r.stderr).strip()
        except Exception as e:
            out = "error: %s" % e
        state["last"] = out; state["at"] = time.time()
        log("%s → %s" % (cmd, out))
        found = ("ESP32 찾음" in out) or (out.startswith(("call →", "stop →")) and "응답없음" not in out)
        ip = read_cache()
        if ip and found:
            save_board(ip, "scan")
        return out

def do_cmd(cmd):
    if cmd == "call":
        state["call_id"] = str(int(time.time() * 1000)); state["call_at"] = time.time()
    else:
        state["call_at"] = 0
    ip = state["board"] or read_cache()
    out = push(cmd, ip) if ip else None
    if out:
        state["last"] = "%s → %s: %s" % (cmd, ip, out); state["at"] = time.time()
        log(state["last"])
        return
    if cmd == "call" and time.time() - state["poll_seen"] < 5:
        log("보드가 /bell 로 확인 중 → 보드가 스스로 울림 (직접 전달 실패: %s)" % (ip or "IP 모름"))
    run_sh(cmd)

def listen_beacons():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("0.0.0.0", BEACON_PORT))
            while True:
                data, addr = s.recvfrom(128)
                if data.startswith(b"SO4T-CALL"):
                    save_board(addr[0], "beacon")
        except Exception as e:
            log("UDP 듣기 오류 (5초 뒤 다시):", e)
            time.sleep(5)

def broadcast_targets():
    t = {"255.255.255.255"}
    try:
        out = subprocess.run(["ip", "-4", "-o", "addr", "show"], capture_output=True, text=True, timeout=3).stdout
        for line in out.splitlines():
            parts = line.split()
            if "brd" in parts and not parts[1].startswith("lo"):
                t.add(parts[parts.index("brd") + 1])
    except Exception:
        pass
    return t

def send_beacons():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    n = 0
    targets = broadcast_targets()
    while True:
        if n % 5 == 0:
            targets = broadcast_targets()
        msg = ("SO4T-PI %d" % BELL_PORT).encode()
        for ip in list(targets) + ([state["board"]] if state["board"] else []):
            try:
                s.sendto(msg, (ip, PI_PORT))
            except Exception:
                pass
        n += 1
        time.sleep(2)

def warm():
    time.sleep(5)
    while True:
        if time.time() - max(state["board_seen"], state["poll_seen"]) > 30:
            run_sh("find")
        time.sleep(60)

def status_text():
    now = time.time()
    def ago(t): return ("%ds 전" % (now - t)) if t else "없음"
    return ("board=%s (%s, %s)\nboard_poll=%s\ncall_id=%s call=%s\nlast=%s\n" %
            (state["board"] or "unknown", state["board_how"] or "-", ago(state["board_seen"]),
             ago(state["poll_seen"]), state["call_id"], ago(state["call_at"]), state["last"] or "-"))

class Base(BaseHTTPRequestHandler):
    def _send(self, code, msg):
        b = msg.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self):
        self._send(204, "")
    def bell(self):
        state["poll_seen"] = time.time()
        save_board(self.client_address[0], "poll")
        age = int(time.time() - state["call_at"]) if state["call_at"] else -1
        self._send(200, "id=%s age=%d" % (state["call_id"], age))
    def log_message(self, *a): pass

class Local(Base):
    def do_GET(self):
        p = self.path.split("?")[0].strip("/")
        if p in ("call", "stop"):
            threading.Thread(target=do_cmd, args=(p,), daemon=True).start()
            self._send(200, "queued " + p)
        elif p == "find":
            run_sh("find"); self._send(200, status_text())
        elif p == "status":
            self._send(200, status_text())
        elif p == "bell":
            self.bell()
        elif p == "ping":
            self._send(200, "relay ok")
        else:
            self._send(404, "use /call /stop /find /status")

class Lan(Base):
    def do_GET(self):
        p = self.path.split("?")[0].strip("/")
        if p == "bell":
            self.bell()
        elif p == "ping":
            self._send(200, "relay ok")
        else:
            self._send(404, "bell only")

def serve(addr, handler):
    while True:
        try:
            ThreadingHTTPServer(addr, handler).serve_forever()
        except Exception as e:
            log("HTTP %s 오류 (5초 뒤 다시): %s" % (addr, e))
            time.sleep(5)

if __name__ == "__main__":
    b = read_cache()
    if b:
        state["board"] = b; state["board_how"] = "cache"
    for fn in (listen_beacons, send_beacons, warm):
        threading.Thread(target=fn, daemon=True).start()
    threading.Thread(target=serve, args=(("0.0.0.0", BELL_PORT), Lan), daemon=True).start()
    log("시작: 화면 127.0.0.1:%d, 보드 확인 :%d/bell, UDP 듣기 %d, 방송 %d" % (LOCAL_PORT, BELL_PORT, BEACON_PORT, PI_PORT))
    serve(("127.0.0.1", LOCAL_PORT), Local)
