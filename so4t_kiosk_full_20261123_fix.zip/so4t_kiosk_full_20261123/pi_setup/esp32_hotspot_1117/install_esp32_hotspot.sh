#!/bin/bash
# 소4트 ESP32 직원 호출 보드 - 대회 핫스팟(wlan0) 방식 설치 (SO4T-ESP32-HOTSPOT)
# 실행: cd ~ && python3 -m zipfile -e esp32_hotspot_1117.zip . && bash install_esp32_hotspot.sh
# 여러 번 실행해도 됨. kiosk.html 본문은 건드리지 않음(스크립트 태그 없을 때만 한 줄 추가).
set -uo pipefail
D="$(cd "$(dirname "$0")" && pwd)"
K="${KIOSK_DIR:-$HOME/kiosk_project}"
H="$K/kiosk.html"
TS=$(date +%Y%m%d_%H%M%S)
U="$(id -un)"
BK="$HOME/esp32_hotspot_backup"
echo "== 소4트 ESP32 핫스팟 방식 설치 ($TS) =="
for f in so4t_call.sh so4t_call_relay.py esp32_call.js; do
  [ -f "$D/$f" ] || { echo "ERROR: $D/$f 없음 (zip 을 ~ 에 풀었는지 확인)"; exit 1; }
done
sudo -v || { echo "ERROR: sudo 필요"; exit 1; }

# 1) 백업 (처음 한 번만 원본 보관)
mkdir -p "$BK"
for f in "$K/static/esp32_call.js" "$K/js/esp32_call.js" /usr/local/bin/so4t_call; do
  b="$BK/$(echo "$f" | tr '/' '_')"
  [ -f "$f" ] && [ ! -f "$b" ] && cp -a "$f" "$b"
done
echo "  백업: $BK"

# 2) 스크립트 설치
[ "$D/so4t_call.sh" != "$HOME/so4t_call.sh" ] && cp "$D/so4t_call.sh" "$HOME/so4t_call.sh"
chmod 755 "$HOME/so4t_call.sh"
install -m 755 "$D/so4t_call_relay.py" "$HOME/.so4t_call_relay.py"
sudo ln -sf "$HOME/so4t_call.sh" /usr/local/bin/so4t_call
echo "  ~/so4t_call.sh 설치 (so4t_call 명령으로도 실행 가능)"

# 3) 키오스크 화면 JS 교체 (원래 함수는 그대로, 신호만 중계로)
if [ -f "$H" ]; then
  mkdir -p "$K/static" "$K/js"
  cp "$D/esp32_call.js" "$K/static/esp32_call.js"
  cp "$D/esp32_call.js" "$K/js/esp32_call.js"
  if grep -q 'esp32_call.js' "$H"; then
    echo "  kiosk.html 에 esp32_call.js 태그 이미 있음 → 그대로 둠"
  else
    cp "$H" "$H.bak_esp32hs_$TS"
    python3 - "$H" <<'PY'
import sys
p=sys.argv[1]; tag='<script src="/static/esp32_call.js"></script><!-- SO4T-ESP32-HOTSPOT -->'
s=open(p,encoding="utf-8").read()
if "esp32_call.js" not in s:
    i=s.rfind("</body>")
    s=s[:i]+tag+"\n"+s[i:] if i>=0 else s+"\n"+tag+"\n"
    open(p,"w",encoding="utf-8").write(s)
PY
    echo "  kiosk.html 에 스크립트 태그 한 줄 추가 (백업 $H.bak_esp32hs_$TS)"
  fi
else
  echo "  경고: $H 없음 → 화면 연동은 건너뜀 (터미널 so4t_call.sh 는 사용 가능)"
fi

# 4) 중계 서비스 (127.0.0.1:8020, 부팅 시 자동, 60초마다 보드 IP 갱신)
sudo tee /etc/systemd/system/so4t-call-relay.service >/dev/null <<UNIT
[Unit]
Description=SO4T staff-call relay to ESP32 board over hotspot (SO4T-ESP32-HOTSPOT)
After=network-online.target NetworkManager.service
Wants=network-online.target

[Service]
User=$U
Environment=HOME=$HOME
ExecStart=/usr/bin/python3 $HOME/.so4t_call_relay.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable so4t-call-relay.service >/dev/null 2>&1
sudo systemctl restart so4t-call-relay.service
echo "  so4t-call-relay.service 켬"

# 5) mDNS(so4t-call.local) 확인 - 없어도 대역 스캔으로 찾음
systemctl is-active avahi-daemon >/dev/null 2>&1 && echo "  avahi(mDNS) 동작 중" || echo "  avahi 꺼짐 → IP 스캔으로 찾음"

# 6) 옛 동글용 서비스: 동글 없으면 대기 메시지만 한 번 찍음(그대로 둠)
echo
echo "== 지금 보드 찾기 시도 =="
bash "$HOME/so4t_call.sh" find || echo "  (보드에 새 스케치 업로드 + 핫스팟 켠 뒤 다시: bash ~/so4t_call.sh find)"
echo
echo "완료! 화면 반영하려면: sudo reboot"
