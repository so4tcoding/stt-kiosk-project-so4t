so4t Wi-Fi persist (Pi NetworkManager)
======================================
Goal: stop wlan0 dropping during kiosk tests. Prefer school Wi-Fi, then phone
hotspot. Never force the ESP32 staff-call AP (so4t-call / SO4T-CALL*) as the
default internet route. Does NOT invent or change Wi-Fi passwords — only tunes
existing NetworkManager connections.

Install (from laptop PowerShell, then Pi SSH)
---------------------------------------------
scp C:\Users\User\Desktop\wifi_persist.zip so4t@so4t.local:~/

cd ~ && rm -rf wifi_persist && unzip -o wifi_persist.zip -d wifi_persist && cd wifi_persist && bash install_wifi_persist.sh

What it does
------------
1) Backs up NM conf + keyfiles under ~/wifi_persist_backup_<timestamp>
2) Writes /etc/NetworkManager/conf.d/99-wifi-powersave.conf (wifi.powersave=2)
3) If connection "yc_yc_hs_P 1" exists: autoconnect yes, priority 20, retries 0
4) If connection "hotspot" exists: autoconnect yes, priority 10, retries 0
5) Any so4t-call / SO4T-CALL* connections: never-default + low/no autoconnect
6) Optional timer: every 60s soft-reconnect if wlan0 not connected (school then hotspot)

You must confirm
----------------
- School NM connection is named exactly: yc_yc_hs_P 1
  (if missing, install prints existing Wi-Fi names — tell us the real name)
- Phone hotspot NM connection is named: hotspot (optional; skipped if absent)
- Passwords/usernames already saved in NM — we will not ask for or invent any

Uninstall
---------
bash uninstall_wifi_persist.sh
