#!/bin/bash
# Install so4t Wi-Fi persist: powersave off, school > hotspot priority, never default via so4t-call.
set -euo pipefail
D="$(cd "$(dirname "$0")" && pwd)"
TS=$(date +%Y%m%d_%H%M%S)
BK=~/wifi_persist_backup_$TS
mkdir -p "$BK"
SCHOOL='yc_yc_hs_P 1'
HOTSPOT='hotspot'
NM_CONF_D=/etc/NetworkManager/conf.d
NM_CONF="$NM_CONF_D/99-wifi-powersave.conf"
SYS_UNIT_D=/etc/systemd/system

need_sudo() {
  if [ "$(id -u)" -eq 0 ]; then
    "$@"
  else
    sudo "$@"
  fi
}

echo "== backup =="
mkdir -p "$BK/nm-conf.d" "$BK/system-connections" "$BK/systemd"
if [ -d "$NM_CONF_D" ]; then
  need_sudo cp -a "$NM_CONF_D/." "$BK/nm-conf.d/" 2>/dev/null || true
fi
if [ -d /etc/NetworkManager/system-connections ]; then
  need_sudo cp -a /etc/NetworkManager/system-connections/. "$BK/system-connections/" 2>/dev/null || true
  need_sudo chown -R "$(id -u):$(id -g)" "$BK/system-connections" 2>/dev/null || true
fi
for u in wifi-persist-reconnect.service wifi-persist-reconnect.timer; do
  [ -f "$SYS_UNIT_D/$u" ] && need_sudo cp -a "$SYS_UNIT_D/$u" "$BK/systemd/" || true
done
echo "$BK" > ~/.wifi_persist_last_backup
echo "backup: $BK"

if ! command -v nmcli >/dev/null 2>&1; then
  echo "ERROR: nmcli not found. Install NetworkManager first." >&2
  exit 1
fi

echo "== NetworkManager wifi.powersave=2 =="
need_sudo mkdir -p "$NM_CONF_D"
need_sudo install -m 644 "$D/99-wifi-powersave.conf" "$NM_CONF"
# Also stamp existing wifi connections (does not change secrets)
while IFS= read -r name; do
  [ -z "$name" ] && continue
  TYPE=$(nmcli -g connection.type connection show id "$name" 2>/dev/null || true)
  [ "$TYPE" = "802-11-wireless" ] || continue
  nmcli connection modify id "$name" 802-11-wireless.powersave 2 2>/dev/null \
    || need_sudo nmcli connection modify id "$name" 802-11-wireless.powersave 2 2>/dev/null \
    || true
done < <(nmcli -t -f NAME connection show)

need_sudo nmcli general reload || need_sudo systemctl reload NetworkManager || true

# Live iface powersave off
IFACE=$(nmcli -t -f DEVICE,TYPE device status | awk -F: '$2=="wifi"{print $1; exit}')
IFACE=${IFACE:-wlan0}
if command -v iw >/dev/null 2>&1; then
  need_sudo iw dev "$IFACE" set power_save off 2>/dev/null || true
fi

mod_conn() {
  # mod_conn NAME PRIORITY
  local name="$1" prio="$2"
  if ! nmcli -t -f NAME connection show | grep -Fxq -- "$name"; then
    echo "MISSING: connection '$name' — skipped (will not invent password/SSID)"
    return 1
  fi
  echo "configure: '$name' autoconnect=yes priority=$prio retries=0"
  need_sudo nmcli connection modify id "$name" \
    connection.autoconnect yes \
    connection.autoconnect-priority "$prio" \
    connection.autoconnect-retries 0 \
    802-11-wireless.powersave 2 \
    ipv4.route-metric 100 \
    ipv6.route-metric 100 \
    ipv4.never-default no \
    ipv6.never-default no
  return 0
}

echo "== preferred connections =="
SCHOOL_OK=0
HOTSPOT_OK=0
mod_conn "$SCHOOL" 20 && SCHOOL_OK=1 || true
mod_conn "$HOTSPOT" 10 && HOTSPOT_OK=1 || true

echo "== demote staff-call / ESP32 APs (never default internet) =="
while IFS= read -r name; do
  [ -z "$name" ] && continue
  echo "$name" | grep -qiE 'so4t-call|SO4T-CALL|so4t_call|esp32' || continue
  TYPE=$(nmcli -g connection.type connection show id "$name" 2>/dev/null || true)
  [ "$TYPE" = "802-11-wireless" ] || continue
  echo "demote: '$name' (autoconnect no / never-default / low priority)"
  need_sudo nmcli connection modify id "$name" \
    connection.autoconnect no \
    connection.autoconnect-priority -100 \
    ipv4.never-default yes \
    ipv6.never-default yes \
    ipv4.route-metric 900 \
    ipv6.route-metric 900 || true
done < <(nmcli -t -f NAME connection show)

echo "== reconnect oneshot + timer =="
mkdir -p ~/.local/bin
install -m 755 "$D/wifi_reconnect.sh" ~/.local/bin/wifi_reconnect.sh
# service ExecStart points at /home/so4t/.local/bin — rewrite if user home differs
HOME_BIN="$HOME/.local/bin/wifi_reconnect.sh"
TMP_SVC=$(mktemp)
sed "s|/home/so4t/.local/bin/wifi_reconnect.sh|$HOME_BIN|g" \
  "$D/wifi-persist-reconnect.service" > "$TMP_SVC"
need_sudo install -m 644 "$TMP_SVC" "$SYS_UNIT_D/wifi-persist-reconnect.service"
need_sudo install -m 644 "$D/wifi-persist-reconnect.timer" "$SYS_UNIT_D/wifi-persist-reconnect.timer"
rm -f "$TMP_SVC"
need_sudo systemctl daemon-reload
need_sudo systemctl enable --now wifi-persist-reconnect.timer

echo
echo "== status =="
echo "--- wifi devices ---"
nmcli -t -f DEVICE,STATE,CONNECTION device | grep -E 'wifi|wlan' || nmcli device status
echo "--- wifi connections (name / autoconnect / priority) ---"
while IFS= read -r name; do
  [ -z "$name" ] && continue
  TYPE=$(nmcli -g connection.type connection show id "$name" 2>/dev/null || true)
  [ "$TYPE" = "802-11-wireless" ] || continue
  AC=$(nmcli -g connection.autoconnect connection show id "$name" 2>/dev/null || echo '?')
  PR=$(nmcli -g connection.autoconnect-priority connection show id "$name" 2>/dev/null || echo '?')
  echo "  $name | autoconnect=$AC | priority=$PR"
done < <(nmcli -t -f NAME connection show)
echo "--- powersave conf ---"
need_sudo cat "$NM_CONF" || true
echo "--- timer ---"
systemctl is-enabled wifi-persist-reconnect.timer 2>/dev/null || true
systemctl is-active wifi-persist-reconnect.timer 2>/dev/null || true

echo
if [ "$SCHOOL_OK" -eq 1 ]; then
  echo "OK: school '$SCHOOL' configured (priority 20)."
else
  echo "ACTION NEEDED: school connection '$SCHOOL' was NOT found."
  echo "  Existing Wi-Fi connection names are listed above."
  echo "  Confirm the exact NM name (and that the password is already saved)."
  echo "  Do NOT paste a new password into chat unless you want us to add a new profile."
fi
if [ "$HOTSPOT_OK" -eq 1 ]; then
  echo "OK: hotspot '$HOTSPOT' configured (priority 10)."
else
  echo "NOTE: connection '$HOTSPOT' not found — skipped (optional)."
  echo "  If your phone hotspot profile has another name, tell us that exact name."
fi
echo "Backup: $BK"
echo "Done. Optional: reboot once, or run: nmcli connection up id '$SCHOOL'"
