#!/bin/bash
set -euo pipefail
need_sudo() {
  if [ "$(id -u)" -eq 0 ]; then "$@"
  else sudo "$@"; fi
}
BK=$(cat ~/.wifi_persist_last_backup 2>/dev/null || true)
echo "last backup marker: ${BK:-none}"

need_sudo systemctl disable --now wifi-persist-reconnect.timer 2>/dev/null || true
need_sudo rm -f /etc/systemd/system/wifi-persist-reconnect.timer \
  /etc/systemd/system/wifi-persist-reconnect.service
need_sudo systemctl daemon-reload 2>/dev/null || true
need_sudo rm -f /etc/NetworkManager/conf.d/99-wifi-powersave.conf
rm -f ~/.local/bin/wifi_reconnect.sh

if [ -n "${BK:-}" ] && [ -d "$BK/nm-conf.d" ]; then
  echo "Restoring NM conf.d from $BK/nm-conf.d (manual system-connections restore if needed)"
  # only restore our powersave file removal already done; user can copy keyfiles back with sudo
fi
need_sudo nmcli general reload 2>/dev/null || true
echo "Uninstalled timer + powersave conf. Connection priority/never-default edits were left as-is;"
echo "restore from $BK/system-connections with sudo if you need the previous keyfiles."
