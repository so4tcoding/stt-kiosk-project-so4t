#!/bin/bash
# Soft reconnect for so4t Pi: prefer school Wi-Fi, then phone hotspot. Never default via so4t-call/ESP32.
set -u
LOG=/tmp/wifi_persist_reconnect.log
exec >>"$LOG" 2>&1
echo "==== $(date '+%Y-%m-%d %H:%M:%S %z') ===="

SCHOOL='yc_yc_hs_P 1'
HOTSPOT='hotspot'
IFACE="${WIFI_IFACE:-wlan0}"

# Keep power save off even if NM briefly re-enables it
if command -v iw >/dev/null 2>&1; then
  iw dev "$IFACE" set power_save off 2>/dev/null || true
fi
if command -v nmcli >/dev/null 2>&1; then
  nmcli general reload 2>/dev/null || true
fi

STATE=$(nmcli -t -f DEVICE,STATE device 2>/dev/null | awk -F: -v d="$IFACE" '$1==d{print $2; exit}')
CONN=$(nmcli -t -f DEVICE,CONNECTION device 2>/dev/null | awk -F: -v d="$IFACE" '$1==d{print $2; exit}')
echo "iface=$IFACE state=${STATE:-?} conn=${CONN:-?}"

# If already connected to school or hotspot, leave it alone
case "${CONN}" in
  "$SCHOOL"|"$HOTSPOT")
    # Still verify we have a default route; if not, bounce preferred connection
    if ip route show default | grep -q .; then
      echo "ok: already on preferred connection with default route"
      exit 0
    fi
    echo "warn: preferred connection up but no default route; will re-up"
    ;;
esac

# Detect ESP32 / staff-call style connections (never use as internet default)
is_call_conn() {
  local n="$1"
  echo "$n" | grep -qiE 'so4t-call|SO4T-CALL|so4t_call|esp32'
}

# If currently stuck on a call AP as the only uplink, do not promote it; try school/hotspot instead
if [ -n "${CONN}" ] && [ "${CONN}" != "--" ] && is_call_conn "$CONN"; then
  echo "info: current connection looks like staff-call AP ($CONN); not using as default"
fi

need=0
if [ "${STATE}" != "connected" ]; then
  need=1
elif ! ip route show default | grep -q .; then
  need=1
fi

if [ "$need" -eq 0 ]; then
  # Connected to something else (not school/hotspot) with a route — leave alone unless it's call AP without preferred available
  if is_call_conn "${CONN}"; then
    need=1
  else
    echo "ok: connected ($CONN), no action"
    exit 0
  fi
fi

try_up() {
  local id="$1"
  if nmcli -t -f NAME connection show 2>/dev/null | grep -Fxq -- "$id"; then
    echo "trying: nmcli connection up id '$id'"
    if nmcli connection up id "$id"; then
      echo "success: $id"
      return 0
    fi
    echo "fail: $id"
  else
    echo "skip: connection '$id' not found"
  fi
  return 1
}

try_up "$SCHOOL" && exit 0
try_up "$HOTSPOT" && exit 0
echo "warn: could not bring up school or hotspot; leaving NM alone"
exit 0
