#!/bin/bash
# so4t-wifi-autoconnect.timer(20초마다) 가 실행: 내장 와이파이(wlan0)가 끊겨 있으면
# 스캔하고, 보이는 저장된 네트워크 중 우선순위가 가장 높은 것(대회 핫스팟 > 학교 > 기타)에 연결.
. /usr/local/lib/so4t-net/so4t_net_common.sh
IF=$(so4t_builtin_if)
command -v iw >/dev/null 2>&1 && iw dev "$IF" set power_save off 2>/dev/null || true
ST=$(nmcli -g GENERAL.STATE device show "$IF" 2>/dev/null)
case "$ST" in
  100*) # 연결됨. 단, 대회 핫스팟이 아닌 곳(학교 등)에 붙어 있는데 핫스팟이 보이면 핫스팟으로 옮김
        # (직원 호출 보드는 핫스팟에만 붙으므로 파이도 같은 핫스팟에 있어야 함)
        CUR=$(nmcli -g GENERAL.CONNECTION device show "$IF" 2>/dev/null | so4t_unesc)
        [ "$CUR" = "$SO4T_HOT_NAME" ] && exit 0
        HU=$(so4t_uuid_by_name "$SO4T_HOT_NAME" | head -n1)
        [ -z "$HU" ] && exit 0
        HS=$(so4t_get "$HU" 802-11-wireless.ssid); HS=${HS:-$SO4T_HOT_SSID}
        F=/run/so4t-hot-switch-fail
        if [ -f "$F" ] && [ $(( $(date +%s) - $(stat -c %Y "$F" 2>/dev/null || echo 0) )) -lt 300 ]; then exit 0; fi
        nmcli device wifi rescan ifname "$IF" >/dev/null 2>&1 || true
        sleep 3
        if nmcli -t -f SSID device wifi list ifname "$IF" --rescan no 2>/dev/null | so4t_unesc | grep -Fxq -- "$HS"; then
          echo "[so4t-wifi] '$CUR' 에 연결돼 있지만 대회 핫스팟 '$HS' 이 보임 → 핫스팟으로 옮김"
          if nmcli --wait 25 connection up uuid "$HU" ifname "$IF" >/dev/null 2>&1; then
            echo "[so4t-wifi] 핫스팟 연결 성공"; rm -f "$F"
          else
            echo "[so4t-wifi] 핫스팟 연결 실패 (비밀번호/WPA2/2.4GHz 확인) → 5분 동안 다시 안 옮김"; touch "$F"
          fi
        fi
        exit 0 ;;
  # 40~90: 연결 중이면 그대로 둠
  40*|50*|60*|70*|80*|90*) exit 0 ;;
  20*) # unavailable: rfkill 막힘일 수 있음
       command -v rfkill >/dev/null 2>&1 && rfkill unblock wifi 2>/dev/null
       nmcli radio wifi on 2>/dev/null ;;
esac
nmcli device set "$IF" managed yes >/dev/null 2>&1 || true
nmcli device wifi rescan ifname "$IF" >/dev/null 2>&1 || true
sleep 4
VIS=$(nmcli -t -f SSID device wifi list ifname "$IF" --rescan no 2>/dev/null | so4t_unesc | sort -u)
[ -z "$VIS" ] && exit 0
BMAC=$(so4t_mac "$IF")
F=/run/so4t-hot-switch-fail
SKIPHOT=0
if [ -f "$F" ] && [ $(( $(date +%s) - $(stat -c %Y "$F" 2>/dev/null || echo 0) )) -lt 300 ]; then SKIPHOT=1; fi
best=""; bestp=-100000
for u in $(so4t_wifi_uuids); do
  [ "$(so4t_get "$u" connection.autoconnect)" = "yes" ] || continue
  [ "$SKIPHOT" = "1" ] && [ "$(so4t_get "$u" connection.id)" = "$SO4T_HOT_NAME" ] && continue
  mode=$(so4t_get "$u" 802-11-wireless.mode); [ -z "$mode" ] || [ "$mode" = "infrastructure" ] || continue
  ssid=$(so4t_get "$u" 802-11-wireless.ssid)
  so4t_is_esp_ssid "$ssid" && continue
  ifn=$(so4t_get "$u" connection.interface-name); [ -z "$ifn" ] || [ "$ifn" = "$IF" ] || continue
  mac=$(so4t_get "$u" 802-11-wireless.mac-address | tr 'a-f' 'A-F'); [ -z "$mac" ] || [ "$mac" = "$BMAC" ] || continue
  printf '%s\n' "$VIS" | grep -Fxq -- "$ssid" || continue
  p=$(so4t_get "$u" connection.autoconnect-priority); p=${p:-0}
  if [ "$p" -gt "$bestp" ] 2>/dev/null; then best="$u"; bestp="$p"; fi
done
[ -z "$best" ] && exit 0
NAME=$(so4t_get "$best" connection.id)
echo "[so4t-wifi] $IF 끊김 → '$NAME' 연결 시도 (priority $bestp)"
if nmcli --wait 25 connection up uuid "$best" ifname "$IF" >/dev/null 2>&1; then
  echo "[so4t-wifi] 연결 성공: $NAME"
  [ "$NAME" = "$SO4T_HOT_NAME" ] && rm -f "$F"
else
  echo "[so4t-wifi] 연결 실패: $NAME (다음 주기에 재시도)"
  # 핫스팟 비밀번호가 틀렸을 때 계속 핫스팟만 붙잡지 않게: 5분 동안은 다른 저장된 와이파이로
  [ "$NAME" = "$SO4T_HOT_NAME" ] && touch "$F"
fi
exit 0
