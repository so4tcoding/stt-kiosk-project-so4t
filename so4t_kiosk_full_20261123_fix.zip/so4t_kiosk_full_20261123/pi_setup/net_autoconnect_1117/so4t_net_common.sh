#!/bin/bash
# 소4트 네트워크 공통 함수 (install / link / autoconnect / check 가 같이 씀)
# 비밀번호는 여기 없음. 절대 출력하지 않음.
SO4T_HOT_NAME="so4t-competition-hotspot"
# 핫스팟 이름: 환경변수 SO4T_HOT_SSID > /etc/so4t-net/hot_ssid (설치 때 저장) > 기본값
if [ -z "${SO4T_HOT_SSID:-}" ] && [ -r /etc/so4t-net/hot_ssid ]; then SO4T_HOT_SSID=$(head -n1 /etc/so4t-net/hot_ssid); fi
SO4T_HOT_SSID="${SO4T_HOT_SSID:-AndroidHotspot3054}"
SO4T_ESP_NAME="so4t-esp32-call"
SO4T_ESP_SSID="SO4T-CALL2"
SO4T_ESP_IP="192.168.4.1"
SO4T_ESP_MYIP="192.168.4.3/24"
SO4T_STATE_DIR="/etc/so4t-net"
SO4T_STATE="$SO4T_STATE_DIR/state"

# nmcli 터미널 출력의 "\:" 이스케이프 해제
so4t_unesc() { sed -e 's/\\:/:/g' -e 's/\\\\/\\/g'; }
so4t_get() { nmcli -g "$2" connection show uuid "$1" 2>/dev/null | so4t_unesc; }

so4t_is_wifi_if() { [ -d "/sys/class/net/$1/wireless" ] || [ -e "/sys/class/net/$1/phy80211" ]; }
so4t_if_driver() { basename "$(readlink -f "/sys/class/net/$1/device/driver" 2>/dev/null)" 2>/dev/null; }
so4t_if_is_usb() { readlink -f "/sys/class/net/$1/device" 2>/dev/null | grep -q '/usb'; }

# 내장 와이파이(brcmfmac, 보통 wlan0)
so4t_builtin_if() {
  local i n best=""
  for i in /sys/class/net/*; do
    n=$(basename "$i")
    so4t_is_wifi_if "$n" || continue
    so4t_if_is_usb "$n" && continue
    if [ "$(so4t_if_driver "$n")" = "brcmfmac" ]; then
      if [ "$n" = "wlan0" ]; then echo wlan0; return 0; fi
      [ -z "$best" ] && best="$n"
    fi
  done
  if [ -n "$best" ]; then echo "$best"; return 0; fi
  # brcmfmac 못 찾으면 USB 아닌 첫 무선, 그래도 없으면 wlan0
  for i in /sys/class/net/*; do
    n=$(basename "$i")
    so4t_is_wifi_if "$n" || continue
    so4t_if_is_usb "$n" && continue
    echo "$n"; return 0
  done
  echo wlan0
}

# USB 와이파이 동글(보통 wlan1). 없으면 빈 문자열
so4t_usb_if() {
  local i n first=""
  for i in /sys/class/net/*; do
    n=$(basename "$i")
    so4t_is_wifi_if "$n" || continue
    so4t_if_is_usb "$n" || continue
    if [ "$n" = "wlan1" ]; then echo wlan1; return 0; fi
    [ -z "$first" ] && first="$n"
  done
  echo "$first"
}

so4t_mac() { cat "/sys/class/net/$1/address" 2>/dev/null | tr 'a-f' 'A-F'; }

# 와이파이 프로필 UUID 목록
so4t_wifi_uuids() {
  nmcli -t -f UUID,TYPE connection show 2>/dev/null | awk -F: '$2=="802-11-wireless"{print $1}'
}
so4t_uuid_by_name() {
  nmcli -t -f UUID,NAME connection show 2>/dev/null | awk -F: -v n="$1" '{u=$1; sub(/^[^:]*:/,""); gsub(/\\:/,":"); if($0==n) print u}'
}
so4t_is_esp_ssid() { echo "$1" | grep -qiE '^so4t-call|so4t_call|esp32'; }
