소4트 파이 네트워크 자동 연결 (2026-11-17)
==========================================
설치:  cd ~ && python3 -m zipfile -e net_autoconnect_1117.zip . && bash install_net_autoconnect.sh
       sudo reboot
확인:  bash ~/net_check.sh
제거:  bash ~/uninstall_net_autoconnect.sh

- 대회 핫스팟 AndroidHotspot3054: 내장 와이파이(wlan0) 전용, 우선순위 최고, 끊기면 20초마다 다시 찾음
- ESP32 직원 호출 보드 SO4T-CALL2: USB 동글(wlan1) 전용, 192.168.4.3/24, 게이트웨이 없음
  so4t-esp32-link.service 가 부팅 때부터 10초마다 확인 → 보드를 나중에 켜도 자동 연결
- 예전 esp32-link.service 는 꺼 둠(제거하면 다시 켜짐). 학교 와이파이 프로필은 지우지 않음.
- 로그: journalctl -u so4t-esp32-link -f   /   journalctl -u so4t-wifi-autoconnect -n 20
주의: 이 zip 안에 와이파이 비밀번호가 들어 있으니 외부에 공유하지 말 것.
