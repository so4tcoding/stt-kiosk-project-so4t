#!/bin/bash
# 소4트 키오스크 파이: 대회 핫스팟 자동 연결 + ESP32 직원 호출 보드(wlan1) 부팅 시 자동 연결
# 실행: cd ~ && python3 -m zipfile -e net_autoconnect_1117.zip . && bash install_net_autoconnect.sh
# 여러 번 실행해도 됨(자기 프로필만 지우고 다시 만듦). 비밀번호는 화면에 출력하지 않음.
set -uo pipefail
D="$(cd "$(dirname "$0")" && pwd)"
TS=$(date +%Y%m%d_%H%M%S)

# ---- 설정 ----
HOT_PSK='<HOTSPOT_PASSWORD>'   # 대회 핫스팟 비밀번호 (팀 내부에서만 채우기)
ESP_PSK='<ESP32_AP_PASSWORD>'   # ESP32 예비 AP(SO4T-CALL2) 비밀번호
HOT_PRIO_MIN=100
ESP_PRIO=50
# 위 줄을 고치지 않아도 됨: SO4T_HOT_PSK 환경변수 또는 아래 입력 칸(화면에 안 보임)으로 넣을 수 있음
[ -n "${SO4T_HOT_PSK:-}" ] && HOT_PSK="$SO4T_HOT_PSK"
[ -n "${SO4T_ESP_PSK:-}" ] && ESP_PSK="$SO4T_ESP_PSK"

if [ ! -f "$D/so4t_net_common.sh" ]; then
  echo "ERROR: so4t_net_common.sh 가 $D 에 없음. zip 을 ~ 에 먼저 풀어 주세요." >&2; exit 1
fi
. "$D/so4t_net_common.sh"
case "$HOT_PSK" in "<"*)
  if [ -t 0 ]; then read -rsp "핫스팟 '$SO4T_HOT_SSID' 비밀번호 입력 (화면에 안 보임): " HOT_PSK; echo; fi ;;
esac
case "$HOT_PSK" in "<"*|"")
  echo "ERROR: 핫스팟 비밀번호가 비어 있거나 아직 자리표시자입니다. 다시 실행해서 입력해 주세요." >&2; exit 1 ;;
esac
if [ ${#HOT_PSK} -lt 8 ] || [ ${#HOT_PSK} -gt 63 ]; then
  echo "ERROR: 핫스팟 비밀번호는 8~63자여야 합니다 (지금 ${#HOT_PSK}자)." >&2; exit 1
fi
command -v nmcli >/dev/null 2>&1 || { echo "ERROR: nmcli 없음 (NetworkManager 필요)" >&2; exit 1; }
sudo -v || { echo "ERROR: sudo 권한 필요" >&2; exit 1; }
S() { sudo "$@"; }

new_uuid() { cat /proc/sys/kernel/random/uuid 2>/dev/null || python3 -c 'import uuid;print(uuid.uuid4())'; }

# 원래 값 기록(처음 한 번만) → uninstall 때 되돌림
remember() { # uuid field value
  S mkdir -p "$SO4T_STATE_DIR"; S touch "$SO4T_STATE"; S chmod 600 "$SO4T_STATE"
  if ! S grep -q "^$1|$2|" "$SO4T_STATE"; then
    printf '%s|%s|%s\n' "$1" "$2" "$3" | S tee -a "$SO4T_STATE" >/dev/null
  fi
}

echo "=================================================="
echo " 소4트 네트워크 자동 연결 설치 ($TS)"
echo "=================================================="

# ---- 0) 백업 ----
echo "== 0) 백업 =="
BK="$HOME/net_autoconnect_backup_$TS"
mkdir -p "$BK"; chmod 700 "$BK"
S ls -la /etc/NetworkManager/system-connections/ > "$BK/system-connections.ls.txt" 2>&1 || true
nmcli -f NAME,UUID,TYPE,DEVICE,AUTOCONNECT,AUTOCONNECT-PRIORITY connection show > "$BK/nmcli_con_show.txt" 2>&1 || true
nmcli device status > "$BK/nmcli_dev_status.txt" 2>&1 || true
ip -br addr > "$BK/ip_addr.txt" 2>&1 || true
ip route > "$BK/ip_route.txt" 2>&1 || true
# 프로필 원본(비밀번호 포함)은 root 만 읽을 수 있는 곳에 복사
RBK="/var/backups/so4t-net/$TS"
S mkdir -p "$RBK" && S chmod 700 /var/backups/so4t-net "$RBK"
S cp -a /etc/NetworkManager/system-connections/. "$RBK/" 2>/dev/null || true
echo "$BK" > "$HOME/.net_autoconnect_last_backup"
echo "  목록 백업: $BK"
echo "  프로필 원본(root 전용): $RBK"

# ---- 1) 인터페이스 확인 ----
echo "== 1) 와이파이 장치 확인 =="
command -v rfkill >/dev/null 2>&1 && S rfkill unblock wifi 2>/dev/null || true
S nmcli radio wifi on 2>/dev/null || true
BI=$(so4t_builtin_if)
BMAC=$(so4t_mac "$BI")
UI=$(so4t_usb_if)
echo "  내장 와이파이(인터넷용): $BI  driver=$(so4t_if_driver "$BI")  MAC=${BMAC:-?}"
if [ -n "$UI" ]; then
  echo "  USB 동글(ESP32용): $UI  driver=$(so4t_if_driver "$UI")"
else
  echo "  USB 동글: 지금 안 보임 → 프로필은 wlan1 로 만들어 두고, 꽂으면 서비스가 자동으로 붙음"
fi
ESP_IF=${UI:-wlan1}
if [ "$ESP_IF" = "$BI" ]; then echo "ERROR: 동글과 내장 와이파이를 구분 못 함" >&2; exit 1; fi

# ---- 2) 옛 ESP32 연결 서비스/프로필 정리 (지우지 않고 끄기만) ----
echo "== 2) 예전 esp32-link 서비스/프로필 충돌 방지 =="
if systemctl list-unit-files esp32-link.service >/dev/null 2>&1 && \
   systemctl list-unit-files esp32-link.service | grep -q esp32-link; then
  EN=$(systemctl is-enabled esp32-link.service 2>/dev/null || true)
  remember "svc" "esp32-link.service" "$EN"
  S systemctl disable --now esp32-link.service >/dev/null 2>&1 || true
  echo "  esp32-link.service 끔 (원래: ${EN:-?}, 제거 시 복구) — 새 so4t-esp32-link 로 대체"
fi

# ---- 3) 우리 프로필 삭제(재설치 대비) ----
echo "== 3) 기존 소4트 프로필 다시 만들기 준비 =="
for n in "$SO4T_HOT_NAME" "$SO4T_ESP_NAME"; do
  for u in $(so4t_uuid_by_name "$n"); do S nmcli connection delete uuid "$u" >/dev/null 2>&1 || true; done
  S rm -f "/etc/NetworkManager/system-connections/$n.nmconnection"
done

# ---- 4) 다른 와이파이 프로필: 핫스팟/학교는 내장 와이파이 전용, ESP32 프로필은 자동연결 끔 ----
echo "== 4) 기존 프로필 정리 (삭제 없음) =="
MAXP=0
for u in $(so4t_wifi_uuids); do
  name=$(so4t_get "$u" connection.id)
  ssid=$(so4t_get "$u" 802-11-wireless.ssid)
  mode=$(so4t_get "$u" 802-11-wireless.mode)
  ac=$(so4t_get "$u" connection.autoconnect)
  if so4t_is_esp_ssid "$ssid" || so4t_is_esp_ssid "$name"; then
    if [ "$ac" = "yes" ]; then
      remember "$u" connection.autoconnect "$ac"
      S nmcli connection modify uuid "$u" connection.autoconnect no || true
      echo "  '$name' (SSID $ssid): 자동연결 끔 → wlan0 이 ESP32에 붙지 않게 (수동 'nmcli con up' 은 그대로 가능)"
    else
      echo "  '$name' (SSID $ssid): 이미 자동연결 꺼짐"
    fi
    continue
  fi
  [ -z "$mode" ] || [ "$mode" = "infrastructure" ] || { echo "  '$name': mode=$mode → 건드리지 않음"; continue; }
  p=$(so4t_get "$u" connection.autoconnect-priority); p=${p:-0}
  [ "$p" -gt "$MAXP" ] 2>/dev/null && MAXP=$p
  ifn=$(so4t_get "$u" connection.interface-name)
  mac=$(so4t_get "$u" 802-11-wireless.mac-address)
  if [ -z "$ifn" ] && [ -z "$mac" ] && [ -n "$BMAC" ]; then
    remember "$u" 802-11-wireless.mac-address ""
    S nmcli connection modify uuid "$u" 802-11-wireless.mac-address "$BMAC" || true
    echo "  '$name': 내장 와이파이($BI) 전용으로 묶음 (동글 wlan1 이 가져가지 않게)"
  else
    echo "  '$name': 이미 장치 지정됨 (ifname=${ifn:-없음} mac=${mac:-없음}) → 그대로"
  fi
done
HOT_PRIO=$HOT_PRIO_MIN
[ "$MAXP" -ge "$HOT_PRIO" ] && HOT_PRIO=$((MAXP+10))
echo "  다른 프로필 최고 우선순위: $MAXP → 대회 핫스팟 우선순위: $HOT_PRIO"

# ---- 5) 대회 핫스팟 프로필 (keyfile, 권한 600) ----
echo "== 5) 대회 핫스팟 '$SO4T_HOT_SSID' 프로필 =="
S mkdir -p "$SO4T_STATE_DIR"
printf '%s\n' "$SO4T_HOT_SSID" | S tee "$SO4T_STATE_DIR/hot_ssid" >/dev/null
S chmod 644 "$SO4T_STATE_DIR/hot_ssid"
umask 077
TMP=$(mktemp)
{
  echo "[connection]"
  echo "id=$SO4T_HOT_NAME"
  echo "uuid=$(new_uuid)"
  echo "type=wifi"
  [ -z "$BMAC" ] && echo "interface-name=$BI"
  echo "autoconnect=true"
  echo "autoconnect-priority=$HOT_PRIO"
  echo "autoconnect-retries=0"
  echo
  echo "[wifi]"
  echo "mode=infrastructure"
  echo "ssid=$SO4T_HOT_SSID"
  echo "powersave=2"
  [ -n "$BMAC" ] && echo "mac-address=$BMAC"
  echo
  echo "[wifi-security]"
  echo "key-mgmt=wpa-psk"
  echo "psk=$HOT_PSK"
  echo
  echo "[ipv4]"
  echo "method=auto"
  echo
  echo "[ipv6]"
  echo "addr-gen-mode=default"
  echo "method=auto"
} > "$TMP"
S install -m 600 -o root -g root "$TMP" "/etc/NetworkManager/system-connections/$SO4T_HOT_NAME.nmconnection"
rm -f "$TMP"

# ---- 6) ESP32 직원 호출 보드 프로필 (wlan1 전용, 인터넷 경로 안 씀) ----
echo "== 6) ESP32 '$SO4T_ESP_SSID' 프로필 ($ESP_IF, $SO4T_ESP_MYIP, 게이트웨이 없음) =="
TMP=$(mktemp)
{
  echo "[connection]"
  echo "id=$SO4T_ESP_NAME"
  echo "uuid=$(new_uuid)"
  echo "type=wifi"
  echo "interface-name=$ESP_IF"
  echo "autoconnect=true"
  echo "autoconnect-priority=$ESP_PRIO"
  echo "autoconnect-retries=0"
  echo
  echo "[wifi]"
  echo "mode=infrastructure"
  echo "ssid=$SO4T_ESP_SSID"
  echo "powersave=2"
  echo
  echo "[wifi-security]"
  echo "key-mgmt=wpa-psk"
  echo "psk=$ESP_PSK"
  echo
  echo "[ipv4]"
  echo "method=manual"
  echo "address1=$SO4T_ESP_MYIP"
  echo "never-default=true"
  echo "ignore-auto-dns=true"
  echo "may-fail=true"
  echo
  echo "[ipv6]"
  echo "method=disabled"
} > "$TMP"
S install -m 600 -o root -g root "$TMP" "/etc/NetworkManager/system-connections/$SO4T_ESP_NAME.nmconnection"
rm -f "$TMP"
umask 022
S nmcli connection reload
sleep 1
for n in "$SO4T_HOT_NAME" "$SO4T_ESP_NAME"; do
  if [ -n "$(so4t_uuid_by_name "$n")" ]; then echo "  프로필 로드됨: $n"; else echo "  !! 프로필 로드 실패: $n (sudo journalctl -u NetworkManager -n 30 확인)"; fi
done

# ---- 7) 절전 끄기 전역 설정 ----
if ! S grep -rqs 'wifi.powersave *= *2' /etc/NetworkManager/conf.d/; then
  printf '%s\n' '# so4t: Wi-Fi power save off' '[connection]' 'wifi.powersave = 2' \
    | S tee /etc/NetworkManager/conf.d/98-so4t-powersave.conf >/dev/null
  echo "  전역 절전 끄기 설정 추가: 98-so4t-powersave.conf"
fi

# ---- 8) 스크립트 + systemd ----
echo "== 8) 자동 연결 서비스 설치 =="
S install -d -m 755 /usr/local/lib/so4t-net
S install -m 644 "$D/so4t_net_common.sh" /usr/local/lib/so4t-net/so4t_net_common.sh
S install -m 755 "$D/so4t_esp32_link.sh" /usr/local/lib/so4t-net/so4t_esp32_link.sh
S install -m 755 "$D/so4t_wifi_autoconnect.sh" /usr/local/lib/so4t-net/so4t_wifi_autoconnect.sh

S tee /etc/systemd/system/so4t-esp32-link.service >/dev/null <<'UNIT'
[Unit]
Description=SO4T ESP32 staff-call board link (USB Wi-Fi wlan1 -> SO4T-CALL2)
After=NetworkManager.service
Wants=NetworkManager.service

[Service]
Type=simple
ExecStart=/bin/bash /usr/local/lib/so4t-net/so4t_esp32_link.sh
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT

S tee /etc/systemd/system/so4t-wifi-autoconnect.service >/dev/null <<'UNIT'
[Unit]
Description=SO4T wlan0 auto-reconnect (rescan + best known network)
After=NetworkManager.service
Wants=NetworkManager.service

[Service]
Type=oneshot
ExecStart=/bin/bash /usr/local/lib/so4t-net/so4t_wifi_autoconnect.sh
TimeoutStartSec=60
UNIT

S tee /etc/systemd/system/so4t-wifi-autoconnect.timer >/dev/null <<'UNIT'
[Unit]
Description=SO4T wlan0 auto-reconnect every 20s

[Timer]
OnBootSec=20s
OnUnitInactiveSec=20s
AccuracySec=2s

[Install]
WantedBy=timers.target
UNIT

S systemctl daemon-reload
S systemctl enable so4t-esp32-link.service so4t-wifi-autoconnect.timer >/dev/null 2>&1
S systemctl restart so4t-esp32-link.service
S systemctl restart so4t-wifi-autoconnect.timer
S touch "$SO4T_STATE"; S chmod 600 "$SO4T_STATE"

# ---- 9) 지금 바로 한 번 시도 ----
echo "== 9) 지금 연결 시도 =="
if [ -n "$UI" ]; then
  S nmcli --wait 15 connection up id "$SO4T_ESP_NAME" ifname "$UI" >/dev/null 2>&1 \
    && echo "  ESP32 보드 연결 성공 ($UI)" \
    || echo "  ESP32 보드 지금은 연결 안 됨 (보드 꺼짐?) → 서비스가 10초마다 계속 시도"
fi
ST=$(nmcli -g GENERAL.STATE device show "$BI" 2>/dev/null)
CON=$(nmcli -g GENERAL.CONNECTION device show "$BI" 2>/dev/null | so4t_unesc)
echo "  $BI 상태: $ST / ${CON:-없음} (이미 연결돼 있으면 그대로 둠)"

echo
echo "=================================================="
echo " 설치 완료 요약"
echo "=================================================="
echo " 1) 대회 핫스팟 '$SO4T_HOT_SSID' → 프로필 '$SO4T_HOT_NAME'"
echo "    - $BI(내장) 전용, 자동연결, 우선순위 $HOT_PRIO (학교·기존 핫스팟보다 높음), 무한 재시도, 절전 끔"
echo "    - $BI 가 끊겨 있으면 20초마다 스캔해서 자동 연결 (so4t-wifi-autoconnect.timer)"
echo " 2) ESP32 직원 호출 보드 '$SO4T_ESP_SSID' → 프로필 '$SO4T_ESP_NAME'"
echo "    - ${ESP_IF}(USB 동글) 전용, 고정 IP $SO4T_ESP_MYIP, 게이트웨이 없음(인터넷은 $BI 로만)"
echo "    - so4t-esp32-link.service 가 부팅 때부터 10초마다 확인, 보드가 늦게 켜져도 자동 연결"
echo " 3) 기존 학교/핫스팟 프로필은 삭제 안 함 (내장 와이파이 전용으로만 묶음)"
echo " 백업: $BK"
echo
echo " 다음 단계: sudo reboot  →  재부팅 후  bash ~/net_check.sh"
echo " 되돌리기: bash ~/uninstall_net_autoconnect.sh"
