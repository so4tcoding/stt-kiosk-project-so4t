#!/bin/bash
# 소4트 네트워크 상태 확인 (비밀번호는 출력하지 않음)
if [ -f /usr/local/lib/so4t-net/so4t_net_common.sh ]; then . /usr/local/lib/so4t-net/so4t_net_common.sh
else . "$(cd "$(dirname "$0")" && pwd)/so4t_net_common.sh"; fi
export LANG=C
BI=$(so4t_builtin_if); UI=$(so4t_usb_if)
echo "===== 소4트 네트워크 상태 $(date '+%F %T') ====="
echo "[장치] 내장=$BI($(so4t_if_driver "$BI"))  USB동글=${UI:-없음}${UI:+($(so4t_if_driver "$UI"))}"
command -v rfkill >/dev/null 2>&1 && { echo "[rfkill]"; rfkill list wifi 2>/dev/null | sed 's/^/  /'; }
command -v iw >/dev/null 2>&1 && echo "[국가] $(iw reg get 2>/dev/null | awk '/country/{print $2; exit}')"
echo "[nmcli device]"; nmcli -f DEVICE,TYPE,STATE,CONNECTION device status | sed 's/^/  /'
echo "[소4트 프로필]"
for n in "$SO4T_HOT_NAME" "$SO4T_ESP_NAME"; do
  u=$(so4t_uuid_by_name "$n" | head -n1)
  if [ -z "$u" ]; then echo "  $n: 없음!"; continue; fi
  echo "  $n: ssid=$(so4t_get "$u" 802-11-wireless.ssid) ifname=$(so4t_get "$u" connection.interface-name) mac=$(so4t_get "$u" 802-11-wireless.mac-address) autoconnect=$(so4t_get "$u" connection.autoconnect) prio=$(so4t_get "$u" connection.autoconnect-priority) retries=$(so4t_get "$u" connection.autoconnect-retries) powersave=$(so4t_get "$u" 802-11-wireless.powersave) ipv4=$(so4t_get "$u" ipv4.method) $(so4t_get "$u" ipv4.addresses) never-default=$(so4t_get "$u" ipv4.never-default)"
done
echo "[와이파이 프로필 전체 (이름|자동연결|우선순위|장치지정)]"
for u in $(so4t_wifi_uuids); do
  echo "  $(so4t_get "$u" connection.id) | $(so4t_get "$u" connection.autoconnect) | $(so4t_get "$u" connection.autoconnect-priority) | ifname=$(so4t_get "$u" connection.interface-name) mac=$(so4t_get "$u" 802-11-wireless.mac-address)"
done
echo "[IP]"; ip -br addr | grep -E '^(wlan|wl)' | sed 's/^/  /'
echo "[기본 경로]"; ip route show default | sed 's/^/  /'; echo "[192.168.4.0/24 경로]"; ip route show 192.168.4.0/24 | sed 's/^/  /'
ip -4 -br addr show "$BI" 2>/dev/null | grep -q ' 192\.168\.4\.' && echo "  !! 경고: $BI 가 192.168.4.x 대역 → ESP32 와 주소 겹침"
echo "[보이는 소4트 관련 SSID]"
nmcli -t -f SSID,SIGNAL,CHAN device wifi list --rescan no 2>/dev/null | grep -E "^($SO4T_HOT_SSID|$SO4T_ESP_SSID|yc_yc)" | sort -u | sed 's/^/  /'
echo "[ESP32 응답]"
if [ -n "$UI" ]; then
  curl -s -o /dev/null -w "  $UI → http://$SO4T_ESP_IP/  HTTP %{http_code}\n" --interface "$UI" -m 3 "http://$SO4T_ESP_IP/" || echo "  $UI → ESP32 응답 없음"
else
  echo "  USB 동글 없음 (키오스크는 wlan0 경로로 대체)"
fi
echo "[직원 호출 중계 (핫스팟 방식)]"
R=$(curl -s -m 2 http://127.0.0.1:8020/status 2>/dev/null)
if [ -n "$R" ]; then printf '%s\n' "$R" | sed 's/^/  /'; else echo "  중계 응답 없음 (sudo systemctl status so4t-call-relay)"; fi
echo "[인터넷]"
if curl -s -o /dev/null -m 5 --interface "$BI" http://connectivitycheck.gstatic.com/generate_204; then echo "  $BI 인터넷 OK"; else echo "  $BI 인터넷 안 됨"; fi
echo "[서비스]"
for s in so4t-esp32-link.service so4t-wifi-autoconnect.timer esp32-link.service; do
  echo "  $s: $(systemctl is-enabled $s 2>/dev/null || echo -) / $(systemctl is-active $s 2>/dev/null || echo -)"
done
echo "[최근 로그]"
journalctl -u so4t-esp32-link -u so4t-wifi-autoconnect -n 12 --no-pager -o cat 2>/dev/null | sed 's/^/  /'
