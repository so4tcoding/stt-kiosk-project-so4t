#!/bin/bash
# so4t-esp32-link.service 본체: USB 동글(wlan1)로 ESP32 직원 호출 보드(SO4T-CALL2)에 계속 붙어 있게 함.
# ESP32가 파이보다 늦게 켜져도 10초마다 확인해서 다시 붙음. wlan0(인터넷)은 건드리지 않음.
. /usr/local/lib/so4t-net/so4t_net_common.sh
log() { echo "[so4t-esp32-link] $*"; }
fail=0; last_msg=""
say_once() { if [ "$1" != "$last_msg" ]; then log "$1"; last_msg="$1"; fi; }

sleep 3
while true; do
  IFX=$(so4t_usb_if)
  if [ -z "$IFX" ] && ip link show wlan1 >/dev/null 2>&1; then IFX=wlan1; fi
  if [ -z "$IFX" ]; then
    say_once "USB 와이파이 동글 없음 → 대기 (키오스크는 wlan0 경로로 대체)"
    sleep 10; continue
  fi
  UUID=$(so4t_uuid_by_name "$SO4T_ESP_NAME" | head -n1)
  if [ -z "$UUID" ]; then
    say_once "프로필 $SO4T_ESP_NAME 없음 (install_net_autoconnect.sh 다시 실행 필요)"
    sleep 10; continue
  fi
  # 동글 이름이 바뀌었으면 프로필 interface-name 따라가기
  CUR_IF=$(so4t_get "$UUID" connection.interface-name)
  if [ "$CUR_IF" != "$IFX" ]; then
    log "동글 이름 $IFX 로 프로필 바인딩 변경 (이전: ${CUR_IF:-없음})"
    nmcli connection modify uuid "$UUID" connection.interface-name "$IFX" || true
  fi
  nmcli device set "$IFX" managed yes >/dev/null 2>&1 || true
  ip link set "$IFX" up 2>/dev/null || true
  command -v iw >/dev/null 2>&1 && iw dev "$IFX" set power_save off 2>/dev/null || true

  # wlan1 이 다른 네트워크에 붙어 있으면 떼어내고 내장 와이파이로 묶기
  ACT=$(nmcli -g GENERAL.CONNECTION device show "$IFX" 2>/dev/null | so4t_unesc)
  if [ -n "$ACT" ] && [ "$ACT" != "--" ] && [ "$ACT" != "$SO4T_ESP_NAME" ]; then
    OU=$(so4t_uuid_by_name "$ACT" | head -n1)
    log "$IFX 가 다른 네트워크($ACT)에 붙어 있음 → 내장 와이파이 전용으로 묶고 ESP32로 전환"
    BI=$(so4t_builtin_if); BMAC=$(so4t_mac "$BI")
    if [ -n "$OU" ] && [ -n "$BMAC" ]; then
      OLD=$(so4t_get "$OU" 802-11-wireless.mac-address)
      grep -q "^$OU|802-11-wireless.mac-address|" "$SO4T_STATE" 2>/dev/null || \
        echo "$OU|802-11-wireless.mac-address|$OLD" >> "$SO4T_STATE"
      nmcli connection modify uuid "$OU" 802-11-wireless.mac-address "$BMAC" || true
    fi
    [ -n "$OU" ] && nmcli connection down uuid "$OU" >/dev/null 2>&1 || true
  fi

  ok=0
  if curl -s -o /dev/null --interface "$IFX" -m 3 "http://$SO4T_ESP_IP/" 2>/dev/null; then ok=1
  elif ping -I "$IFX" -c 1 -W 2 "$SO4T_ESP_IP" >/dev/null 2>&1; then ok=1; fi

  if [ "$ok" = 1 ]; then
    say_once "ESP32 연결 OK ($IFX → $SO4T_ESP_IP)"; fail=0
  else
    fail=$((fail+1))
    ST=$(nmcli -g GENERAL.STATE device show "$IFX" 2>/dev/null)
    ACT=$(nmcli -g GENERAL.CONNECTION device show "$IFX" 2>/dev/null | so4t_unesc)
    if [ "$ACT" = "$SO4T_ESP_NAME" ] && [ "$fail" -lt 3 ]; then
      say_once "ESP32 응답 없음, 연결은 살아 있음 → 잠시 대기 ($ST)"
    else
      say_once "ESP32 응답 없음 → $IFX 재연결 시도 (ESP32 꺼져 있으면 계속 재시도)"
      nmcli device wifi rescan ifname "$IFX" >/dev/null 2>&1 || true
      sleep 2
      if nmcli --wait 20 connection up uuid "$UUID" ifname "$IFX" >/dev/null 2>&1; then
        log "재연결 성공"; fail=0
      fi
    fi
  fi
  sleep 10
done
