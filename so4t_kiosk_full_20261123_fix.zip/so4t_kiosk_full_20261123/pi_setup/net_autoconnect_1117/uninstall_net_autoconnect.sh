#!/bin/bash
# install_net_autoconnect.sh 가 추가한 것만 제거하고, 바꾼 값은 원래대로 되돌림.
set -uo pipefail
D="$(cd "$(dirname "$0")" && pwd)"
if [ -f /usr/local/lib/so4t-net/so4t_net_common.sh ]; then . /usr/local/lib/so4t-net/so4t_net_common.sh
elif [ -f "$D/so4t_net_common.sh" ]; then . "$D/so4t_net_common.sh"
else echo "ERROR: so4t_net_common.sh 없음" >&2; exit 1; fi
sudo -v || exit 1
S() { sudo "$@"; }

echo "== 1) 서비스/타이머 제거 =="
S systemctl disable --now so4t-esp32-link.service so4t-wifi-autoconnect.timer >/dev/null 2>&1 || true
S systemctl stop so4t-wifi-autoconnect.service >/dev/null 2>&1 || true
S rm -f /etc/systemd/system/so4t-esp32-link.service \
        /etc/systemd/system/so4t-wifi-autoconnect.service \
        /etc/systemd/system/so4t-wifi-autoconnect.timer
S systemctl daemon-reload

echo "== 2) 소4트 프로필 삭제 =="
for n in "$SO4T_HOT_NAME" "$SO4T_ESP_NAME"; do
  for u in $(so4t_uuid_by_name "$n"); do S nmcli connection delete uuid "$u" >/dev/null 2>&1 && echo "  삭제: $n"; done
  S rm -f "/etc/NetworkManager/system-connections/$n.nmconnection"
done

echo "== 3) 바꿨던 기존 프로필 값 복구 =="
if S test -f "$SO4T_STATE"; then
  while IFS='|' read -r u f v; do
    [ -z "$u" ] && continue
    if [ "$u" = "svc" ]; then
      if [ "$v" = "enabled" ]; then
        S systemctl enable --now "$f" >/dev/null 2>&1 && echo "  $f 다시 켬"
      fi
      continue
    fi
    if nmcli -t -f UUID connection show | grep -qx "$u"; then
      S nmcli connection modify uuid "$u" "$f" "$v" >/dev/null 2>&1 \
        && echo "  $(so4t_get "$u" connection.id): $f 복구" \
        || echo "  !! 복구 실패: $u $f"
    fi
  done < <(S cat "$SO4T_STATE")
  S rm -rf "$SO4T_STATE_DIR"
else
  echo "  기록 없음"
fi

echo "== 4) 파일 정리 =="
S rm -rf /usr/local/lib/so4t-net
S rm -f /etc/NetworkManager/conf.d/98-so4t-powersave.conf
S nmcli connection reload || true
S nmcli general reload 2>/dev/null || true
echo "완료. 백업(/var/backups/so4t-net, ~/net_autoconnect_backup_*)은 남겨 둠. 필요하면 sudo reboot"
