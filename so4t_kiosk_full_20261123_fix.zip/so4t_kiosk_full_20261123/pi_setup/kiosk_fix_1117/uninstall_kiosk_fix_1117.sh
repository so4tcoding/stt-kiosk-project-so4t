#!/bin/bash
# 소4트 키오스크 11/17 고침 되돌리기 (패치 블록만 빼고, 추가한 Chrome 옵션만 지움)
K="${KIOSK_DIR:-$HOME/kiosk_project}"; H="$K/kiosk.html"
A="${AUTOSTART_FILE:-$HOME/.config/labwc/autostart}"; S="$HOME/.so4t_fix_1117_autostart"
TS=$(date +%Y%m%d_%H%M%S)_$$
if [ -f "$H" ]; then
  cp -a "$H" "$H.bak_unfix1117_$TS"
  python3 - "$H" <<'PY'
import sys, re
p = sys.argv[1]; s = open(p, encoding="utf-8", newline="").read()
ns = re.sub(r'\n?[ \t]*<!-- SO4T_FIX_1117 BEGIN.*?<!-- SO4T_FIX_1117 END -->[ \t]*\r?\n?', lambda m: "\n" if m.group(0).startswith("\n") else "", s, flags=re.S)
open(p, "w", encoding="utf-8", newline="").write(ns)
print("1117 패치 제거" if ns != s else "1117 패치 없음 (이미 제거됨)")
PY
fi
if [ -f "$S" ] && [ -f "$A" ]; then
  cp -a "$A" "$A.bak_unfix1117_$TS"
  sed -i 's# --autoplay-policy=no-user-gesture-required##' "$A" && rm -f "$S" && echo "autostart의 autoplay 옵션 제거"
fi
echo "완료. sudo reboot 또는 Chrome 다시 띄우기"
