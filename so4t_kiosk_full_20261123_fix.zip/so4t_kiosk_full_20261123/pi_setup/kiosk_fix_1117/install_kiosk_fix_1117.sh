#!/bin/bash
# 소4트 키오스크 11/17 고침 설치 (여러 번 실행해도 안전, 기능 삭제 없음)
#  1) 절전 해제 후 '주문 시작 안내'가 안 나오던 문제  2) 하단 천천히/빠르게/가+ 크게/가- 작게 바 숨김
#  3) 결제 끝 '감사합니다. 맛있게 드세요.'를 끝까지 말한 뒤 절전  (+ 메뉴+개수 한 번에 말할 때 수량 자동 입력)
#  4) 한 문장 주문: "아이스 아메리카노 1개 얼음 많이 포장해서 줘" → 말한 단계는 자동, 모르는 단계만 질문 (끄기: localStorage so4t_oneshot_off=1)
#  + Google Chrome 자동실행 줄에 --autoplay-policy=no-user-gesture-required 추가 (건너뛰기: SKIP_AUTOSTART=1)
set -e
D="$(cd "$(dirname "$0")" && pwd)"
K="${KIOSK_DIR:-$HOME/kiosk_project}"; H="$K/kiosk.html"
B="$D/so4t_fix_1117_block.html"
A="${AUTOSTART_FILE:-$HOME/.config/labwc/autostart}"
TS=$(date +%Y%m%d_%H%M%S)_$$
[ -f "$H" ] || { echo "kiosk.html 없음: $H"; exit 1; }
[ -f "$B" ] || { echo "패치 파일 없음: $B (zip을 홈 폴더에서 풀었는지 확인)"; exit 1; }

echo "== 1) kiosk.html 패치"
cp -a "$H" "$H.bak_fix1117_$TS"
echo "백업: $H.bak_fix1117_$TS"
python3 - "$H" "$B" <<'PY'
import sys, re
p, b = sys.argv[1], sys.argv[2]
s = open(p, encoding="utf-8", newline="").read()
blk = open(b, encoding="utf-8").read().strip("\n")
o = s
s = re.sub(r'[ \t]*<!-- SO4T_FIX_1117 BEGIN.*?<!-- SO4T_FIX_1117 END -->[ \t]*\r?\n?', '', s, flags=re.S)
if s != o: print("예전 1117 패치 제거 후 다시 넣음")
i = s.rfind("</body>")
if i < 0:
    s = s + ("" if s.endswith("\n") else "\n") + blk + "\n"
else:
    j = s.rfind("\n", 0, i) + 1
    if s[j:i].strip():  # </body> 앞에 다른 글자가 같은 줄에 있으면 </body> 바로 앞에 넣음
        j = i
        s = s[:j] + "\n" + blk + "\n" + s[j:]
    else:
        s = s[:j] + blk + "\n" + s[j:]
open(p, "w", encoding="utf-8", newline="").write(s)
PY
nb=$(grep -c 'SO4T_FIX_1117 BEGIN' "$H" || true); ne=$(grep -c 'SO4T_FIX_1117 END' "$H" || true)
if [ "$nb" = "1" ] && [ "$ne" = "1" ] && grep -q '</html>' "$H"; then echo "확인: 패치 1개 들어감 OK"
else echo "⚠ 확인 실패(BEGIN=$nb END=$ne) → 백업으로 되돌림"; cp -a "$H.bak_fix1117_$TS" "$H"; exit 1; fi
grep -c 'so4t_fix.js\|static/payment.js\|design_skin.js' "$H" | sed 's/^/기존 애드온 태그 수(그대로 유지): /'

echo "== 2) Chrome 자동실행 옵션 (TTS 자동재생 허용)"
if [ "${SKIP_AUTOSTART:-0}" = "1" ]; then echo "건너뜀 (SKIP_AUTOSTART=1)"
elif [ ! -f "$A" ]; then echo "autostart 없음: $A (건너뜀)"
else
  cp -a "$A" "$A.bak_fix1117_$TS"
  python3 - "$A" "$HOME/.so4t_fix_1117_autostart" <<'PY'
import sys, re
p, state = sys.argv[1], sys.argv[2]
FLAG = "--autoplay-policy=no-user-gesture-required"
lines = open(p, encoding="utf-8").read().split("\n")
changed = 0; has = 0
for k, ln in enumerate(lines):
    if ln.lstrip().startswith("#"): continue
    m = re.search(r'(google-chrome-stable|google-chrome|/opt/google/chrome/chrome)(?=\s)', ln)
    if not m: continue
    if "--autoplay-policy" in ln: has += 1; continue
    lines[k] = ln[:m.end()] + " " + FLAG + ln[m.end():]; changed += 1
if changed:
    open(p, "w", encoding="utf-8").write("\n".join(lines))
    open(state, "w").write(FLAG + "\n")
    print("Chrome 줄에 %s 추가 (%d줄)" % (FLAG, changed))
elif has: print("이미 autoplay 옵션 있음 (건너뜀)")
else: print("⚠ autostart에 Chrome 실행 줄을 못 찾음 (건너뜀)")
PY
  cmp -s "$A" "$A.bak_fix1117_$TS" && rm -f "$A.bak_fix1117_$TS" || echo "백업: $A.bak_fix1117_$TS"
  grep -n 'google-chrome' "$A" | grep -v '^[0-9]*:[[:space:]]*#' | sed 's/^/  autostart: /' | cut -c1-220
fi

echo
echo "완료! 다시 띄우기 (둘 중 하나):"
echo "  sudo reboot"
echo "  또는: pkill -f 'google-chrome|chromium'; sleep 1; google-chrome-stable --ozone-platform=wayland --autoplay-policy=no-user-gesture-required --disable-features=Translate,MediaRouter --renderer-process-limit=2 --enable-gpu-rasterization --ignore-gpu-blocklist --disable-smooth-scrolling --no-first-run --kiosk --noerrdialogs --disable-infobars --enable-speech-dispatcher http://localhost:8000/kiosk.html &"
echo "확인: F12 콘솔에 [kfix1117] loaded v1117 · 상태 보기: __so4tFix1117.log"
echo "되돌리기: bash uninstall_kiosk_fix_1117.sh"
