#!/bin/bash
# 소4트 파이 한 번에 설치 (2026-11-23)
#  1) 키오스크 고친 파일: 한 문장 주문/옵션/여러 메뉴, 안내 문장 끊김, 메뉴 그림
#  2) 선생님 핫스팟 자동 연결 (학교 와이파이에 붙어 있어도 핫스팟이 켜지면 핫스팟으로 옮김)
#  3) 직원 호출 벨(ESP32) 중계: 보드와 파이가 서로 자동으로 찾음 (IP 몰라도 됨)
# 실행: bash ~/so4t_kiosk_full_20261123/pi_setup/setup_pi_1123.sh
#  - 핫스팟 비밀번호는 실행 중에 물어봄(화면에 안 보임). 파일에 적지 않아도 됨.
#  - 여러 번 실행해도 됨. 관리자 PIN·Firebase 키가 들어 있을 수 있는 stt_server.py, static/firebase_config.js 는 덮어쓰지 않음.
#  - 일부만: SKIP_KIOSK=1 (키오스크 파일 건너뜀) / SKIP_NET=1 (네트워크·벨 건너뜀)
set -uo pipefail
P="$(cd "$(dirname "$0")" && pwd)"
R="$(cd "$P/.." && pwd)"
K="${KIOSK_DIR:-$HOME/kiosk_project}"
TS=$(date +%Y%m%d_%H%M%S)
HOT_NAME="so4t-competition-hotspot"

echo "=================================================="
echo " 소4트 파이 설치 1123 ($TS)"
echo "=================================================="
sudo true || { echo "ERROR: sudo 권한 필요"; exit 1; }

# ---------- 1) 키오스크 파일 ----------
if [ "${SKIP_KIOSK:-0}" != "1" ]; then
  echo "== 1) 키오스크 파일 ($K) =="
  [ -f "$K/kiosk.html" ] || { echo "ERROR: $K/kiosk.html 없음 → KIOSK_DIR=키오스크폴더 bash $0"; exit 1; }
  BK="$HOME/kiosk_backup_1123_$TS"
  mkdir -p "$BK"
  for f in kiosk.html js/kiosk_pi.js kiosk_pi.js js/kiosk_icons.js kiosk_icons.js stt_server.py; do
    if [ -f "$K/$f" ]; then mkdir -p "$BK/$(dirname "$f")"; cp -a "$K/$f" "$BK/$f"; fi
  done
  echo "  백업: $BK"
  install -D -m 644 "$R/kiosk/kiosk.html" "$K/kiosk.html"
  for f in kiosk_pi.js kiosk_icons.js; do
    install -D -m 644 "$R/kiosk/js/$f" "$K/js/$f"
    # 서버는 폴더 맨 위 파일을 먼저 씀 → 맨 위에도 옛 파일이 있으면 같이 바꿈
    [ -f "$K/$f" ] && install -m 644 "$R/kiosk/js/$f" "$K/$f"
  done
  mkdir -p "$K/static/twemoji"
  cp -r "$R/kiosk/static/twemoji/." "$K/static/twemoji/"
  echo "  kiosk.html, kiosk_pi.js, kiosk_icons.js, 메뉴 그림 파일 복사"
  if [ -f "$K/stt_server.py" ]; then
    python3 - "$K/stt_server.py" <<'PY'
import re, sys, py_compile, shutil
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
if '"kiosk_icons.js"' in s or "'kiosk_icons.js'" in s:
    print("  stt_server.py: kiosk_icons.js 이미 허용됨"); sys.exit(0)
m = re.search(r'_KIOSK_JS\s*=\s*\{', s)
if not m:
    print("  경고: stt_server.py 에 _KIOSK_JS 목록이 없음 → 메뉴 그림은 기본 접시 그림으로 나옴"); sys.exit(0)
shutil.copy2(p, p + ".bak_icons1123")
open(p, "w", encoding="utf-8").write(s[:m.end()] + '"kiosk_icons.js",' + s[m.end():])
try:
    py_compile.compile(p, doraise=True)
    print("  stt_server.py: kiosk_icons.js 한 이름만 허용 목록에 추가 (나머지 그대로)")
except Exception as e:
    shutil.copy2(p + ".bak_icons1123", p)
    print("  경고: stt_server.py 수정 확인 실패 → 원래대로 되돌림:", e)
PY
  fi
  if [ -f "$P/kiosk_fix_1117/install_kiosk_fix_1117.sh" ]; then
    echo "  11/17 고침(새 버전) 다시 확인 + Chrome 자동재생 옵션"
    KIOSK_DIR="$K" bash "$P/kiosk_fix_1117/install_kiosk_fix_1117.sh" 2>&1 | sed 's/^/    /' \
      || echo "  경고: install_kiosk_fix_1117.sh 실패 (kiosk.html 은 이미 새 버전이라 주문 기능은 그대로 동작)"
  fi
  if systemctl list-unit-files kiosk-stt.service 2>/dev/null | grep -q kiosk-stt; then
    sudo systemctl restart kiosk-stt.service && echo "  kiosk-stt.service 다시 시작"
  fi
fi

# ---------- 2) 핫스팟 자동 연결 ----------
if [ "${SKIP_NET:-0}" != "1" ]; then
  echo
  echo "== 2) 선생님 핫스팟 자동 연결 =="
  echo "  ※ 핫스팟 설정: 보안 WPA2-Personal(또는 WPA2/WPA3), 대역 2.4GHz, '자동으로 끄기' 끄기"
  DEF_SSID=$(head -n1 /etc/so4t-net/hot_ssid 2>/dev/null || true); DEF_SSID=${DEF_SSID:-AndroidHotspot3054}
  read -rp "  핫스팟 이름 [Enter = $DEF_SSID]: " SSID
  SSID=${SSID:-$DEF_SSID}
  HAVE=$(nmcli -t -f NAME connection show 2>/dev/null | grep -Fx "$HOT_NAME" || true)
  PSK=""
  for i in 1 2 3; do
    if [ -n "$HAVE" ]; then
      read -rsp "  핫스팟 비밀번호 (화면에 안 보임, Enter = 이미 저장된 값 그대로): " PSK; echo
      [ -z "$PSK" ] && break
    else
      read -rsp "  핫스팟 비밀번호 (화면에 안 보임): " PSK; echo
    fi
    if [ ${#PSK} -ge 8 ] && [ ${#PSK} -le 63 ]; then break; fi
    echo "  비밀번호는 8~63자예요. 다시 입력해 주세요."; PSK=""
  done
  if [ -n "$PSK" ]; then
    SO4T_HOT_SSID="$SSID" SO4T_HOT_PSK="$PSK" bash "$P/net_autoconnect_1117/install_net_autoconnect.sh" 2>&1 | sed 's/^/    /'
  elif [ -n "$HAVE" ]; then
    if [ "$SSID" != "$DEF_SSID" ]; then
      sudo nmcli connection modify id "$HOT_NAME" 802-11-wireless.ssid "$SSID" \
        && printf '%s\n' "$SSID" | sudo tee /etc/so4t-net/hot_ssid >/dev/null && echo "  핫스팟 이름만 '$SSID' 로 바꿈"
    fi
    echo "  저장된 핫스팟 프로필 그대로 사용"
  else
    echo "  ERROR: 핫스팟 비밀번호가 없어 자동 연결을 설치하지 못했어요. 다시 실행해 주세요."; exit 1
  fi
  unset PSK
  sudo install -d -m 755 /usr/local/lib/so4t-net
  sudo install -m 644 "$P/net_autoconnect_1117/so4t_net_common.sh" /usr/local/lib/so4t-net/so4t_net_common.sh
  sudo install -m 755 "$P/net_autoconnect_1117/so4t_wifi_autoconnect.sh" /usr/local/lib/so4t-net/so4t_wifi_autoconnect.sh
  install -m 755 "$P/net_autoconnect_1117/net_check.sh" "$HOME/net_check.sh"

  # ---------- 3) 직원 호출 벨 중계 ----------
  echo
  echo "== 3) 직원 호출 벨 중계 (so4t-call-relay) =="
  KIOSK_DIR="$K" bash "$P/esp32_hotspot_1117/install_esp32_hotspot.sh" 2>&1 | sed 's/^/    /'
  if command -v ufw >/dev/null 2>&1 && sudo ufw status 2>/dev/null | grep -q "Status: active"; then
    sudo ufw allow 8021/tcp >/dev/null && sudo ufw allow 4210/udp >/dev/null && echo "  방화벽: 8021/tcp, 4210/udp 열음"
  fi

  # ---------- 4) 지금 핫스팟으로 연결 + 보드 기다리기 ----------
  echo
  echo "== 4) 지금 핫스팟 연결 (SSH 로 접속 중이면 여기서 끊길 수 있어요) =="
  IF=wlan0
  CUR=$(nmcli -g GENERAL.CONNECTION device show "$IF" 2>/dev/null | sed 's/\\:/:/g')
  if [ "$CUR" = "$HOT_NAME" ]; then
    echo "  이미 핫스팟 '$SSID' 에 연결돼 있어요"
  else
    sudo nmcli device wifi rescan ifname "$IF" >/dev/null 2>&1 || true
    sleep 3
    if nmcli -t -f SSID device wifi list ifname "$IF" --rescan no 2>/dev/null | sed 's/\\:/:/g' | grep -Fxq -- "$SSID"; then
      sudo nmcli --wait 25 connection up id "$HOT_NAME" ifname "$IF" >/dev/null 2>&1 \
        && echo "  핫스팟 '$SSID' 연결 성공" \
        || echo "  핫스팟 연결 실패 → 비밀번호·WPA2·2.4GHz 확인 후 이 스크립트를 다시 실행"
    else
      echo "  핫스팟 '$SSID' 이 지금 안 보여요 → 핫스팟을 켜면 20초 안에 파이가 알아서 붙어요"
    fi
  fi
  sudo systemctl restart so4t-call-relay.service 2>/dev/null || true
  echo "  보드 찾는 중 (최대 60초, 보드 전원과 핫스팟을 켜 두세요)..."
  OK=0
  for i in $(seq 1 30); do
    ST=$(curl -s -m 2 http://127.0.0.1:8020/status 2>/dev/null || true)
    if printf '%s' "$ST" | grep -Eq '^board=[0-9]' && printf '%s' "$ST" | grep -Eq '\((beacon|poll|scan|cache), ([0-9]|[1-2][0-9])s 전\)|board_poll=([0-9]|[1-2][0-9])s 전'; then OK=1; break; fi
    sleep 2
  done
  printf '%s\n' "$ST" | sed 's/^/    /'
  if [ "$OK" = "1" ]; then
    echo "  보드 찾음! 시험: curl -s 127.0.0.1:8020/call  (부저) → curl -s 127.0.0.1:8020/stop"
  else
    echo "  아직 보드를 못 찾았어요. 보드가 '삑' 1번(핫스팟 접속) → '삑삑' 2번(파이 찾음) 소리를 내는지 보세요."
    echo "  상태 다시 보기: curl -s 127.0.0.1:8020/status   /   전체 점검: bash ~/net_check.sh"
  fi
fi

echo
echo "=================================================="
echo " 끝! 화면까지 새로 띄우려면: sudo reboot"
echo " 되돌리기: 키오스크 파일 = ${BK:-$HOME/kiosk_backup_1123_*} 에서 복사,"
echo "           네트워크 = bash $P/net_autoconnect_1117/uninstall_net_autoconnect.sh"
echo "=================================================="
