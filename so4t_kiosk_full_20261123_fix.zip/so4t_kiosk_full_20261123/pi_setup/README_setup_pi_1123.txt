소4트 파이 한 번에 설치 (2026-11-23)
====================================

무엇이 바뀌나
  1) 키오스크: 한 문장 주문(옵션·여러 메뉴·말 끊김 이어 듣기), 확인 안내 문장 끝까지 읽기, 메뉴 그림
  2) 선생님 핫스팟 자동 연결: 핫스팟을 켜면 20초 안에 파이가 핫스팟으로 붙음
     (학교 와이파이에 붙어 있어도 핫스팟이 보이면 핫스팟으로 옮김)
  3) 직원 호출 벨: 보드와 파이가 같은 핫스팟에 붙으면 서로 자동으로 찾음 (IP 입력 필요 없음)

준비 (선생님 폰 핫스팟 설정)
  - 보안: WPA2-Personal (WPA2/WPA3 혼합도 됨)
  - 대역: 2.4GHz (또는 '호환성 최대화')
  - '연결된 기기 없으면 자동으로 끄기' 끄기

설치 (파이 터미널, 한 줄씩)
  cd ~ && python3 -m zipfile -e so4t_kiosk_full_20261123_fix.zip .
  bash ~/so4t_kiosk_full_20261123/pi_setup/setup_pi_1123.sh
    → 핫스팟 이름: Enter (AndroidHotspot3054 그대로)
    → 핫스팟 비밀번호: 입력해도 화면에 안 보임, 입력 후 Enter
    → 마지막에 "보드 찾음!" 이 나오면 성공
  sudo reboot

시험
  curl -s 127.0.0.1:8020/status     보드 IP, 마지막 확인 시각
  curl -s 127.0.0.1:8020/call       부저 울림
  curl -s 127.0.0.1:8020/stop       부저 멈춤
  키오스크 화면에서 "직원 불러 주세요" 또는 직원 호출 버튼 → 부저 울림
  전체 점검: bash ~/net_check.sh

보드 소리/불빛 뜻
  '삑' 1번      핫스팟 접속됨
  '삑삑' 2번    파이 찾음 (이제 호출 받을 준비 끝)
  LED 1초마다 깜빡   핫스팟 못 찾음
  LED 3초마다 짧게   핫스팟은 됐고 파이를 아직 못 찾음
  LED 꺼짐           다 연결됨

일부만 다시 설치
  SKIP_NET=1 bash ~/so4t_kiosk_full_20261123/pi_setup/setup_pi_1123.sh    키오스크 파일만
  SKIP_KIOSK=1 bash ~/so4t_kiosk_full_20261123/pi_setup/setup_pi_1123.sh  핫스팟·벨만

안 될 때
  - "핫스팟 연결 실패": 비밀번호, WPA2, 2.4GHz 확인 후 setup_pi_1123.sh 다시 실행
  - 파이는 붙었는데 보드를 못 찾음: 보드가 '삑' 1번을 내는지 확인. 안 내면 보드 쪽 핫스팟 비밀번호 문제
    → esp32_hotspot_1117/README_esp32_hotspot.txt 의 [1] 또는 [1-2] 참고
  - 로그: journalctl -u so4t-call-relay -n 30   /   journalctl -u so4t-wifi-autoconnect -n 20

지키는 것
  - 비밀번호는 파일에 적지 않아도 됨(설치 중 입력). 스크립트는 비밀번호를 화면에 출력하지 않음.
  - stt_server.py 는 덮어쓰지 않음(메뉴 그림 파일 이름 한 개만 허용 목록에 추가), static/firebase_config.js 는 그대로.
  - 바꾸기 전 파일은 ~/kiosk_backup_1123_날짜 에 백업.
