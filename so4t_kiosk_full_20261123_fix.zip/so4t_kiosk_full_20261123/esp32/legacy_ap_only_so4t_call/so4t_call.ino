#include <WiFi.h>
#include <WebServer.h>

const int BUZZER = 5;
const int STOP_BTN = 6;   // 직원 끄기 버튼 (IO6 - GND)
const int LED = 7;        // (선택) LED: IO7 - 220Ω - LED - GND
WebServer server(80);
bool calling = false;

void sendCors(const char* msg) {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "text/plain", msg);
}
void handleCall() { calling = true;  sendCors("OK"); }
void handleStop() { calling = false; noTone(BUZZER); digitalWrite(LED, LOW); sendCors("STOP"); }

void setup() {
  Serial.begin(115200);
  pinMode(STOP_BTN, INPUT_PULLUP);
  pinMode(LED, OUTPUT);
  digitalWrite(LED, LOW);
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(IPAddress(192,168,4,1), IPAddress(192,168,4,1), IPAddress(255,255,255,0));
  WiFi.softAP("SO4T-CALL2", "<ESP32_AP_PASSWORD>", 6, 0, 4);
  // setTxPower 줄은 넣지 않음 (전파를 줄이면 연결이 끊겼음)
  server.on("/call", handleCall);
  server.on("/stop", handleStop);
  server.begin();
  Serial.println("READY");
}

void loop() {
  server.handleClient();
  if (digitalRead(STOP_BTN) == LOW) {
    calling = false;
    noTone(BUZZER);
    digitalWrite(LED, LOW);
  }
  if (calling) {
    digitalWrite(LED, HIGH);
    tone(BUZZER, 2000, 150);
    delay(150);
    digitalWrite(LED, LOW);
    delay(150);
  }
}
