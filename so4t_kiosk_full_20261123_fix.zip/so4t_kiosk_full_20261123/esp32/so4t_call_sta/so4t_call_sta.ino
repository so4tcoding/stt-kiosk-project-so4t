/* 소4트 직원 호출 보드 (ESP32-S3) - 핫스팟 자동 연결 버전 (2026-11-23)
   - 핫스팟(기본 AndroidHotspot3054)에 STA 로 접속. 핫스팟이 늦게 켜지거나 끊겨도 3초마다 다시 찾음
   - 파이와 서로 찾기 (IP 를 몰라도 됨)
       보드 → 2초마다 UDP 4210 방송 "SO4T-CALL <ip>"  (파이 중계가 듣고 보드 IP 저장)
       파이 → 2초마다 UDP 4211 방송 "SO4T-PI"        (보드가 듣고 파이 IP 저장)
   - 호출 받는 길 두 가지 (둘 중 하나만 돼도 울림)
       1) 파이가 보드로 http://<보드>/call?id=..   2) 보드가 1초마다 http://<파이>:8021/bell 확인
   - 소리로 상태 알림: 핫스팟 접속 '삑' 1번, 파이 찾음 '삑삑' 2번
   - LED(IO7): 핫스팟 못 찾음 = 1초마다 깜빡, 파이 못 찾음 = 3초마다 짧게, 다 됨 = 꺼짐, 호출 중 = 같이 깜빡
   - 30초 안에 핫스팟 접속 못 하면 예비 AP(SO4T-CALL2, 192.168.4.1)도 켬 (AP+STA)
     예비 AP 에 폰을 붙이고 http://192.168.4.1/setup 에서 핫스팟 이름/비밀번호를 바꿀 수 있음 (보드에 저장)
   - mDNS 이름: so4t-call.local
   - 엔드포인트: /call(부저 울림) /stop(끔) /ping("ok") / /setup(예비 AP 에서만)
   - 핀: 부저 IO5, 끄기 버튼 IO6-GND, (선택) LED IO7
   - Arduino IDE ESP32 코어 2.x / 3.x 용 (추가 라이브러리 필요 없음) */
#include <WiFi.h>
#include <WiFiMulti.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <WiFiUdp.h>
#include <HTTPClient.h>
#include <Preferences.h>

// ---- 설정 ----
const char* HOT_SSID = "AndroidHotspot3054";
const char* HOT_PASS = "<HOTSPOT_PASSWORD>";   // 대회 핫스팟 비밀번호 (팀 내부에서만 채우기)
// 두 번째 네트워크(선택): 비밀번호를 알면 아래 두 줄을 채우세요. 비워 두면 안 씀.
const char* WIFI2_SSID = "";
const char* WIFI2_PASS = "";
const char* AP_SSID = "SO4T-CALL2";
const char* AP_PASS = "<ESP32_AP_PASSWORD>";  // 예비 AP SO4T-CALL2 비밀번호 (8자 이상)
const char* HOSTNAME = "so4t-call";

const int BUZZER = 5;
const int STOP_BTN = 6;   // 직원 끄기 버튼 (IO6 - GND)
const int LED = 7;        // (선택) LED: IO7 - 220Ω - LED - GND

const uint16_t BEACON_PORT = 4210;   // 보드 → 파이
const uint16_t PI_PORT = 4211;       // 파이 → 보드
const uint16_t PI_BELL_PORT = 8021;  // 파이 중계의 /bell

WiFiMulti wifiMulti;
WebServer server(80);
WiFiUDP udp;
Preferences prefs;
String savedSsid, savedPass;
bool calling = false;
bool apStarted = false;
bool mdnsStarted = false;
bool wasConnected = false;
bool udpStarted = false;
bool piKnown = false;
IPAddress piIP;
String lastCallId = "";
unsigned long bootMs = 0;
unsigned long lastTry = 0;
unsigned long lastBeacon = 0;
unsigned long lastPoll = 0;
unsigned long pollGap = 1000;
unsigned long lastPiOk = 0;
unsigned long ledAt = 0;
int nets = 0;

bool isPlaceholder(const char* s) { return s == nullptr || strlen(s) == 0 || s[0] == '<'; }

void sendCors(const char* msg) {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "text/plain; charset=utf-8", msg);
}
void startCall(const char* how) {
  if (!calling) { Serial.print("[call] 호출 ("); Serial.print(how); Serial.println(")"); }
  calling = true;
}
void stopCall(const char* how) {
  calling = false; noTone(BUZZER); digitalWrite(LED, LOW);
  Serial.print("[call] 정지 ("); Serial.print(how); Serial.println(")");
}
void handleCall() {
  String id = server.hasArg("id") ? server.arg("id") : "";
  if (id.length()) {
    if (id == lastCallId) { sendCors("OK"); return; }   // 이미 /bell 확인으로 울린 호출
    lastCallId = id;
  }
  startCall("http");
  sendCors("OK");
}
void handleStop() { stopCall("http"); sendCors("STOP"); }
void handlePing() { sendCors("ok"); }
void handleRoot() {
  String s = "SO4T-CALL ok\nsta_ip=" + WiFi.localIP().toString() +
             "\nssid=" + WiFi.SSID() +
             "\npi=" + String(piKnown ? piIP.toString() : String("unknown")) +
             "\npi_ok_ago_s=" + String(lastPiOk ? (long)((millis() - lastPiOk) / 1000) : -1L) +
             "\nap=" + String(apStarted ? "on" : "off") +
             "\ncalling=" + String(calling ? "1" : "0") + "\n";
  sendCors(s.c_str());
}

// ---- 예비 AP 에서만 열리는 핫스팟 바꾸기 화면 ----
bool fromAP() {
  IPAddress c = server.client().remoteIP();
  return apStarted && c[0] == 192 && c[1] == 168 && c[2] == 4;
}
void handleSetup() {
  if (!fromAP()) { server.send(403, "text/plain; charset=utf-8", "SO4T-CALL2 예비 와이파이에 붙어서 http://192.168.4.1/setup 으로 여세요"); return; }
  String cur = savedSsid.length() ? savedSsid : String(HOT_SSID);
  String page = "<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width'>"
                "<h3>소4트 직원 호출 보드 - 핫스팟 바꾸기</h3>"
                "<p>지금 찾는 핫스팟: <b>" + cur + "</b></p>"
                "<form action='/save' method='post'>핫스팟 이름<br><input name='ssid' value='" + cur + "'><br>"
                "비밀번호<br><input name='pass' type='password'><br><br><button>저장하고 다시 시작</button></form>"
                "<p><a href='/forget'>저장한 값 지우기(스케치 값으로 돌아감)</a></p>";
  server.send(200, "text/html; charset=utf-8", page);
}
void handleSave() {
  if (!fromAP()) { server.send(403, "text/plain; charset=utf-8", "forbidden"); return; }
  String ss = server.arg("ssid"), pw = server.arg("pass");
  ss.trim();
  if (!ss.length() || (pw.length() && pw.length() < 8)) { server.send(400, "text/plain; charset=utf-8", "이름은 필수, 비밀번호는 8자 이상"); return; }
  prefs.begin("so4t", false); prefs.putString("ssid", ss); prefs.putString("pass", pw); prefs.end();
  server.send(200, "text/plain; charset=utf-8", "저장했어요. 보드가 다시 시작합니다.");
  delay(800);
  ESP.restart();
}
void handleForget() {
  if (!fromAP()) { server.send(403, "text/plain; charset=utf-8", "forbidden"); return; }
  prefs.begin("so4t", false); prefs.clear(); prefs.end();
  server.send(200, "text/plain; charset=utf-8", "지웠어요. 보드가 다시 시작합니다.");
  delay(800);
  ESP.restart();
}

void beep(int n) {
  for (int i = 0; i < n; i++) { tone(BUZZER, 2500, 80); delay(140); }
  noTone(BUZZER);
}

void startAP() {
  if (apStarted) return;
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(IPAddress(192,168,4,1), IPAddress(192,168,4,1), IPAddress(255,255,255,0));
  WiFi.softAP(AP_SSID, AP_PASS, 6, 0, 4);
  apStarted = true;
  Serial.println("[wifi] 핫스팟 접속 실패 → 예비 AP SO4T-CALL2(192.168.4.1)도 켬. 바꾸기: http://192.168.4.1/setup");
}

void onConnected() {
  Serial.print("[wifi] 핫스팟 접속 OK  SSID=");
  Serial.print(WiFi.SSID());
  Serial.print("  IP=");
  Serial.println(WiFi.localIP());
  if (!mdnsStarted) {
    if (MDNS.begin(HOSTNAME)) {
      MDNS.addService("http", "tcp", 80);
      mdnsStarted = true;
      Serial.println("[mdns] http://so4t-call.local");
    }
  }
  if (udpStarted) udp.stop();   // IP 가 바뀌었을 수 있어 다시 염
  udpStarted = udp.begin(PI_PORT);
  lastBeacon = 0;
  beep(1);
}

// ---- 파이와 서로 찾기 ----
void sendBeacon() {
  if (millis() - lastBeacon < 2000) return;
  lastBeacon = millis();
  String msg = "SO4T-CALL " + WiFi.localIP().toString();
  IPAddress targets[2] = { IPAddress(255,255,255,255), WiFi.broadcastIP() };
  for (int i = 0; i < 2; i++) {
    if (i == 1 && targets[1] == targets[0]) break;
    if (udp.beginPacket(targets[i], BEACON_PORT)) { udp.print(msg); udp.endPacket(); }
  }
  if (piKnown) {   // 방송이 막힌 핫스팟 대비: 아는 파이에게는 직접도 보냄
    if (udp.beginPacket(piIP, BEACON_PORT)) { udp.print(msg); udp.endPacket(); }
  }
}
void setPi(IPAddress ip, const char* how) {
  if (piKnown && ip == piIP) return;
  IPAddress me = WiFi.localIP(), mask = WiFi.subnetMask();
  for (int i = 0; i < 4; i++) if ((ip[i] & mask[i]) != (me[i] & mask[i])) return;   // 같은 핫스팟 안의 파이만
  bool first = !piKnown;
  piIP = ip; piKnown = true; pollGap = 1000;
  Serial.print("[pi] 파이 찾음 ("); Serial.print(how); Serial.print(") "); Serial.println(ip);
  if (first) beep(2);
}
void readUdp() {
  int n = udp.parsePacket();
  if (n <= 0) return;
  char buf[48];
  int len = udp.read(buf, sizeof(buf) - 1);
  if (len < 0) len = 0;
  buf[len] = 0;
  if (strncmp(buf, "SO4T-PI", 7) == 0) setPi(udp.remoteIP(), "udp");
}
void pollPi() {
  if (!piKnown || millis() - lastPoll < pollGap) return;
  lastPoll = millis();
  WiFiClient cl;
  HTTPClient http;
  String url = "http://" + piIP.toString() + ":" + String(PI_BELL_PORT) + "/bell?ip=" + WiFi.localIP().toString();
  http.setConnectTimeout(700);
  http.setTimeout(700);
  if (!http.begin(cl, url)) { pollGap = 3000; return; }
  int code = http.GET();
  if (code == 200) {
    String b = http.getString();   // "id=1763880000000 age=3"
    lastPiOk = millis(); pollGap = 1000;
    int i = b.indexOf("id="), j = b.indexOf(" age=");
    if (i >= 0 && j > i) {
      String id = b.substring(i + 3, j);
      long age = b.substring(j + 5).toInt();
      if (id != lastCallId) {
        if (id != "0" && age >= 0 && age <= 15) startCall("bell");
        lastCallId = id;
      }
    }
  } else {
    pollGap = 3000;
  }
  http.end();
}

void showLed(bool conn) {
  if (calling) return;
  unsigned long t = millis();
  if (!conn) { digitalWrite(LED, ((t / 500) % 2) ? HIGH : LOW); return; }
  if (!piKnown || (lastPiOk && t - lastPiOk > 10000) || !lastPiOk) { digitalWrite(LED, (t % 3000) < 120 ? HIGH : LOW); return; }
  digitalWrite(LED, LOW);
}

void setup() {
  Serial.begin(115200);
  delay(300);
  pinMode(STOP_BTN, INPUT_PULLUP);
  pinMode(LED, OUTPUT);
  digitalWrite(LED, LOW);

  prefs.begin("so4t", true);
  savedSsid = prefs.getString("ssid", "");
  savedPass = prefs.getString("pass", "");
  prefs.end();

  WiFi.persistent(false);
  WiFi.setHostname(HOSTNAME);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);          // 절전 끔 → 호출 응답 빠르게
  WiFi.setAutoReconnect(true);
  if (savedSsid.length()) { wifiMulti.addAP(savedSsid.c_str(), savedPass.c_str()); nets++; Serial.println("[wifi] 보드에 저장된 핫스팟: " + savedSsid); }
  if (!isPlaceholder(HOT_PASS)) { wifiMulti.addAP(HOT_SSID, HOT_PASS); nets++; }
  else Serial.println("[wifi] HOT_PASS 가 아직 자리표시자입니다. 스케치에 비밀번호를 넣거나 192.168.4.1/setup 에서 저장하세요.");
  if (strlen(WIFI2_SSID) > 0) { wifiMulti.addAP(WIFI2_SSID, WIFI2_PASS); nets++; }

  server.on("/call", handleCall);
  server.on("/stop", handleStop);
  server.on("/ping", handlePing);
  server.on("/setup", handleSetup);
  server.on("/save", handleSave);
  server.on("/forget", handleForget);
  server.on("/", handleRoot);
  server.begin();

  bootMs = millis();
  if (!nets) startAP();
  Serial.println("[boot] 소4트 직원 호출 보드 시작, 핫스팟 찾는 중...");
}

void loop() {
  server.handleClient();

  // ---- 와이파이 유지 (자동 재연결) ----
  bool conn = (WiFi.status() == WL_CONNECTED);
  if (!conn && nets > 0 && millis() - lastTry > (apStarted ? 10000UL : 3000UL)) {
    lastTry = millis();
    wifiMulti.run(2000);            // 핫스팟 다시 찾아서 접속 시도
    conn = (WiFi.status() == WL_CONNECTED);
  }
  if (conn && !wasConnected) {
    onConnected();
  } else if (!conn && wasConnected) {
    Serial.println("[wifi] 핫스팟 끊김 → 재접속 시도 중");
  }
  wasConnected = conn;
  if (!conn && !apStarted && millis() - bootMs > 30000) startAP();

  if (conn && udpStarted) {
    readUdp();
    sendBeacon();
    pollPi();
  }
  showLed(conn);

  // ---- 부저 ----
  if (digitalRead(STOP_BTN) == LOW && calling) stopCall("button");
  if (calling) {
    digitalWrite(LED, HIGH);
    tone(BUZZER, 2000, 150);
    delay(150);
    digitalWrite(LED, LOW);
    delay(150);
  }
}
