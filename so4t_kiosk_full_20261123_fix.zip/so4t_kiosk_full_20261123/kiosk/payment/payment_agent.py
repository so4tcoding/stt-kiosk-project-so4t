"""소4트 결제 에이전트 (파이에서 127.0.0.1:8010)
키오스크(payment.js, driver=local-agent)가 /pay /cancel /status 로 요청.
백엔드는 payment_config.json 의 agent.backend 로 고름: simulator | serial
실행: venv/bin/uvicorn payment_agent:app --host 127.0.0.1 --port 8010
"""
import asyncio, json, os, random, time
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

CFG_PATH = Path(os.environ.get("PAYMENT_CONFIG", Path(__file__).with_name("payment_config.json")))


def load_cfg():
    try:
        return json.loads(CFG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"agent": {"backend": "simulator"}, "timeoutSec": 60, "terminal": {}}


class PaymentBackend:
    """새 카드 단말기는 이 클래스를 상속해서 pay/cancel/status 만 구현하면 됨.
    pay 반환값: {"status": approved|declined|canceled|error, "approvalNo", "cardMasked", "message"}"""
    name = "base"

    async def pay(self, amount: int, order_id: str, timeout_sec: int) -> dict:
        raise NotImplementedError

    async def cancel(self, approval_no: str, amount: int, abort_pending: bool = False) -> dict:
        raise NotImplementedError

    async def status(self) -> dict:
        return {"ok": True}


def result(status, approval_no="", card_masked="", message=""):
    return {"status": status, "approvalNo": approval_no, "cardMasked": card_masked, "message": message}


class SimulatorBackend(PaymentBackend):
    """진짜 돈이 오가지 않는 흉내. 환경변수/요청으로 결과를 정함.
    SIM_RESULT=approved|declined|canceled|error|timeout (기본 approved), SIM_DELAY=초"""
    name = "simulator"

    def __init__(self, cfg):
        self.next = None
        self._waiter = None

    async def pay(self, amount, order_id, timeout_sec):
        kind = self.next or os.environ.get("SIM_RESULT", "approved")
        self.next = None
        delay = float(os.environ.get("SIM_DELAY", "2"))
        self._waiter = asyncio.get_running_loop().create_future()
        try:
            if kind == "timeout":
                await asyncio.wait_for(self._waiter, timeout_sec)
            else:
                await asyncio.wait_for(asyncio.shield(self._waiter), delay)
        except asyncio.TimeoutError:
            if kind == "timeout":
                return result("error", message=f"{timeout_sec}초 응답 없음(timeout)")
        else:
            return result("canceled", message="결제 중 취소됨")
        finally:
            self._waiter = None
        if kind == "approved":
            return result("approved", "SIM" + str(int(time.time()))[-8:], "SIM-****-****-0000", "시뮬레이터 승인")
        return result(kind if kind in ("declined", "canceled") else "error", message="시뮬레이터 " + kind)

    async def cancel(self, approval_no, amount, abort_pending=False):
        if self._waiter and not self._waiter.done():
            self._waiter.set_result(True)
            return result("canceled", message="진행 중 결제 중단")
        return result("canceled", approval_no, message="시뮬레이터 승인취소")

    async def status(self):
        return {"ok": True, "backend": self.name, "busy": self._waiter is not None}


class SerialTerminalBackend(PaymentBackend):
    """VAN 카드 단말기(시리얼/USB) 자리. 실제 통신 규격은 VAN사·단말기 제조사 SDK 문서에만 있음.
    여기엔 가짜 프로토콜 바이트를 넣지 않았음. 아래 TODO 를 SDK 문서대로 채워야 함."""
    name = "serial"

    def __init__(self, cfg):
        t = cfg.get("terminal", {})
        self.port = t.get("port", "/dev/ttyUSB0")
        self.baud = int(t.get("baud", 115200))
        self.ser = None

    def _open(self):
        import serial  # pip install pyserial
        if self.ser is None or not self.ser.is_open:
            self.ser = serial.Serial(self.port, self.baud, timeout=1)
        return self.ser

    async def pay(self, amount, order_id, timeout_sec):
        try:
            await asyncio.to_thread(self._open)
        except Exception as e:
            return result("error", message=f"단말기 포트 열기 실패({self.port}): {e}")
        # TODO(VAN SDK): 승인 요청 전문 만들기 (금액, 할부 0, 가맹점/단말기 ID) — SDK 문서 규격 그대로
        # TODO(VAN SDK): self.ser.write(요청전문) → timeout_sec 동안 응답 읽기 (ACK/NAK, 재전송 규칙 포함)
        # TODO(VAN SDK): 응답에서 승인번호, 마스킹 카드번호, 응답코드 해석 → result("approved"/"declined", ...)
        return result("error", message="serial 백엔드는 아직 미구현(TODO: VAN SDK 연동)")

    async def cancel(self, approval_no, amount, abort_pending=False):
        # TODO(VAN SDK): abort_pending 이면 진행 중 요청 중단 전문, 아니면 승인취소 전문(원승인번호, 원금액, 원거래일자)
        return result("error", approval_no, message="serial 취소 미구현(TODO)")

    async def status(self):
        return {"ok": False, "backend": self.name, "port": self.port, "baud": self.baud,
                "portExists": os.path.exists(self.port), "message": "TODO: 단말기 상태 확인 전문"}


BACKENDS = {"simulator": SimulatorBackend, "serial": SerialTerminalBackend}
CFG = load_cfg()
backend: PaymentBackend = BACKENDS.get(CFG.get("agent", {}).get("backend", "simulator"), SimulatorBackend)(CFG)
_lock = asyncio.Lock()

app = FastAPI(title="so4t payment agent")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"],
                   allow_methods=["GET", "POST"], allow_headers=["*"])


class PayReq(BaseModel):
    amount: int
    orderId: str = ""
    timeoutSec: int = 0


class CancelReq(BaseModel):
    approvalNo: str = ""
    amount: int = 0
    abortPending: bool = False


@app.post("/pay")
async def pay(r: PayReq):
    if r.amount <= 0:
        return result("error", message="금액 오류")
    if _lock.locked():
        return result("error", message="이미 결제 진행 중")
    async with _lock:
        t = r.timeoutSec or int(CFG.get("timeoutSec", 60))
        try:
            return await backend.pay(r.amount, r.orderId, t)
        except Exception as e:
            return result("error", message=str(e))


@app.post("/cancel")
async def cancel(r: CancelReq):
    try:
        return await backend.cancel(r.approvalNo, r.amount, r.abortPending)
    except Exception as e:
        return result("error", message=str(e))


@app.get("/status")
@app.post("/status")
async def status():
    s = await backend.status()
    s["backend"] = backend.name
    return s
