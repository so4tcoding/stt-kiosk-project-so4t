#!/bin/bash
# 소4트 키오스크 - 리눅스/맥 시뮬레이션용 실행
cd "$(dirname "$0")"
[ -f models/whisper-kiosk-ct2-int8/model.bin ] || { echo "학습 모델 없음 → WHISPER_MODEL=base"; export WHISPER_MODEL=base; }
export KIOSK_ADMIN_PASSWORD="${KIOSK_ADMIN_PASSWORD:-<ADMIN_PIN>}"
export KIOSK_SERIAL_BRIDGE="${KIOSK_SERIAL_BRIDGE:-0}"
exec python3 -m uvicorn stt_server:app --host 127.0.0.1 --port 8000
