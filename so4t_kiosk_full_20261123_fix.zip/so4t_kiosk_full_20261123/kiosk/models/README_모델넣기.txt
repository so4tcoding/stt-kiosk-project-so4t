이 폴더에 팀이 학습한 Whisper 모델 폴더를 넣어야 합니다 (zip 에는 용량 때문에 빠져 있음).

  kiosk/models/whisper-kiosk-ct2-int8/   ← 여기에 model.bin, config.json, tokenizer.json, vocabulary.* 등

- 원본 위치: 라즈베리파이 ~/kiosk_project/models/whisper-kiosk-ct2-int8/  또는 예전 노트북의 같은 폴더
- 파이에서 노트북으로 가져오기 (노트북 PowerShell):
    scp -r so4t@so4t.local:~/kiosk_project/models/whisper-kiosk-ct2-int8 .\models\
- 모델이 없으면 서버가 'model.bin 이 없습니다' 에서 멈출 수 있음
  → 시뮬레이션만 할 때는 환경변수 WHISPER_MODEL=base 로 켜면 기본 공개 모델을 인터넷에서 내려받아 사용(정확도는 학습 모델과 다름)
