// 소4트 관리자 웹앱 (Firebase Auth + Firestore)
const SDK = "https://www.gstatic.com/firebasejs/10.12.2/";
const { initializeApp } = await import(SDK + "firebase-app.js");
const A = await import(SDK + "firebase-auth.js");
const F = await import(SDK + "firebase-firestore.js");
const $ = id => document.getElementById(id);
const CFG = window.SO4T_FIREBASE_CONFIG;
if (!CFG || /^PASTE/.test(CFG.apiKey || "")) { $("msg").textContent = "firebase_config.js 를 먼저 채워 주세요."; throw new Error("no config"); }
const app = initializeApp(CFG), auth = A.getAuth(app), db = F.getFirestore(app);
const won = n => (Number(n) || 0).toLocaleString("ko-KR") + "원";
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});

/* ---------- 로그인 ---------- */
$("loginBtn").onclick = async () => {
  $("msg").textContent = ""; unlockAudio();
  try { await A.signInWithEmailAndPassword(auth, $("email").value.trim(), $("pw").value); }
  catch (e) { $("msg").textContent = "로그인 실패: " + e.code; }
};
$("logout").onclick = () => A.signOut(auth);
let unsubs = [];
A.onAuthStateChanged(auth, u => {
  unsubs.forEach(f => f()); unsubs = [];
  const ok = u && !u.isAnonymous;
  $("loginBox").classList.toggle("hide", !!ok); $("app").classList.toggle("hide", !ok); $("logout").classList.toggle("hide", !ok);
  if (ok) { watchCalls(); watchStats(); loadMenu(); }
});

/* ---------- 소리·알림 ---------- */
let ctx = null;
function unlockAudio() { try { ctx = ctx || new (window.AudioContext || window.webkitAudioContext)(); ctx.resume(); } catch (e) {} }
function beep() {
  if (!ctx) return;
  [0, 0.35, 0.7].forEach(t => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = 880; o.connect(g); g.connect(ctx.destination);
    g.gain.setValueAtTime(0.4, ctx.currentTime + t); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.3); o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.3); });
  try { navigator.vibrate && navigator.vibrate([300, 100, 300]); } catch (e) {}
}
$("enableAlert").onclick = async () => {
  unlockAudio(); beep();
  let p = "unsupported"; try { p = await Notification.requestPermission(); } catch (e) {}
  $("alertState").textContent = "소리 켜짐 · 알림 " + (p === "granted" ? "허용됨" : "꺼짐(" + p + ")") + ". 이 화면을 열어 두면 호출을 알려 줘요.";
};
async function notify(text) {
  beep();
  try {
    if (Notification.permission !== "granted") return;
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg) reg.showNotification("🙋 직원 호출", { body: text, tag: "call", renotify: true, requireInteraction: true });
    else new Notification("🙋 직원 호출", { body: text });
  } catch (e) {}
}

/* ---------- 직원 호출 ---------- */
const SRC = { button: "큰 버튼 길게", screen: "화면 버튼", test: "테스트" };
function watchCalls() {
  const q = F.query(F.collection(db, "calls"), F.where("status", "==", "open"));
  let first = true;
  unsubs.push(F.onSnapshot(q, snap => {
    if (!first) snap.docChanges().forEach(c => { if (c.type === "added") { const d = c.doc.data(); notify((d.kioskId || "") + " · " + (SRC[d.source] || d.source)); } });
    first = false;
    const list = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => String(b.timeISO).localeCompare(String(a.timeISO)));
    $("calls").innerHTML = list.length ? "" : "<p>들어온 호출이 없어요.</p>";
    list.forEach(c => {
      const el = document.createElement("div"); el.className = "call";
      const t = c.timeISO ? new Date(c.timeISO).toLocaleTimeString("ko-KR") : "";
      el.innerHTML = `<span>🙋 ${esc(c.kioskId)} · ${esc(SRC[c.source] || c.source)}<br><small>${esc(t)}</small></span>`;
      const b = document.createElement("button"); b.textContent = "확인";
      b.onclick = () => F.updateDoc(F.doc(db, "calls", c.id), { status: "done", doneAt: F.serverTimestamp() }).catch(e => alert("실패: " + e.code));
      el.appendChild(b); $("calls").appendChild(el);
    });
  }, e => { $("calls").innerHTML = "<p class='msg'>호출 읽기 실패: " + esc(e.code) + " (규칙의 관리자 이메일 확인)</p>"; }));
}

/* ---------- 통계 ---------- */
let chart = null;
function watchStats() {
  const start = new Date(); start.setHours(0, 0, 0, 0); start.setDate(start.getDate() - 6);
  const q = F.query(F.collection(db, "orders"), F.where("time", ">=", F.Timestamp.fromDate(start)));
  unsubs.push(F.onSnapshot(q, snap => {
    const orders = snap.docs.map(d => d.data());
    const todayKey = new Date().toDateString();
    const days = [...Array(7)].map((_, i) => { const d = new Date(start); d.setDate(d.getDate() + i); return d; });
    const rev = days.map(() => 0), top = {};
    let tc = 0, tr = 0;
    orders.forEach(o => {
      const d = o.time?.toDate ? o.time.toDate() : new Date(o.timeISO);
      const i = days.findIndex(x => x.toDateString() === d.toDateString()); if (i >= 0) rev[i] += Number(o.total) || 0;
      if (d.toDateString() === todayKey) { tc++; tr += Number(o.total) || 0; }
      (o.items || []).forEach(it => top[it.name] = (top[it.name] || 0) + (Number(it.count) || 1));
    });
    $("todayCount").textContent = tc + "건"; $("todayRev").textContent = won(tr);
    $("top").innerHTML = Object.entries(top).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([n, c]) => `<li>${esc(n)} — ${c}개</li>`).join("") || "<li>아직 주문이 없어요</li>";
    if (window.Chart) {
      const labels = days.map(d => (d.getMonth() + 1) + "/" + d.getDate());
      if (chart) { chart.data.datasets[0].data = rev; chart.update(); }
      else chart = new Chart($("chart"), { type: "bar", data: { labels, datasets: [{ label: "매출(원)", data: rev, backgroundColor: "#c2410c" }] },
        options: { plugins: { legend: { labels: { font: { size: 16 } } } }, scales: { x: { ticks: { font: { size: 16 } } }, y: { ticks: { font: { size: 14 } } } } } });
    } else $("statMsg").textContent = "차트 라이브러리를 못 불러왔어요(인터넷 확인).";
  }, e => { $("statMsg").textContent = "통계 읽기 실패: " + e.code; }));
}

/* ---------- 메뉴 편집 ---------- */
let loadedNames = [];
function row(m = {}) {
  const tr = document.createElement("tr");
  tr.innerHTML = `<td><input class="n" value="${esc(m.name)}"></td><td><input class="p" type="number" min="0" step="100" value="${esc(m.price ?? "")}"></td>
  <td><input class="c" value="${esc(m.category)}"></td><td><input class="t" value="${esc(m.taste)}"></td>
  <td><input class="s" type="checkbox" ${m.soldOut ? "checked" : ""} style="width:28px;height:28px"></td><td><button class="sub del">✕</button></td>`;
  tr.querySelector(".del").onclick = () => tr.remove();
  $("menuRows").appendChild(tr);
}
function fill(list) { $("menuRows").innerHTML = ""; list.forEach(row); }
async function loadMenu() {
  $("menuMsg").textContent = "";
  try {
    const s = await F.getDoc(F.doc(db, "config", "menu"));
    const list = s.exists() && Array.isArray(s.data().menus) ? s.data().menus : [];
    loadedNames = list.map(m => m.name); fill(list);
    if (!list.length) $("menuMsg").textContent = "저장된 메뉴가 없어요. '로컬 menu.json 가져오기'로 시작하세요.";
  } catch (e) { $("menuMsg").textContent = "불러오기 실패: " + e.code; }
}
$("loadMenu").onclick = loadMenu;
$("addRow").onclick = () => row();
$("importFile").onchange = async ev => {
  const f = ev.target.files[0]; if (!f) return;
  try { const d = JSON.parse(await f.text()); const list = Array.isArray(d) ? d : d.menus;
    if (!Array.isArray(list)) throw new Error("menus 배열 없음");
    fill(list); $("menuMsg").className = "ok"; $("menuMsg").textContent = list.length + "개 가져옴. 확인 후 저장을 누르세요.";
  } catch (e) { $("menuMsg").className = "msg"; $("menuMsg").textContent = "파일 오류: " + e.message; }
  ev.target.value = "";
};
$("saveMenu").onclick = async () => {
  const menus = [], names = new Set(); let err = "";
  [...$("menuRows").children].forEach((tr, i) => {
    const name = tr.querySelector(".n").value.trim(), price = Number(tr.querySelector(".p").value), category = tr.querySelector(".c").value.trim();
    if (!name && !category) return;
    if (!name || !category || !(price >= 0) || tr.querySelector(".p").value === "") err ||= `${i + 1}번째 줄: 이름·가격·분류를 채워 주세요`;
    if (names.has(name)) err ||= `'${name}' 이(가) 두 번 있어요`;
    names.add(name);
    menus.push({ name, price, category, taste: tr.querySelector(".t").value.trim(), soldOut: tr.querySelector(".s").checked });
  });
  if (!menus.length) err ||= "메뉴가 하나도 없어요";
  $("menuMsg").className = "msg";
  if (err) { $("menuMsg").textContent = err; return; }
  const removed = loadedNames.filter(n => !names.has(n));
  try {
    await F.setDoc(F.doc(db, "config", "menu"), { version: Date.now(), full: true, menus, removed, updated: F.serverTimestamp(), updatedBy: auth.currentUser.email });
    loadedNames = menus.map(m => m.name);
    $("menuMsg").className = "ok"; $("menuMsg").textContent = "저장했어요 (" + menus.length + "개)";
  } catch (e) { $("menuMsg").textContent = "저장 실패: " + e.code; }
};
