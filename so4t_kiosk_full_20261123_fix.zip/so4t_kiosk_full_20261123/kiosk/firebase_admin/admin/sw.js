// 홈 화면 앱(PWA)용 서비스 워커: 알림 표시 + 알림 누르면 앱 열기. (FCM 백그라운드 푸시는 없음)
self.addEventListener("install", e => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", () => {});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: "window" }).then(cs => cs.length ? cs[0].focus() : self.clients.openWindow("./index.html")));
});
