/* 소4트 Firebase 설정 — 이 파일 하나만 고치면 됩니다.
   Firebase 콘솔 > 프로젝트 설정 > 내 앱(웹) > "SDK 설정 및 구성" > "구성(Config)"에 나오는 값을 그대로 붙여넣으세요.
   apiKey가 "PASTE_..."로 남아 있으면 키오스크는 Firebase를 아예 안 쓰고 지금처럼 오프라인으로만 동작합니다. */
window.SO4T_FIREBASE_CONFIG = {
  apiKey: "PASTE_<FIREBASE_API_KEY>",
  authDomain: "<FIREBASE_PROJECT_ID>.firebaseapp.com",
  projectId: "<FIREBASE_PROJECT_ID>",
  storageBucket: "<FIREBASE_PROJECT_ID>.firebasestorage.app",
  messagingSenderId: "<FIREBASE_SENDER_ID>",
  appId: "<FIREBASE_APP_ID>"
};
/* 키오스크 이름(여러 대일 때 구분용). 원하면 바꾸세요. */
window.SO4T_KIOSK_ID = window.SO4T_KIOSK_ID || "kiosk-1";
