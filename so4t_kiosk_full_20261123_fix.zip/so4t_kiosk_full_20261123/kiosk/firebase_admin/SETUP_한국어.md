# 소4트 키오스크 × Firebase 설치 가이드

이 애드온이 하는 일
- 주문이 끝나면 Firestore `orders`에 기록해요(메뉴, 수량, 합계, 시간, 키오스크 이름, 음성/터치 추정, 직원 호출 횟수).
- 직원 호출(버튼 2초 또는 화면 버튼)이 들어오면 `calls`에 기록하고, 관리자 폰에서 소리와 알림이 울려요. ESP32 부저도 그대로 울려요.
- 관리자 웹에서 고친 메뉴(`config/menu`)를 키오스크가 읽어요. 메뉴가 없거나 잘못됐으면 파이의 menu.json을 그대로 써요.
- 인터넷이나 Firebase가 안 돼도 키오스크는 지금처럼 오프라인으로 동작해요.

## 1. Firebase 프로젝트 만들기 (노트북 브라우저)
1. https://console.firebase.google.com 에 구글 계정으로 들어가요.
2. **프로젝트 추가**를 눌러요. 이름은 예를 들어 `so4t-kiosk`로 하고, 애널리틱스는 꺼도 돼요.
3. 왼쪽 **빌드 → Firestore Database → 데이터베이스 만들기**를 눌러요. 위치는 `asia-northeast3 (서울)`, 모드는 **프로덕션 모드**로 해요.
4. **빌드 → Authentication → 시작하기 → 로그인 방법**에서 **이메일/비밀번호**와 **익명**을 둘 다 "사용 설정"해요.
5. Authentication의 **사용자 → 사용자 추가**에서 관리자 이메일과 비밀번호를 만들어요. 이게 관리자 웹 로그인 계정이에요.
6. **프로젝트 설정(톱니바퀴) → 내 앱 → 웹(</>)**에서 앱을 등록해요. 이름은 `kiosk`로 하고, Hosting 체크는 안 해도 돼요.
   그다음 나오는 `firebaseConfig = { ... }` 안의 값 6개를 복사해요.

## 2. 설정 파일 채우기
- 압축을 푼 폴더의 **`firebase_config.js`**를 열고 `PASTE_...` 자리에 6개 값을 붙여 넣어요. 따옴표는 그대로 둬요.
- 똑같은 파일을 **`admin/firebase_config.js`**에도 복사해요. 덮어쓰면 돼요.
- **`firestore.rules`**에서 `ADMIN_EMAIL@example.com`을 5번에서 만든 관리자 이메일로 바꿔요. 안 바꾸면 관리자 화면에 아무것도 안 보여요.
- (참고) 이 웹 설정값은 비밀번호가 아니라서 공개돼도 괜찮아요. 데이터는 규칙이 지켜 줘요. 그래도 깃허브에는 안 올리는 걸 추천해요.

## 3. 규칙과 관리자 웹 올리기 (노트북, Node.js 필요)
1. Node.js LTS를 설치해요(https://nodejs.org).
2. 명령 프롬프트를 열고 압축을 푼 폴더로 이동해요.
```
npm install -g firebase-tools
firebase login
firebase use --add        (목록에서 내 프로젝트를 고르고, 별칭은 default)
firebase deploy --only firestore:rules,hosting
```
3. 끝나면 나오는 `Hosting URL`(https://프로젝트ID.web.app)이 관리자 웹 주소예요.

## 4. 폰에서 관리자 웹 쓰기
1. 폰 크롬(아이폰은 사파리)에서 Hosting URL을 열고 로그인해요.
2. **🔊 알림·소리 켜기**를 누르고 알림을 허용해요.
3. 크롬 메뉴의 **홈 화면에 추가**나 **앱 설치**를 누르면 앱처럼 쓸 수 있어요. 아이폰은 홈 화면에 추가한 앱에서만 알림이 돼요(iOS 16.4 이상).
4. ⚠ 알림은 **관리자 화면이 열려 있을 때만** 와요. 화면을 끄거나 앱을 완전히 닫으면 안 울려요. 카운터 쪽 폰이나 태블릿에 켜 두세요.
5. 처음이면 메뉴 편집에서 **로컬 menu.json 가져오기**를 눌러 파이의 menu.json 파일을 고르고(USB로 옮기기) **저장**해요.

## 5. 파이에 설치
노트북에서:
```
scp .\firebase_addon.zip 아이디@파이IP:~
```
(2번에서 firebase_config.js를 채운 뒤 다시 압축한 zip이어야 해요. 아니면 파이에서 `nano firebase_addon/firebase_config.js`로 직접 채워도 돼요.)
파이에서:
```
unzip -o firebase_addon.zip -d firebase_addon
bash firebase_addon/install_firebase_addon.sh
sudo reboot
```
설정을 나중에 고쳤다면 설치 스크립트를 한 번 더 돌리면 돼요(여러 번 돌려도 안전해요).

## 6. 확인
- 키오스크에서 F12를 눌러 콘솔을 열고, `[firebase] 연결됨`과 `__kioskStaffCall hooked`가 보이는지 봐요.
- 콘솔에 `__fbTest()`를 치면 관리자 폰에 테스트 호출이 와야 해요. **확인**을 누르면 사라져요.
- 주문을 하나 끝까지 하면 관리자 웹의 오늘 주문이 1건 늘어나요.
- 상태 보기: 콘솔에서 `__so4tFirebase`

## 지우기
`bash firebase_addon/uninstall_firebase_addon.sh` (kiosk.html 백업도 `kiosk.html.bak_firebase_*`로 남아 있어요)
