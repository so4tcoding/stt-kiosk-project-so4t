/* 소4트 ESP32 무선 직원 호출 애드온 v2 (SO4T-ESP32-HOTSPOT, 2026-11-17)
   window.__kioskStaffCall 을 감싸서(원래 함수 먼저 실행) 직원 호출 보드로 신호를 추가로 보낸다.
   1순위: 파이 중계 http://127.0.0.1:8020/call → so4t_call.sh 가 핫스팟에서 보드를 찾아 전달
   2순위(중계가 안 될 때): 예전 방식 http://192.168.4.1/call
   실패는 모두 무시 → 화면 호출은 항상 그대로 동작. */
(function () {
  "use strict";
  var RELAY = "http://127.0.0.1:8020/call";
  var LEGACY = "http://192.168.4.1/call";
  var COOLDOWN_MS = 5000, TIMEOUT_MS = 2500, lastAt = 0;

  function hit(url, src, now) {
    var ctrl = (typeof AbortController === "function") ? new AbortController() : null;
    var t = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, TIMEOUT_MS) : null;
    return fetch(url + "?src=" + encodeURIComponent(String(src || "unknown")) + "&t=" + now,
                 { mode: "no-cors", cache: "no-store", signal: ctrl ? ctrl.signal : undefined })
      .then(function (r) { if (t) clearTimeout(t); return r; },
            function (e) { if (t) clearTimeout(t); throw e; });
  }

  function signal(source) {
    var now = Date.now();
    if (now - lastAt < COOLDOWN_MS) return;
    lastAt = now;
    try {
      hit(RELAY, source, now)
        .then(function () { console.log("[esp32] call sent (relay)"); })
        .catch(function () {
          return hit(LEGACY, source, now)
            .then(function () { console.log("[esp32] call sent (192.168.4.1)"); });
        })
        .catch(function (e) { console.warn("[esp32] call failed (무시)", e && e.name); });
    } catch (e) {}
  }

  function wrap() {
    var orig = window.__kioskStaffCall;
    if (typeof orig !== "function") return false;
    if (orig.__esp32Wrapped) return true;
    var wrapped = function () {
      var r;
      try { r = orig.apply(this, arguments); }
      finally { try { signal(arguments[0]); } catch (e) {} }
      return r;
    };
    wrapped.__esp32Wrapped = true;
    wrapped.__esp32Orig = orig;
    window.__kioskStaffCall = wrapped;
    console.log("[esp32] __kioskStaffCall hooked (v2 hotspot)");
    return true;
  }

  window.__esp32Call = signal;   // 수동 테스트용: 콘솔에서 __esp32Call("test")
  if (!wrap()) {
    var tries = 0, iv = setInterval(function () { if (wrap() || ++tries > 60) clearInterval(iv); }, 500);
  }
  window.addEventListener("load", wrap);
  setInterval(wrap, 5000);
})();
