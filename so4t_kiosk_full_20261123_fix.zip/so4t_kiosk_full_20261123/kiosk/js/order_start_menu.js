/* 소4트 애드온: 첫 화면에서 "주문 시작" → 바로 메뉴판(category_select)
   기존 기능은 지우지 않고 processVoiceCommand 앞에 한 겹 덧씌움.
   "네", "사용법 알려줘" 등 다른 말은 원래대로 처리. */
(function () {
    "use strict";
    var START_RE = /주문시작|주문을?시작|주문할게|주문할래|주문하겠|주문할께|주문하고싶|바로주문|시작할게|시작할께|시작해줘|시작하자/;
    var STAGES = { welcome: 1, open_order_prompt: 1, guide: 1 };

    function stage() {
        try { return currentStageName; } catch (e) { return window.currentStageName; }
    }
    function norm(t) { return String(t || "").toLowerCase().replace(/[\s,.'"?!~…]+/g, ""); }

    function goMenu() {
        try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (e) {}
        try { isAddOnPhase = false; } catch (e) {}
        try { orderState = { items: [], place: "", pay: "" }; } catch (e) {}
        try { if (typeof emptyTempItem === "function") tempItem = emptyTempItem(); } catch (e) {}
        try { document.body.classList.remove("clean-start-screen"); } catch (e) {}
        transitionTo("category_select", renderCategorySelect);
    }

    function wrap() {
        var prev = window.processVoiceCommand;
        if (typeof prev !== "function" || prev.__orderStartMenu) return false;
        var wrapped = function orderStartMenuProcessVoiceCommand(text) {
            try {
                var c = norm(text);
                if (STAGES[stage()] && START_RE.test(c) && !/사용법|방법|어떻게|설명|취소|안할|안해|말고/.test(c) &&
                    typeof transitionTo === "function" && typeof renderCategorySelect === "function") {
                    console.log("[orderStart] '" + text + "' → 메뉴판");
                    goMenu();
                    return;
                }
            } catch (e) { console.warn("[orderStart] 오류, 원래 처리로 넘김", e); }
            return prev.apply(this, arguments);
        };
        wrapped.__orderStartMenu = true;
        window.processVoiceCommand = wrapped;
        try { processVoiceCommand = wrapped; } catch (e) {}
        console.log("[orderStart] processVoiceCommand hooked");
        return true;
    }

    wrap();
    window.addEventListener("load", function () { setTimeout(wrap, 0); });
    // 나중에 다른 패치가 processVoiceCommand를 또 바꾸면 다시 맨 위에 씌움
    setInterval(wrap, 2000);
    window.__orderStartTest = function (t) { return window.processVoiceCommand(t || "주문 시작"); };
})();
