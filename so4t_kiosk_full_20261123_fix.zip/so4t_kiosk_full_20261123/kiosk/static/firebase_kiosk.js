/* 소4트 Firebase 애드온 (키오스크 쪽)
   - 주문 완료 → Firestore orders, 직원 호출 → calls, 시작 시 config/menu 읽기
   - 모든 호출은 기다리지 않고(fire-and-forget) 시간 제한이 있음. Firebase가 안 되면 키오스크는 원래대로 동작.
   - 기존 기능은 지우지 않음: __kioskStaffCall 은 원래 함수(+ESP32 훅)를 먼저 부르고 덧붙이기만 함. */
(function () {
  "use strict";
  var SDK = "https://www.gstatic.com/firebasejs/10.12.2/";
  var CFG = window.SO4T_FIREBASE_CONFIG;
  var KID = String(window.SO4T_KIOSK_ID || "kiosk-1");
  var FBX = window.__so4tFirebase = { ready: false, error: "", remoteMenu: null, sent: { orders: 0, calls: 0, sessions: 0, unrecognized: 0 }, corrections: null, log: [] };
  function log(m) { FBX.log.push(new Date().toLocaleTimeString() + " " + m); if (FBX.log.length > 50) FBX.log.shift(); console.log("[firebase] " + m); }
  function timeout(p, ms) { return Promise.race([p, new Promise(function (_, rej) { setTimeout(function () { rej(new Error("timeout " + ms + "ms")); }, ms); })]); }
  if (!CFG || !CFG.apiKey || /^PASTE/.test(CFG.apiKey)) { FBX.error = "config 없음"; log("firebase_config.js 미설정 → 사용 안 함"); return; }

  /* ---- Firebase 준비 (실패해도 조용히) ---- */
  var api = null, db = null;
  var ready = timeout(Promise.all([
    import(SDK + "firebase-app.js"), import(SDK + "firebase-auth.js"), import(SDK + "firebase-firestore.js")
  ]), 8000).then(function (m) {
    var app = m[0].initializeApp(CFG);
    api = m[2]; db = api.getFirestore(app);
    return timeout(m[1].signInAnonymously(m[1].getAuth(app)), 8000);
  }).then(function () { FBX.ready = true; log("연결됨 (익명 로그인)"); return true; })
    .catch(function (e) { FBX.error = String(e && e.message || e); log("연결 실패 → 오프라인 그대로: " + FBX.error); return false; });

  function add(col, data) {
    ready.then(function (ok) {
      if (!ok) return;
      data.createdAt = api.serverTimestamp();
      if (data.time === undefined && data.timeISO) { var dt = new Date(data.timeISO); data.time = api.Timestamp.fromDate(isFinite(dt) ? dt : new Date()); } // 시니어 애드온(unrecognized) 등
      return timeout(api.addDoc(api.collection(db, col), data), 6000).then(function () { FBX.sent[col]++; log(col + " 기록"); });
    }).catch(function (e) { log(col + " 기록 실패(무시): " + (e && e.message)); });
  }
  FBX.add = add;

  /* ---- 2) 직원 호출: 원래 함수 감싸기 ---- */
  var lastCall = 0;
  function hookStaff() {
    var orig = window.__kioskStaffCall;
    if (typeof orig !== "function") return false;
    if (orig.__fbHooked) return true;
    var wrapped = function (source) {
      var r; try { r = orig.apply(this, arguments); } finally {
        try {
          var now = Date.now();
          if (now - lastCall >= 10000) {           // 원래 코드와 같은 10초 중복 방지
            lastCall = now;
            add("calls", { time: api ? api.Timestamp.fromDate(new Date()) : null, timeISO: new Date().toISOString(), source: String(source || "unknown"), kioskId: KID, status: "open" });
          }
        } catch (e) {}
      }
      return r;
    };
    wrapped.__fbHooked = true;
    for (var k in orig) { try { if (!(k in wrapped)) wrapped[k] = orig[k]; } catch (e) {} }
    window.__kioskStaffCall = wrapped;
    log("__kioskStaffCall hooked");
    return true;
  }
  if (!hookStaff()) { var t = setInterval(function () { if (hookStaff()) clearInterval(t); }, 1000); setTimeout(function () { clearInterval(t); }, 30000); }

  /* ---- 1) 주문 기록: V8 통계가 만든 주문 완료 이벤트(__kioskV8.lastEvent)를 받아 씀 ---- */
  var seen = null;
  setInterval(function () {
    try {
      var V8 = window.__kioskV8; var ev = V8 && V8.lastEvent;
      if (!ev || ev === seen) return;
      seen = ev;
      if (ev.result !== "completed") return;
      var items = (ev.items || []).map(function (i) { return { name: String(i.item || ""), count: Number(i.count) || 1, isSet: !!i.isSet }; });
      var utter = 0; Object.keys(ev.stages || {}).forEach(function (k) { utter += Number(ev.stages[k].utterances) || 0; });
      add("orders", Object.assign({
        items: items, qty: items.reduce(function (s, i) { return s + i.count; }, 0), total: Number(ev.total) || 0,
        time: api ? api.Timestamp.fromDate(new Date(ev.end || Date.now())) : null, timeISO: String(ev.end || new Date().toISOString()),
        durationMs: Number(ev.durationMs) || 0, kioskId: KID,
        inputMode: utter > 0 ? "voice" : "touch",   // 추정: 주문 중 음성 발화가 1번이라도 있으면 voice
        staffCalls: Number(ev.staffCalls) || 0, offline: !!(ev.fallback || ev.offlineNow)
      }, payFor(ev)));
    } catch (e) {}
  }, 1000);

  /* ---- 1-b) 결제 결과(결제 애드온 so4t:payment 이벤트) · 세션 기록(통계용) ---- */
  var payLog = [];
  window.addEventListener("so4t:payment", function (e) {
    try { var d = e.detail || {}; payLog.push({ status: String(d.status || ""), driver: String(d.driver || ""), amount: Number(d.amount) || 0, t: Date.parse(d.time) || Date.now() }); if (payLog.length > 30) payLog.shift(); } catch (er) {}
  });
  function payOf(ev) {   // 이 주문(세션) 동안 일어난 카드 결제 시도만 (카드번호·승인번호는 안 보냄)
    var a = Date.parse(ev.start) || 0, b = (Date.parse(ev.end) || Date.now()) + 3000;
    var l = payLog.filter(function (p) { return p.t >= a && p.t <= b && !/^refund_/.test(p.status); });
    if (!l.length) return null;
    var last = l[l.length - 1];
    return { status: last.status, driver: last.driver, attempts: l.length, amount: last.amount };
  }
  function payFor(ev) { var p = payOf(ev); return p ? { payment: p } : {}; }
  var seenS = null;
  setInterval(function () {
    try {
      var V8 = window.__kioskV8; var ev = V8 && V8.lastEvent;
      if (!ev || ev === seenS) return;
      seenS = ev;
      if (ev.result !== "completed" && ev.result !== "abandoned") return;
      var utter = 0; Object.keys(ev.stages || {}).forEach(function (k) { utter += Number(ev.stages[k].utterances) || 0; });
      var SP = window.__so4tSenior, first = "unknown";
      try { if (SP && SP.firstInputFor) first = SP.firstInputFor(ev.start) || "unknown"; } catch (e) {}
      if (["voice", "touch", "unknown"].indexOf(first) < 0) first = "unknown";
      var d = { result: ev.result, startISO: String(ev.start || ""), timeISO: String(ev.end || new Date().toISOString()),
        durationMs: Number(ev.durationMs) || 0, firstInput: first, utterances: utter, staffCalls: Number(ev.staffCalls) || 0,
        offline: !!(ev.fallback || ev.offlineNow), total: Number(ev.total) || 0, kioskId: KID };
      var p = payOf(ev); if (p) d.payment = p;
      add("sessions", d);
    } catch (e) {}
  }, 1000);


  /* ---- 3) 원격 메뉴: config/menu 가 올바를 때만 /menu.json 대신 사용 ---- */
  function validMenu(d) {
    if (!d || !Array.isArray(d.menus) || !d.menus.length || d.menus.length > 300) return false;
    var names = {};
    return d.menus.every(function (m) {
      if (!m || typeof m.name !== "string" || !m.name.trim() || names[m.name]) return false;
      names[m.name] = 1;
      return typeof m.price === "number" && isFinite(m.price) && m.price >= 0 && typeof m.category === "string" && !!m.category.trim();
    });
  }
  FBX.validMenu = validMenu;
  function clean(d) {
    return { version: Number(d.version) || 1, full: true, source: "firebase", menus: d.menus.map(function (m) {
      var o = { name: m.name.trim(), price: m.price, category: m.category.trim(), taste: String(m.taste || ""), soldOut: !!m.soldOut };
      // 시니어 애드온: 맵기(0~3)·알레르기(목록)는 관리자가 넣은 것만 옮김 (없으면 안 만듦)
      if (m.spicy !== undefined && m.spicy !== null && m.spicy !== "" && isFinite(Number(m.spicy))) o.spicy = Math.max(0, Math.min(3, Math.round(Number(m.spicy))));
      if (Array.isArray(m.allergens)) o.allergens = m.allergens.map(String).filter(function (x) { return x.trim(); }).slice(0, 30);
      return o; }),
      removed: Array.isArray(d.removed) ? d.removed.map(String) : [] };
  }
  // 키오스크가 2분마다 /menu.json 을 다시 읽으므로, 원격 메뉴가 있으면 그 응답만 바꿔치기 (로컬 파일은 안 건드림)
  var origFetch = window.fetch;
  window.fetch = function (input, init) {
    try {
      var url = typeof input === "string" ? input : (input && input.url) || "";
      var path = url.replace(/^https?:\/\/[^/]+/, "").split("?")[0];
      if (FBX.remoteMenu && path === "/menu.json" && (!init || !init.method || init.method === "GET"))
        return Promise.resolve(new Response(JSON.stringify(FBX.remoteMenu), { status: 200, headers: { "Content-Type": "application/json" } }));
    } catch (e) {}
    return origFetch.apply(this, arguments);
  };
  function loadRemoteMenu() {
    ready.then(function (ok) {
      if (!ok) return;
      return timeout(api.getDoc(api.doc(db, "config", "menu")), 6000).then(function (s) {
        var d = s.exists() ? s.data() : null;
        if (!validMenu(d)) { FBX.remoteMenu = null; log("원격 메뉴 없음/형식 오류 → 로컬 menu.json 사용"); return; }
        FBX.remoteMenu = clean(d);
        try { if (window.__kioskV8 && window.__kioskV8.applyMenuJson) window.__kioskV8.applyMenuJson(FBX.remoteMenu); } catch (e) { log("메뉴 반영 실패: " + e.message); }
        log("원격 메뉴 적용 " + d.menus.length + "개");
      });
    }).catch(function (e) { log("원격 메뉴 읽기 실패(로컬 사용): " + (e && e.message)); });
  }
  loadRemoteMenu();
  /* ---- 4) 오인식 교정 사전: config/corrections { map: { "틀린말": "맞는말" } } ---- */
  function loadCorrections() {
    ready.then(function (ok) {
      if (!ok) return;
      return timeout(api.getDoc(api.doc(db, "config", "corrections")), 6000).then(function (s) {
        var m = s.exists() && s.data() && s.data().map, out = {};
        if (m && typeof m === "object") Object.keys(m).slice(0, 500).forEach(function (k) { if (typeof m[k] === "string" && k.trim() && k.length <= 40 && m[k].length <= 40) out[k] = m[k]; });
        FBX.corrections = out; log("교정 사전 " + Object.keys(out).length + "개");
      });
    }).catch(function (e) { log("교정 사전 읽기 실패(로컬 사용): " + (e && e.message)); });
  }
  loadCorrections();
  setInterval(function () { var s = ""; try { s = currentStageName; } catch (e) {} if (s === "welcome" || s === "sleep") { loadRemoteMenu(); loadCorrections(); } }, 120000);

  window.__fbTest = function () { add("calls", { time: api ? api.Timestamp.fromDate(new Date()) : null, timeISO: new Date().toISOString(), source: "test", kioskId: KID, status: "open" }); return "테스트 호출 보냄"; };
})();
