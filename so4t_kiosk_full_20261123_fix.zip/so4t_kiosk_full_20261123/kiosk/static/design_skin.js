/* 소4트 디자인 스킨 애드온 (design_skin.js)
   겉모습만 바꿈: 마스코트 SVG + 말풍선 + 카테고리 줄을 화면에 "장식"으로 붙임.
   - 기존 함수/상태/이벤트/ID 는 건드리지 않음 (읽지도 덮어쓰지도 않음)
   - 붙인 요소는 전부 pointer-events:none, aria-hidden */
(function () {
  "use strict";
  if (window.__so4tDesign) return;
  window.__so4tDesign = { version: "2.0" };
  var MASCOT =
    '<svg viewBox="0 0 220 230" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<g stroke="#22252B" stroke-width="5" stroke-linecap="round" stroke-linejoin="round">' +
    // 왼팔
    '<path d="M52 150 Q30 165 36 186" fill="none"/>' +
    // 몸
    '<circle cx="104" cy="140" r="62" fill="#FFD66B"/>' +
    // 셰프 모자
    '<path d="M70 82 Q52 80 54 60 Q58 40 80 46 Q86 22 106 24 Q128 22 132 46 Q154 40 158 60 Q160 80 140 82 Z" fill="#FFFFFF"/>' +
    '<rect x="72" y="80" width="66" height="16" rx="6" fill="#FFFFFF"/>' +
    // 오른팔(흔들기)
    '<g class="ds-wave"><path d="M160 128 Q182 112 188 88" fill="none"/>' +
    '<circle cx="190" cy="82" r="8" fill="#FFD66B"/></g>' +
    '</g>' +
    // 눈, 볼, 입
    '<circle cx="86" cy="134" r="5.5" fill="#22252B"/><circle cx="122" cy="134" r="5.5" fill="#22252B"/>' +
    '<ellipse cx="72" cy="152" rx="10" ry="6" fill="#FF9B85" opacity=".8"/><ellipse cx="136" cy="152" rx="10" ry="6" fill="#FF9B85" opacity=".8"/>' +
    '<path d="M94 150 Q104 160 114 150" fill="none" stroke="#22252B" stroke-width="4.5" stroke-linecap="round"/>' +
    '</svg>';
  var CATS = "국밥 · 불고기 · 햄버거 · 커피 · 음료 · 디저트";

  function mount() {
    var orb = document.getElementById("ai-mic-orb");
    if (!orb || !orb.parentNode) return;
    var hero = orb.parentNode;
    if (!document.getElementById("ds-mascot")) {
      var m = document.createElement("div");
      m.id = "ds-mascot"; m.setAttribute("aria-hidden", "true");
      m.innerHTML = MASCOT +
        '<div id="ds-bubble"><b>안녕하세요!</b><span class="ds-hello">말로 주문해 보세요</span><span class="ds-listen">듣고 있어요…</span></div>';
      hero.insertBefore(m, hero.firstChild);
    }
    if (!document.getElementById("ds-cats")) {
      var c = document.createElement("div");
      c.id = "ds-cats"; c.setAttribute("aria-hidden", "true"); c.textContent = CATS;
      hero.insertBefore(c, hero.firstChild);
    }
    if (!document.getElementById("ds-hint")) {
      var h = document.createElement("div");
      h.id = "ds-hint"; h.setAttribute("aria-hidden", "true"); h.textContent = "큰 버튼 2초";
      document.body.appendChild(h);
    }
    document.documentElement.classList.add("so4t-design");
  }
  function boot() { mount(); setInterval(mount, 1500); } // 다른 코드가 DOM 을 다시 그려도 장식만 다시 붙임
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();

  /* v2: 처음 화면·절전 화면·직원 호출 화면에도 캐릭터, 시작 문구는 화면 글자만 교체 */
  var SLEEPY = MASCOT.replace('<circle cx="86" cy="134" r="5.5" fill="#22252B"/><circle cx="122" cy="134" r="5.5" fill="#22252B"/>',
      '<path d="M79 134 Q86 140 93 134" fill="none" stroke="#22252B" stroke-width="4.5" stroke-linecap="round"/><path d="M115 134 Q122 140 129 134" fill="none" stroke="#22252B" stroke-width="4.5" stroke-linecap="round"/>')
      .replace('</svg>', '<text class="ds-z" x="170" y="40" font-size="34" font-weight="900" fill="#FF7A59">Z</text></svg>');
  function deco(parentId, id, svg) {
    var p = document.getElementById(parentId);
    if (!p || document.getElementById(id)) return;
    var d = document.createElement("div"); d.id = id; d.setAttribute("aria-hidden", "true"); d.innerHTML = svg;
    p.insertBefore(d, p.firstChild);
  }
  function mount2() {
    deco("boot-overlay", "ds-boot-mascot", MASCOT);
    deco("v8-staff-overlay", "ds-staff-mascot", MASCOT);
    var so = document.getElementById("button-sleep-overlay");
    if (so && !document.getElementById("ds-sleep-mascot")) deco("button-sleep-overlay", "ds-sleep-mascot", SLEEPY);
    var sf = document.getElementById("sleep-overlay-final");
    if (sf && !sf.querySelector(".ds-sleep2")) { var w = sf.firstElementChild || sf; var d = document.createElement("div"); d.className = "ds-sleep2"; d.id = so ? "" : "ds-sleep-mascot"; d.setAttribute("aria-hidden", "true"); d.style.cssText = "pointer-events:none;width:200px;height:208px;margin:0 auto 10px"; d.innerHTML = SLEEPY; w.insertBefore(d, w.firstChild); }
    var ap = document.getElementById("ai-prompt");
    var isStart = !!ap && ap.textContent.replace(/\s+/g, "") === "주문을시작하시겠습니까?";
    document.documentElement.classList.toggle("ds-start-title", isStart);
  }
  setInterval(mount2, 300);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount2); else mount2();
  console.log("[design] skin loaded");
})();
