/* 소4트 시니어 플러스 애드온 (senior_plus.js)
   1) 말 속도·글씨 크기 (세션 동안만, 첫 화면에서 기본값으로)
   2) 지난 주문 다시 하기 (localStorage, 최근 3건, 개인정보 없음)
   3) 결제 전 주문 다시 읽기 (askPaymentStage 앞, V8 '주문 내역 확인'을 이미 거쳤으면 중복 안 함)
   4) 맵기·알레르기 안내 (menu_info.json + Firebase config/menu 의 spicy/allergens, 없으면 지어내지 않음)
   5) 오인식 교정 사전 + 경상도 사투리 보정 (corrections.json + Firestore config/corrections) + 못 알아들은 말 기록(글자만)
   6) 통계용 세션 첫 입력(음성/터치) 기록 → firebase_kiosk.js 가 sessions 에 씀
   기존 기능은 지우지 않음. 모든 훅은 실패하면 원래 흐름으로 넘김. 인터넷 없어도 동작. */
(function () {
  "use strict";
  if (window.__so4tSenior) return;
  var S = window.__so4tSenior = { version: "1.0", rateFactor: 1, fontStep: 0, log: [], hooks: {} };
  function log() { var a = ["[senior]"].concat([].slice.call(arguments)); console.log.apply(console, a); }
  function sq(s) { return String(s || "").replace(/[\s.,!?~·'"`()\[\]\-:;…]/g, ""); }
  function stage() { try { return String(currentStageName || ""); } catch (e) { return String(window.currentStageName || ""); } }
  function setStage(n) { try { currentStageName = n; } catch (e) { window.currentStageName = n; } }
  function items() { try { return (orderState && Array.isArray(orderState.items)) ? orderState.items : []; } catch (e) { return []; } }
  function menus() { try { return Array.isArray(customMenus) ? customMenus : []; } catch (e) { return []; } }
  function priceOf(n) { try { if (typeof getMenuPrice === "function") return Number(getMenuPrice(n)) || 0; } catch (e) {} var m = menus().find(function (x) { return x.name === n; }); return m ? Number(m.price) || 0 : 0; }
  function lineTotal(i) { var c = Number(i.count) || 1, p = priceOf(i.item) * c; if (i.isSet) p += 2000 * c; return p; } // renderSummary 와 같은 계산
  function sumOf(list) { return list.reduce(function (s, i) { return s + lineTotal(i); }, 0); }
  function won(n) { return Number(n || 0).toLocaleString() + "원"; }
  function say(t, cb) { try { if (typeof window.speakText === "function") return window.speakText(t, cb); } catch (e) {} try { return speakText(t, cb); } catch (e) {} }
  function ui(a, b, h) { try { updateUI(a, b, h); } catch (e) { log("updateUI 없음", e); } }
  function V8() { return window.__kioskV8 || null; }
  function FBX() { return window.__so4tFirebase || null; }
  function kioskId() { return String(window.SO4T_KIOSK_ID || "kiosk-1"); }
  function lsGet(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function fetchJson(u) { return fetch(u, { cache: "no-store" }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  var BIG = "font-size:1.5rem;font-weight:900;padding:16px 20px;border-radius:18px;border:0;color:#fff;min-width:8.5rem;font-family:inherit;cursor:pointer";

  /* =================== 공통: 확인 질문 대기 =================== */
  var pend = null; // { kind, until, yes(), no() }
  function ask(kind, msg, yes, no, ms) { pend = { kind: kind, until: Date.now() + (ms || 20000), yes: yes, no: no }; say(msg); }
  var YES = /^(네|예|응|어|넹|네네|예예|맞아|맞아요|맞습니다|좋아요|그래|그래요|그렇게해|그렇게해주세요|네맞아요|확인|담아|담아줘|담아주세요|결제|결제해|결제해줘|결제할게|결제할게요|해주세요|해줘)(요)?(주세요)?$/;
  var NO = /^(아니|아니요|아니오|아뇨|아냐|아니야|싫어|됐어|괜찮아|괜찮아요|고칠래|고칠게|고쳐|수정|취소|안할래|안해|안담아|그만)/;

  /* =================== 1) 말 속도 · 글씨 크기 =================== */
  var RATE_STEPS = [0.7, 0.85, 1, 1.2, 1.4], rateIdx = 2;
  // 모든 speakText 덮어쓰기와 기존 speak 가로채기(kiosk_tts_rate)를 거친 "마지막" rate 값에 세션 배율만 곱함 (저장값은 안 바꿈)
  (function hookRate() {
    try {
      var ss = window.speechSynthesis, P = window.SpeechSynthesisUtterance && SpeechSynthesisUtterance.prototype;
      var d = P && Object.getOwnPropertyDescriptor(P, "rate");
      if (!ss || !d || !d.set || ss.__seniorRate) return;
      var orig = ss.speak;
      ss.speak = function (u) {
        try {
          if (u && S.rateFactor !== 1 && !u.__seniorRate) {
            u.__seniorRate = true;
            var real = d.get.call(u) || 1;
            var apply = function (v) { d.set.call(u, Math.max(0.5, Math.min(2, (Number(v) || 1) * S.rateFactor))); };
            apply(real);
            Object.defineProperty(u, "rate", { configurable: true, get: function () { return d.get.call(u); }, set: function (v) { apply(v); } });
          }
        } catch (e) {}
        return orig.apply(this, arguments);
      };
      ss.__seniorRate = true;
      S.hooks.rate = true; log("speechSynthesis rate hooked");
    } catch (e) { log("rate 훅 실패", e); }
  })();
  function setRate(idx, speak) {
    rateIdx = Math.max(0, Math.min(RATE_STEPS.length - 1, idx)); S.rateFactor = RATE_STEPS[rateIdx];
    updateBar();
    if (speak) say(rateIdx === 0 ? "가장 천천히 말씀드릴게요." : rateIdx === RATE_STEPS.length - 1 ? "가장 빠르게 말씀드릴게요." :
      S.rateFactor < 1 ? "천천히 말씀드릴게요." : S.rateFactor > 1 ? "조금 빠르게 말씀드릴게요." : "보통 빠르기로 말씀드릴게요.");
  }
  function zoomMax() { try { return zoomFactors.length - 1; } catch (e) { return 4; } }
  function zoomNow() { try { return Number(zoomLevel) || 0; } catch (e) { return Number(window.zoomLevel) || 0; } }
  function setZoom(n) {
    n = Math.max(0, Math.min(zoomMax(), n));
    try { zoomLevel = n; } catch (e) {}
    window.zoomLevel = n;
    try { if (typeof updateZoomUI === "function") updateZoomUI(); } catch (e) {}
    try { if (typeof fitToScreen === "function") fitToScreen(); } catch (e) {}
    updateBar(); return n;
  }
  function font(dir, speak) {
    var before = zoomNow(), n = setZoom(before + dir);
    if (!speak) return;
    if (n === before) say(dir > 0 ? "지금이 가장 큰 글씨입니다." : "지금이 기본 글씨 크기입니다.");
    else say(dir > 0 ? "글씨를 크게 했어요." : (n ? "글씨를 조금 작게 했어요." : "글씨를 원래 크기로 돌렸어요."));
  }
  S.font = font; S.setRate = setRate;
  S.rate = function (d) { setRate(rateIdx + d, true); };
  function resetAccess() {
    var changed = S.rateFactor !== 1 || zoomNow() !== 0;
    rateIdx = 2; S.rateFactor = 1;
    if (zoomNow() !== 0) setZoom(0);
    updateBar();
    if (changed) log("새 손님 → 말 속도·글씨 기본값");
  }
  var bar = null;
  function mountBar() {
    if (bar || !document.body) return;
    bar = document.createElement("div"); bar.id = "senior-bar";
    bar.style.cssText = "position:fixed;left:8px;bottom:8px;z-index:9990;display:flex;gap:6px;flex-wrap:wrap;background:rgba(255,255,255,.92);border:2px solid #c2510f;border-radius:16px;padding:6px;font-family:inherit";
    var mk = function (label, fn, title) {
      var b = document.createElement("button"); b.type = "button"; b.textContent = label; b.title = title || label; b.className = "v8-touch senior-btn";
      b.style.cssText = "font-size:20px;font-weight:900;padding:10px 12px;border-radius:12px;border:0;background:#c2510f;color:#fff;min-width:64px;cursor:pointer";
      b.addEventListener("click", function (e) { e.stopPropagation(); markInput("touch"); fn(); }); bar.appendChild(b); return b;
    };
    mk("🐢 천천히", function () { S.rate(-1); }, "천천히 말하기");
    mk("🐇 빠르게", function () { S.rate(+1); }, "빠르게 말하기");
    mk("가+ 크게", function () { font(+1, true); }, "글씨 크게");
    mk("가- 작게", function () { font(-1, true); }, "글씨 작게");
    var st = document.createElement("span"); st.id = "senior-bar-state"; st.style.cssText = "align-self:center;font-weight:800;font-size:16px;color:#4a3f30;padding:0 4px";
    bar.appendChild(st); document.body.appendChild(bar); updateBar();
  }
  function updateBar() {
    var st = document.getElementById("senior-bar-state"); if (!st) return;
    st.textContent = "속도 " + ["아주 느림", "느림", "보통", "빠름", "아주 빠름"][rateIdx] + " · 글씨 " + (zoomNow() + 1) + "단계";
  }

  /* =================== 5) 교정 사전 =================== */
  /* 경상도 사투리 기본 보정 (11/3). 관리자 사전이나 corrections.json에 같은 말이 있으면 그게 우선 */
  var DIALECT = {
    "주이소": "주세요", "주이쏘": "주세요", "주소예": "주세요", "도고": "줘", "도가": "줘",
    "됐심더": "됐습니다", "됐십니더": "됐습니다", "맞심더": "맞습니다", "맞십니더": "맞습니다", "맞다카이": "맞아요",
    "아입니더": "아닙니다", "아이다": "아니야", "아이라예": "아니요", "아니라예": "아니요",
    "고마 됐다": "그만 됐어", "고마해라": "그만해", "치아라": "취소해", "치아뿌라": "취소해",
    "뭐꼬": "뭐야", "머꼬": "뭐야", "얼마고": "얼마야", "얼마라예": "얼마예요", "얼마인교": "얼마예요",
    "묵을끼다": "먹을게", "묵을게": "먹을게", "무울래": "먹을래", "묵고": "먹고", "묵을래": "먹을래",
    "쪼매": "조금", "쪼끔": "조금", "쪼깨": "조금", "억수로": "많이", "마이 주": "많이 주",
    "인자": "이제", "우째": "어떻게", "우짜노": "어떡해", "할끼다": "할게", "할낍니더": "할게요",
    "안 맵나": "안 매워요", "맵나": "매워요", "있나예": "있어요", "있능교": "있어요", "있심니꺼": "있어요",
    "하모": "네", "그래예": "그래요", "예예": "네네", "됐다마": "됐어"
  };
  var CORR = { local: {}, remote: lsGet("senior_corrections_cache", {}) };
  fetchJson("/static/corrections.json").then(function (j) { if (j && j.corrections && typeof j.corrections === "object") CORR.local = j.corrections; log("corrections.json " + Object.keys(CORR.local).length + "개"); });
  function corrMap() {
    var f = FBX(), r = f && f.corrections;
    if (r && typeof r === "object") { CORR.remote = r; lsSet("senior_corrections_cache", r); }
    var m = {}; Object.keys(DIALECT).forEach(function (k) { m[k] = DIALECT[k]; }); Object.keys(CORR.local).forEach(function (k) { m[k] = CORR.local[k]; }); Object.keys(CORR.remote || {}).forEach(function (k) { m[k] = CORR.remote[k]; });
    return m;
  }
  function correct(text) {
    var t = String(text || ""); if (!t) return t;
    var m = corrMap(), keys = Object.keys(m).filter(function (k) { return k && typeof m[k] === "string" && k.length <= 40; }).sort(function (a, b) { return b.length - a.length; });
    if (!keys.length) return t;
    var out = t, hit = false;
    keys.forEach(function (k) {
      var to = String(m[k]);
      if (out.indexOf(k) >= 0) { out = out.split(k).join(to); hit = true; return; }
      var ks = sq(k);
      if (ks && sq(out).indexOf(ks) >= 0) { out = sq(out).split(ks).join(sq(to) || to); hit = true; }
    });
    if (hit && out !== t) { S.lastCorrection = { from: t, to: out, at: Date.now() }; log("교정: '" + t + "' → '" + out + "'"); }
    return out;
  }
  S.correct = correct;

  /* =================== 2) 지난 주문 다시 하기 =================== */
  var LKEY = "senior_last_orders_v1";
  try { localStorage.removeItem(LKEY); } catch (e) {}
  var snap = null;
  function cleanItem(i) {
    return { item: String(i.item || ""), count: Math.max(1, Math.min(20, Number(i.count) || 1)), isSet: !!i.isSet, temp: String(i.temp || "기본"),
      options: typeof i.options === "string" ? i.options : "기본 옵션", cupSize: String(i.cupSize || ""), beverageOptions: i.beverageOptions && typeof i.beverageOptions === "object" ? JSON.parse(JSON.stringify(i.beverageOptions)) : null };
  }
  function saveLast(list) {
    if (!list || !list.length) return;
    var h = lsGet(LKEY, []); if (!Array.isArray(h)) h = [];
    h.unshift({ at: new Date().toISOString(), items: list.map(cleanItem) });
    lsSet(LKEY, h.slice(0, 3)); log("지난 주문 저장 (" + list.length + "줄)");
  }
  S.lastOrders = function () { return lsGet(LKEY, []); };
  S.clearLastOrders = function () { try { localStorage.removeItem(LKEY); } catch (e) {} return "지움"; };
  function repeatLast() {
    var h = lsGet(LKEY, []), last = Array.isArray(h) && h[0];
    if (!last || !last.items || !last.items.length) { say("저장된 지난 주문이 없어요. 드시고 싶은 메뉴 이름을 말씀해 주세요."); return true; }
    var names = menus().map(function (m) { return m.name; });
    var ok = [], miss = [];
    last.items.forEach(function (i) {
      var m = menus().find(function (x) { return x.name === i.item; });
      if (!m || (names.length && names.indexOf(i.item) < 0)) miss.push(i.item + "(메뉴에 없음)");
      else if (m.soldOut) miss.push(i.item + "(품절)");
      else ok.push(i);
    });
    if (!ok.length) { say("지난번 메뉴가 지금은 없거나 품절이에요. 다른 메뉴를 말씀해 주세요."); return true; }
    var txt = ok.map(function (i) { return i.item + (i.isSet ? " 세트" : "") + " " + i.count + "개"; }).join(", ");
    showPanel("🔁 지난번 주문", ok.map(function (i) { return esc(i.item) + (i.isSet ? " [세트]" : "") + " x" + i.count + " · " + won(lineTotal(i)); }).join("<br>") +
      (miss.length ? "<br><small>빠진 메뉴: " + esc(miss.join(", ")) + "</small>" : "") + "<br><b>합계 " + won(sumOf(ok)) + "</b>",
      [["✔ 네, 담아 주세요", "#15803d", function () { pend && pend.yes(); }], ["✕ 아니요", "#6b7280", function () { pend && pend.no(); }]]);
    ask("repeat", "지난번 주문은 " + txt + ", 합계 " + won(sumOf(ok)) + "입니다." + (miss.length ? " " + miss.join(", ") + "은 빼고 담아요." : "") + " 똑같이 담을까요? 네 또는 아니요로 말씀해 주세요.",
      function () {
        hidePanel();
        try { ok.forEach(function (i) { orderState.items.push(cleanItem(i)); }); } catch (e) { say("담지 못했어요. 직원을 불러 주세요."); return; }
        try { isAddOnPhase = false; } catch (e) {}
        try { if (typeof emptyTempItem === "function") tempItem = emptyTempItem(); } catch (e) {}
        try { document.body.classList.remove("clean-start-screen"); } catch (e) {}
        log("지난 주문 담음", txt);
        try { transitionTo("summary", renderSummary); } catch (e) { say("장바구니에 담았어요."); }
      },
      function () { hidePanel(); say("네, 담지 않을게요. 드시고 싶은 메뉴를 말씀해 주세요."); });
    return true;
  }

  /* =================== 4) 맵기 · 알레르기 =================== */
  var INFO = { local: {}, loaded: false };
  fetchJson("/static/menu_info.json").then(function (j) { INFO.loaded = true; if (j && j.items && typeof j.items === "object") INFO.local = j.items; log("menu_info.json " + Object.keys(INFO.local).length + "개"); });
  var ALG = [ // 식품 알레르기 표시 22종 (이름 → 손님이 말할 수 있는 말)
    ["난류", /계란|달걀|난류|에그/], ["우유", /우유|유제품|밀크|치즈|버터|크림/], ["메밀", /메밀/], ["땅콩", /땅콩|피넛/], ["대두", /대두|콩(?!나물)|두부|두유/],
    ["밀", /밀가루|(^|[^메])밀(?!크)|글루텐/], ["고등어", /고등어/], ["게", /(^|[^가-힣])게(?!요|임|살려)|꽃게|게살|대게/], ["새우", /새우/], ["돼지고기", /돼지/],
    ["복숭아", /복숭아/], ["토마토", /토마토/], ["아황산류", /아황산/], ["호두", /호두/], ["닭고기", /닭|치킨/], ["쇠고기", /쇠고기|소고기|소불고기/],
    ["오징어", /오징어/], ["조개류", /조개|굴(?!러)|전복|홍합/], ["잣", /(^|[^가-힣])잣/], ["견과류", /견과|아몬드|캐슈/]
  ];
  function normInfo(o) {
    if (!o || typeof o !== "object") return null;
    var r = {};
    var sp = o.spicy; if (sp !== undefined && sp !== null && sp !== "" && isFinite(Number(sp))) r.spicy = Math.max(0, Math.min(3, Math.round(Number(sp))));
    if (Array.isArray(o.allergens)) r.allergens = o.allergens.map(function (a) { return String(a).trim(); }).filter(Boolean);
    return (r.spicy === undefined && !r.allergens) ? null : r;
  }
  function infoOf(name) {
    var out = normInfo(INFO.local[name]) || {};
    var f = FBX(), rm = f && f.remoteMenu && f.remoteMenu.menus;
    if (Array.isArray(rm)) { var m = rm.find(function (x) { return x.name === name; }); var r = normInfo(m); if (r) { if (r.spicy !== undefined) out.spicy = r.spicy; if (r.allergens) out.allergens = r.allergens; } }
    var cm = normInfo(menus().find(function (x) { return x.name === name; })); if (cm) { if (cm.spicy !== undefined && out.spicy === undefined) out.spicy = cm.spicy; if (cm.allergens && !out.allergens) out.allergens = cm.allergens; }
    return (out.spicy === undefined && !out.allergens) ? null : out;
  }
  S.infoOf = infoOf;
  function avail() { return menus().filter(function (m) { return m && m.name && !m.soldOut; }); }
  function algKey(word) { for (var k = 0; k < ALG.length; k++) if (ALG[k][1].test(word)) return ALG[k][0]; return ""; }
  function hasAlg(info, key) { return (info.allergens || []).some(function (a) { return a === key || algKey(a) === key; }); }
  var SPICY_NO = /안매운|안맵|덜매운|안매워|맵지않|순한|안얼큰|매운거못|매운거싫|매운거빼|매운거말고|맵지않은/;
  var SPICY_YES = /매운|맵게|맵고|얼큰|칼칼|매콤/;
  var ALG_CTX = /알레르기|알러지|알레르|들어간|들어있|들어가|들었|들어|있는거|없는거|안들어|빼고|못먹|넣은|넣지않|성분/;
  function parseGuide(c) {
    if (/소리|목소리|볼륨/.test(c)) return null;
    if (SPICY_NO.test(c)) return { type: "notSpicy" };
    if (SPICY_YES.test(c) && /거|것|메뉴|있어|있나|있을|뭐|추천|알려|보여|어떤|$/.test(c) && !/덜맵게|맵게해|맵게만들|맵게해주/.test(c)) return { type: "spicy" };
    if (ALG_CTX.test(c)) {
      var key = algKey(c);
      if (!key && /알레르기|알러지/.test(c)) return { type: "allergyAsk" };
      if (key) {
        var avoid = /알레르기|알러지|없는|안들어|빼고|못먹|넣지않|안들|피해/.test(c);
        return { type: avoid ? "without" : "with", key: key };
      }
    }
    return null;
  }
  S.parseGuide = function (t) { return parseGuide(sq(t)); };
  function noInfo() {
    showPanel("ℹ️ 안내", "아직 정보가 등록되지 않았어요.<br>직원에게 물어봐 주세요.", [["🙋 직원 부르기", "#ea580c", function () { pend && pend.yes(); }], ["닫기", "#6b7280", function () { pend && pend.no(); }]]);
    ask("staff", "아직 정보가 등록되지 않았어요, 직원에게 물어봐 주세요. 직원을 불러 드릴까요?", function () { hidePanel(); staff("allergy"); }, function () { hidePanel(); say("네, 다른 것이 궁금하시면 말씀해 주세요."); });
    return true;
  }
  function staff(src) { try { if (typeof window.__kioskStaffCall === "function") return window.__kioskStaffCall(src || "senior"); } catch (e) {} say("직원을 불러 주세요."); }
  function pepper(n) { return n > 0 ? new Array(n + 1).join("🌶") : "안 매움"; }
  function guide(g) {
    var list = avail(), withInfo = list.filter(function (m) { return infoOf(m.name); });
    if (g.type === "allergyAsk") { say("어떤 재료가 걱정되세요? 예를 들어 땅콩 알레르기, 우유 알레르기 처럼 말씀해 주세요."); return true; }
    var res = [], title = "", speech = "";
    if (g.type === "notSpicy" || g.type === "spicy") {
      var known = list.filter(function (m) { var i = infoOf(m.name); return i && i.spicy !== undefined; });
      if (!known.length) return noInfo();
      if (g.type === "notSpicy") { res = known.filter(function (m) { return infoOf(m.name).spicy === 0; }); title = "🙂 안 매운 메뉴"; }
      else { res = known.filter(function (m) { return infoOf(m.name).spicy > 0; }).sort(function (a, b) { return infoOf(b.name).spicy - infoOf(a.name).spicy; }); title = "🌶 매운 메뉴"; }
      if (!res.length) { speech = g.type === "notSpicy" ? "등록된 정보로는 안 매운 메뉴가 없어요." : "등록된 정보로는 매운 메뉴가 없어요."; }
      else speech = (g.type === "notSpicy" ? "안 매운 메뉴는 " : "매운 메뉴는 ") + res.slice(0, 6).map(function (m) { return m.name; }).join(", ") + (res.length > 6 ? " 등 " + res.length + "가지" : "") + "입니다.";
    } else {
      var known2 = list.filter(function (m) { var i = infoOf(m.name); return i && Array.isArray(i.allergens); });
      if (!known2.length) return noInfo();
      if (g.type === "with") { res = known2.filter(function (m) { return hasAlg(infoOf(m.name), g.key); }); title = g.key + " 들어간 메뉴"; speech = res.length ? g.key + "가 들어간 메뉴는 " + res.slice(0, 6).map(function (m) { return m.name; }).join(", ") + "입니다." : "등록된 정보로는 " + g.key + "가 들어간 메뉴가 없어요."; }
      else { res = known2.filter(function (m) { return !hasAlg(infoOf(m.name), g.key); }); title = g.key + " 없는 메뉴 (등록 정보 기준)"; speech = res.length ? "등록된 정보로 " + g.key + "가 없는 메뉴는 " + res.slice(0, 6).map(function (m) { return m.name; }).join(", ") + "입니다." : "등록된 정보로는 " + g.key + "가 없는 메뉴가 없어요."; }
    }
    var unknown = list.length - (g.type === "notSpicy" || g.type === "spicy" ? list.filter(function (m) { var i = infoOf(m.name); return i && i.spicy !== undefined; }).length : list.filter(function (m) { var i = infoOf(m.name); return i && Array.isArray(i.allergens); }).length);
    if (unknown > 0) speech += " 정보가 없는 메뉴 " + unknown + "가지는 직원에게 물어봐 주세요.";
    if (g.type === "with" || g.type === "without") speech += " 알레르기가 심하시면 꼭 직원에게 한 번 더 확인해 주세요.";
    var html = res.length ? res.map(function (m) { var i = infoOf(m.name) || {};
      return '<button type="button" class="senior-pick" data-n="' + esc(m.name) + '" style="display:block;width:100%;text-align:left;margin:4px 0;padding:10px;border-radius:12px;border:2px solid #fdba74;background:#fff7ed;font-size:1.3rem;font-weight:800;cursor:pointer">' +
        esc(m.name) + " · " + won(m.price) + "<br><small>" + (i.spicy !== undefined ? "맵기 " + pepper(i.spicy) : "맵기 정보 없음") + " · " + (i.allergens ? (i.allergens.length ? "알레르기: " + esc(i.allergens.join(", ")) : "알레르기 표시 없음") : "알레르기 정보 없음") + "</small></button>"; }).join("")
      : "<p>해당 메뉴가 없어요.</p>";
    if (unknown > 0) html += "<p><small>정보 미등록 메뉴 " + unknown + "가지 → 직원에게 물어봐 주세요.</small></p>";
    showPanel(title, html, [["🙋 직원 부르기", "#ea580c", function () { hidePanel(); staff("allergy"); }], ["닫기", "#6b7280", hidePanel]]);
    say(speech);
    return true;
  }
  S.guide = function (t) { var g = parseGuide(sq(t)); return g ? guide(g) : false; };

  /* ---- 떠 있는 안내 창 ---- */
  function showPanel(title, html, btns) {
    hidePanel();
    var el = document.createElement("div"); el.id = "senior-panel";
    el.style.cssText = "position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:9995;width:min(92vw,640px);max-height:80vh;overflow:auto;background:#fff;border:4px solid #c2510f;border-radius:22px;padding:18px;box-shadow:0 10px 40px #0005;font-size:1.4rem;color:#2d2416";
    el.innerHTML = '<div style="font-size:1.7rem;font-weight:900;margin-bottom:8px">' + esc(title) + "</div><div>" + html + '</div><div id="senior-panel-btns" style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-top:12px"></div>';
    (btns || []).forEach(function (b) { var x = document.createElement("button"); x.type = "button"; x.textContent = b[0]; x.style.cssText = BIG + ";background:" + b[1]; x.className = "v8-touch";
      x.addEventListener("click", function (e) { e.stopPropagation(); markInput("touch"); b[2](); }); el.querySelector("#senior-panel-btns").appendChild(x); });
    [].forEach.call(el.querySelectorAll(".senior-pick"), function (b) { b.addEventListener("click", function (e) { e.stopPropagation(); var n = b.getAttribute("data-n"); hidePanel();
      try { if (typeof selectSpecificItem === "function") { selectSpecificItem(n); return; } } catch (er) { log("selectSpecificItem 실패", er); } say(n + " 라고 말씀해 주세요."); }); });
    document.body.appendChild(el);
  }
  function hidePanel() { var el = document.getElementById("senior-panel"); if (el) el.remove(); }
  S.hidePanel = hidePanel;

  /* =================== 3) 결제 전 다시 읽기 =================== */
  var confirmedSig = "", prevStage = "", payOrig = null;
  function sig() { return JSON.stringify(items().map(function (i) { return [i.item, i.count, i.isSet, i.temp, i.options, i.cupSize]; })); }
  function readback() {
    var list = items(), v8 = V8();
    var t = "";
    try { if (v8 && typeof v8.readoutText === "function") t = v8.readoutText(); } catch (e) {}
    if (t) t = t.replace(/이대로 결제하시려면[^.]*\.?\s*$/, "");
    else t = "주문 내역을 천천히 읽어 드릴게요. " + list.map(function (i) { return i.item + (i.isSet ? " 세트" : "") + " " + (Number(i.count) || 1) + "개"; }).join(". ") + ". 총 금액은 " + won(sumOf(list)) + "입니다. ";
    return t + " 이대로 결제할까요? 네 또는 아니요로 말씀해 주세요.";
  }
  function payGate() {
    var o = payOrig;
    var list = items();
    if (!list.length || confirmedSig === sig()) return o.apply(this, arguments);
    // V8 '주문 내역 확인' 화면에서 이미 천천히 읽고 '네'를 받은 바로 다음이면 또 묻지 않음
    if (prevStage === "summary" && V8() && typeof V8().readoutText === "function") { confirmedSig = sig(); log("summary 확인을 이미 거침 → 바로 결제"); return o.apply(this, arguments); }
    var self = this, args = arguments;
    setStage("payment_confirm");
    var rows = list.map(function (i) { return '<div style="display:flex;justify-content:space-between;font-size:1.35rem;font-weight:800;padding:4px 0;border-bottom:1px dashed #e7d7bf"><span>' + esc(i.item) + (i.isSet ? " [세트]" : "") + " x" + (Number(i.count) || 1) + "</span><span>" + won(lineTotal(i)) + "</span></div>"; }).join("");
    ui("이대로 결제할까요?", "총 합계: " + won(sumOf(list)),
      '<div class="w-full glass-panel p-3 rounded-2xl bg-white/70" style="max-height:44vh;overflow:hidden">' + rows + '</div>' +
      '<div style="display:flex;gap:12px;justify-content:center;margin-top:10px"><button type="button" class="v8-touch" style="' + BIG + ';background:#15803d" onclick="__so4tSenior.payYes()">✔ 네, 결제</button>' +
      '<button type="button" class="v8-touch" style="' + BIG + ';background:#6b7280" onclick="__so4tSenior.payNo()">✎ 고칠래요</button></div>');
    S.payYes = function () { if (stage() !== "payment_confirm") return; pend = null; confirmedSig = sig(); markInput("touch-or-voice");
      try { transitionTo("payment", function () { return o.apply(self, args); }); } catch (e) { setStage("payment"); o.apply(self, args); } };
    S.payNo = function () { if (stage() !== "payment_confirm") return; pend = null;
      try { transitionTo("summary", renderSummary); } catch (e) { log("renderSummary 없음", e); } };
    ask("pay", readback(), function () { S.payYes(); }, function () { S.payNo(); }, 120000);
    log("결제 전 다시 읽기");
  }
  function hookPay() {
    var cur = window.askPaymentStage;
    if (typeof cur !== "function" || cur.__seniorPay) return !!cur;
    payOrig = cur;
    var w = function seniorAskPaymentStage() { try { return payGate.apply(this, arguments); } catch (e) { console.warn("[senior] 결제 전 확인 오류 → 원래 흐름", e); return payOrig.apply(this, arguments); } };
    w.__seniorPay = true; w.__orig = cur;
    window.askPaymentStage = w; try { askPaymentStage = w; } catch (e) {}
    S.hooks.askPaymentStage = true; log("askPaymentStage hooked"); return true;
  }
  function hookTransition() {
    var cur = window.transitionTo;
    if (typeof cur !== "function" || cur.__seniorTr) return;
    var w = function (name) { try { prevStage = stage(); } catch (e) {} return cur.apply(this, arguments); };
    w.__seniorTr = true; w.__orig = cur;
    window.transitionTo = w; try { transitionTo = w; } catch (e) {}
    S.hooks.transitionTo = true;
  }

  /* =================== 6) 세션 첫 입력 · 못 알아들은 말 =================== */
  var firstBy = {}, pendingFirst = null;
  function sessionStart() { var v = V8(); return v && v.session && v.session.active ? String(v.session.start) : ""; }
  function markInput(mode) {
    if (mode === "touch-or-voice") return;
    var k = sessionStart();
    if (k) { if (!firstBy[k]) firstBy[k] = pendingFirst || mode; }
    else if (!pendingFirst) pendingFirst = mode;
  }
  S.firstInputFor = function (startISO) { // firebase_kiosk.js 가 sessions 기록할 때 부름
    var t = Date.parse(startISO); if (!isFinite(t)) return "unknown";
    var k = Object.keys(firstBy).find(function (x) { return Math.abs(Number(x) - t) < 1000; });
    return k ? firstBy[k] : "unknown";
  };
  document.addEventListener("pointerdown", function (e) { if (e.target && e.target.closest && e.target.closest("#so4t-pay-panel")) return; markInput("touch"); }, true);
  var lastSpeakT = 0;
  // 키오스크 관련 말(관련 없는 말 필터를 통과한 말)인데 3초 동안 대답도, 화면·장바구니 변화도 없으면 '못 알아들은 말'
  function watchNoResponse(u) {
    var st0 = stage(), sg0 = sig();
    setTimeout(function () {
      try { if (lastUtter === u && !u.logged && lastSpeakT < u.t && stage() === st0 && sig() === sg0 && String(u.text || "").replace(/\s/g, "").length >= 2) logUnrecognized(u, "no_response"); } catch (e) {}
    }, 3000);
  }
  var lastUtter = null, ULKEY = "senior_unrecognized_local";
  var REPROMPT = /다시 말씀|못 알아|잘 모르겠|죄송합니다|잘 못 들었|다시 한 번 말/;
  (function hookReprompt() {
    var ss = window.speechSynthesis; if (!ss || ss.__seniorRe) return;
    var o = ss.speak;
    ss.speak = function (u) {
      lastSpeakT = Date.now();
      try { var tx = u && u.text || ""; if (lastUtter && !lastUtter.logged && Date.now() - lastUtter.t < 3000 && REPROMPT.test(tx)) logUnrecognized(lastUtter, "reprompt"); } catch (e) {}
      return o.apply(this, arguments);
    };
    ss.__seniorRe = true;
  })();
  function logUnrecognized(u, reason) {
    u.logged = true;
    var text = String(u.text || "").slice(0, 100); if (!text.trim()) return;
    var rec = { text: text, stage: String(u.stage || "").slice(0, 40), reason: reason, kioskId: kioskId(), timeISO: new Date().toISOString() };
    var l = lsGet(ULKEY, []); if (!Array.isArray(l)) l = []; l.push(rec); lsSet(ULKEY, l.slice(-50));
    var f = FBX();
    try { if (f && typeof f.add === "function") f.add("unrecognized", JSON.parse(JSON.stringify(rec))); } catch (e) {}   // time 은 firebase_kiosk.js 가 timeISO 로 채움
    log("못 알아들은 말 기록:", text);
  }
  S.unrecognizedLocal = function () { return lsGet(ULKEY, []); };

  /* =================== 음성 처리 (공통 진입점) =================== */
  var REPEAT = /(아까|지난번|저번|전번|지난|저번에|전에)(꺼|거|것|주문|먹은거|시킨거)?(랑|이랑|하고|과|와)?(똑같이|똑같은|똑같은거|같은거|같은걸|같은것|같이|똑같|같게)|^(저번|지난번)(꺼|거|것|걸)(로|요|주세요|줘|로줘|로주세요|으로)?$|(저번|지난번)(꺼|거|것|걸)(로|으로)?(주세요|줘|할게|할래|시킬게|주문)/;
  var RATE_SLOW = /천천히|느리게|느릿|빨라요|너무빨라|말이빨라/;
  var RATE_FAST = /빨리말|빠르게말|빨리해|빠르게해|좀빨리|너무느려|느려요|답답해/;
  var FONT_BIG2 = /크게보여|크게봐|크게좀보여|글씨좀키워|글자키워|잘안보여|글씨가작아|글씨가안보/;
  function own(t) {   // 이 애드온이 처리하는 말이면 처리하고 true
    var c = sq(t); if (!c) return false;
    var st = stage(), now = Date.now();
    if (st === "sleep" || st === "admin_auth" || st === "admin_panel_open") return false;
    if (pend && pend.until > now) {
      if (YES.test(c) || (pend.kind === "pay" && /^(네|예)?(결제|계산)/.test(c))) { var p = pend; pend = null; p.yes(); return true; }
      if (NO.test(c)) { var q = pend; pend = null; q.no(); return true; }
      if (pend.kind === "pay" && st === "payment_confirm") { if (/직원|사람|도와/.test(c)) { staff("voice"); return true; } say("이대로 결제하시려면 네, 고치시려면 아니요 라고 말씀해 주세요."); return true; }
    } else pend = null;
    if (st === "payment_confirm") return false;
    if (/^(guidance|done)$/.test(st)) return false;  // 결제 중 화면은 결제 애드온·원래 흐름
    if (RATE_SLOW.test(c) && (/말|목소리|얘기|읽어/.test(c) || /^(좀|조금|더)?(천천히|느리게)(해|해줘|해주세요|요)?$/.test(c)) && !/설명|메뉴/.test(c)) { S.rate(-1); return true; }
    if (RATE_FAST.test(c) && !/설명|메뉴|결제/.test(c)) { S.rate(+1); return true; }
    if (FONT_BIG2.test(c) && Date.now() > fontWait) {
      // 원래 키오스크 확대 기능이 먼저 처리하게 두고, 0.6초 뒤에도 그대로면 그때 한 단계 키움 (두 번 커지지 않게)
      fontWait = Date.now() + 1500; var z0 = zl();
      setTimeout(function () { if (zl() === z0) font(+1, true); }, 600);
      return false;
    }
    /* 지난 주문 다시 하기: 손님 구별이 안 돼서 꺼 둠 (11/3) */
    var g = parseGuide(c); if (g) return guide(g);
    return false;
  }
  S.own = own;
  var fontWait = 0;
  function zl() { try { return zoomLevel; } catch (e) { return -1; } }
  function isOwnPhrase(t) {
    var c = sq(t);
    return RATE_SLOW.test(c) || RATE_FAST.test(c) || FONT_BIG2.test(c) || !!parseGuide(c) || (!!pend && pend.until > Date.now() && (YES.test(c) || NO.test(c)));
  }
  S.isOwnPhrase = isOwnPhrase;

  // (a) 무관 발화 필터: 원래 판정이 버려도 이 애드온의 말(교정 후 포함)은 통과
  function hookRelevance() {
    var R = window.KIOSK_RELEVANCE; if (!R || typeof R.isKioskRelated !== "function" || R.isKioskRelated.__senior) return;
    var o = R.isKioskRelated;
    var w = function (text) {
      var r = o.apply(this, arguments); if (r) return r;
      try { var c = correct(text); if (isOwnPhrase(c)) return true; if (c !== String(text || "") && o.call(this, c, arguments[1], arguments[2])) return true; } catch (e) {}
      return r;
    };
    w.__senior = true; w.__orig = o; R.isKioskRelated = w; S.hooks.relevance = true; log("KIOSK_RELEVANCE hooked");
  }
  // (b) 하이브리드 routeText 안의 단일 라우터(KIOSK_INTENTS.route) 앞: 교정 → 이 애드온 처리 → 원래 라우터
  var reenter = false, inflight = "";
  function hookRoute() {
    var I = window.KIOSK_INTENTS; if (!I || typeof I.route !== "function" || I.route.__senior) return;
    var o = I.route;
    var w = function (t, from) {
      try {
        lastUtter = { text: String(t || ""), t: Date.now(), stage: stage() }; markInput("voice");
        var c = correct(t);
        if (c !== String(t || "") && !reenter && typeof window.__hybridRouteText === "function") {
          reenter = true; try { window.__hybridRouteText(c); } finally { reenter = false; } return true;
        }
        if (own(c)) { lastUtter.logged = true; inflight = c; setTimeout(function () { inflight = ""; }, 1500); return true; }
        if (c !== String(t || "")) t = c;
        watchNoResponse(lastUtter);
      } catch (e) { console.warn("[senior] route 오류 → 원래 흐름", e); }
      return o.call(this, t, from);
    };
    w.__senior = true; w.__orig = o; I.route = w; S.hooks.route = true; log("KIOSK_INTENTS.route hooked");
  }
  // (c) processVoiceCommand (다른 길로 들어오는 말): 교정 + 이 애드온 처리. 주문시작·결제 애드온 표시를 그대로 옮겨 서로 다시 감싸기 반복을 막음
  var pvcDepth = 0;
  function hookPVC() {
    var prev = window.processVoiceCommand;
    if (typeof prev !== "function" || prev.__seniorPlus) return;
    var w = function seniorProcessVoiceCommand(text) {
      if (pvcDepth > 0) return prev.apply(this, arguments);   // 바깥 senior 층이 이미 처리
      pvcDepth++;
      try {
        var c = correct(text);
        if (c === inflight) return;                            // 같은 말을 route 에서 이미 처리
        if (!lastUtter || Date.now() - lastUtter.t > 500) { lastUtter = { text: String(text || ""), t: Date.now(), stage: stage() }; }
        if (own(c)) { lastUtter.logged = true; return; }
        var a = [].slice.call(arguments); a[0] = c;
        return prev.apply(this, a);
      } catch (e) { console.warn("[senior] 오류 → 원래 처리", e); return prev.apply(this, arguments); }
      finally { pvcDepth--; }
    };
    w.__seniorPlus = true; w.__orderStartMenu = prev.__orderStartMenu; w.__payVoice = prev.__payVoice;
    window.processVoiceCommand = w; try { processVoiceCommand = w; } catch (e) {}
    S.hooks.processVoiceCommand = true; log("processVoiceCommand hooked");
  }

  /* =================== 화면 단계 감시 (새 손님 초기화 · 주문 저장) =================== */
  var lastSt = "";
  setInterval(function () {
    var st = stage();
    if (/^(payment|payment_confirm|guidance)$/.test(st) && items().length) snap = items().map(cleanItem);
    if (st !== lastSt) {
      if (st === "done" && snap) { snap = null; }
      if (st === "welcome" || st === "sleep") { resetAccess(); hidePanel(); pend = null; confirmedSig = ""; snap = null; pendingFirst = null; }
      if (st === "summary" || st === "category_select") { if (sig() !== confirmedSig) confirmedSig = ""; }
      lastSt = st;
    }
    var ks = Object.keys(firstBy); if (ks.length > 20) delete firstBy[ks[0]];
    var k = sessionStart(); if (k && !firstBy[k] && pendingFirst) { firstBy[k] = pendingFirst; pendingFirst = null; }
  }, 300);

  function hookWelcome() {
    var f = window.showWelcomeScreen; if (typeof f !== "function" || f.__senior) return;
    var w = function seniorWelcomeScreen() { try { resetAccess(); hidePanel(); pend = null; confirmedSig = ""; snap = null; } catch (e) {} return f.apply(this, arguments); };
    w.__senior = true; window.showWelcomeScreen = w; try { showWelcomeScreen = w; } catch (e) {}
  }
  function hookAll() { hookWelcome(); hookRelevance(); hookRoute(); hookPVC(); hookPay(); hookTransition(); mountBar(); }
  hookAll();
  window.addEventListener("load", function () { setTimeout(hookAll, 100); });
  setInterval(hookAll, 2000);
  S.test = function (t) { var c = correct(t); return own(c) ? "senior 처리: " + c : "원래 흐름: " + c; };
  log("loaded v" + S.version);
})();
