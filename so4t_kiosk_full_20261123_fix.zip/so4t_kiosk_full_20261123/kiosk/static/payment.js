/* 소4트 카드 결제 애드온 (payment slot)
   - selectPayment("신용/체크 카드") 만 감쌈. 현금은 원래 함수 그대로.
   - driver "off" 이면 원래 selectPayment 그대로 (지금과 100% 동일).
   - driver "simulator"(기본): 손대지 않으면 4초 뒤 자동 승인 → 원래처럼 감사 화면. Ctrl+Shift+P 시험 패널.
   - driver "local-agent": 파이의 결제 에이전트(/pay /cancel /status) 로 POST.
   - 결과는 window 'so4t:payment' 이벤트 + window.__so4tPay.history 에 남김 (카드번호는 마스킹된 값만). */
(function () {
  "use strict";
  if (window.__so4tPay) return;
  var DEF = { driver: "simulator", agentUrl: "http://127.0.0.1:8010", timeoutSec: 20, simulator: { autoResult: "manual", autoDelayMs: 4000 } };
  var CFG = JSON.parse(JSON.stringify(DEF));
  var P = window.__so4tPay = { cfg: CFG, history: [], busy: false, choice: false, drivers: {}, version: "1.2" };
  function log() { var a = ["[payment]"].concat([].slice.call(arguments)); console.log.apply(console, a); }
  function res(status, o) { o = o || {}; return { status: status, approvalNo: o.approvalNo || "", cardMasked: o.cardMasked || "", message: o.message || "" }; }

  /* ---------- 드라이버 (PaymentAdapter: pay / cancel / status) ---------- */
  // (a) simulator: 키오스크 안에서 흉내. 시험: __so4tPay.sim("approve"|"decline"|"cancel"|"error"|"timeout")
  var simPending = null, simNext = null;
  P.drivers.simulator = {
    name: "simulator",
    pay: function (amount, orderId) {
      return new Promise(function (resolve) {
        var s = CFG.simulator || {};
        var timer = null;
        simPending = function (kind) {
          clearTimeout(timer); simPending = null;
          if (kind === "timeout") return; // 응답 없음 흉내 → 바깥 타임아웃이 처리
          if (kind === "approve" || kind === "approved") resolve(res("approved", { approvalNo: "SIM" + String(Date.now()).slice(-8), cardMasked: "SIM-****-****-0000", message: "시뮬레이터 승인" }));
          else if (kind === "decline" || kind === "declined") resolve(res("declined", { message: "시뮬레이터 거절" }));
          else if (kind === "cancel" || kind === "canceled") resolve(res("canceled", { message: "시뮬레이터 취소" }));
          else resolve(res("error", { message: "시뮬레이터 오류" }));
        };
        var auto = simNext || s.autoResult || "approved"; simNext = null;
        if (auto !== "manual" && auto !== "timeout") timer = setTimeout(function () { simPending && simPending(auto); }, Number(s.autoDelayMs) || 4000);
        if (auto === "timeout") simPending("timeout");
      });
    },
    cancel: function (approvalNo, amount) { return Promise.resolve(res("canceled", { approvalNo: approvalNo, message: "시뮬레이터 승인취소" })); },
    status: function () { return Promise.resolve({ ok: true, driver: "simulator", pending: !!simPending }); },
    abort: function () { if (simPending) { var f = simPending; simPending = null; } }
  };
  P.sim = function (kind) { if (simPending) { simPending(kind); return "ok: " + kind; } simNext = kind; return "다음 결제에 적용: " + kind; };

  // (b) local-agent: 파이 결제 에이전트
  function post(path, body, ms) {
    var ctl = window.AbortController ? new AbortController() : null;
    var t = ctl ? setTimeout(function () { ctl.abort(); }, ms) : null;
    return fetch(CFG.agentUrl.replace(/\/$/, "") + path, { method: body ? "POST" : "GET", headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined, signal: ctl ? ctl.signal : undefined })
      .then(function (r) { return r.json(); })
      .finally(function () { clearTimeout(t); });
  }
  P.drivers["local-agent"] = {
    name: "local-agent",
    pay: function (amount, orderId) {
      return post("/pay", { amount: amount, orderId: orderId, timeoutSec: CFG.timeoutSec }, (CFG.timeoutSec + 5) * 1000)
        .then(function (j) { return res(j.status || "error", j); })
        .catch(function (e) { return res("error", { message: "에이전트 연결 실패: " + (e && e.message) }); });
    },
    cancel: function (approvalNo, amount) {
      return post("/cancel", { approvalNo: approvalNo || "", amount: amount || 0 }, 15000).then(function (j) { return res(j.status || "error", j); })
        .catch(function (e) { return res("error", { message: String(e && e.message) }); });
    },
    status: function () { return post("/status", null, 5000).catch(function (e) { return { ok: false, message: String(e && e.message) }; }); },
    abort: function () { post("/cancel", { approvalNo: "", amount: 0, abortPending: true }, 5000).catch(function () {}); }
  };
  P.adapter = function () { return P.drivers[CFG.driver] || null; };

  /* ---------- 설정 읽기 ---------- */
  fetch("/static/payment_config.json", { cache: "no-store" }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
    if (j) Object.keys(j).forEach(function (k) { CFG[k] = j[k]; });
    CFG.timeoutSec = Math.max(10, Math.min(300, Number(CFG.timeoutSec) || 20));
    log("설정 driver=" + CFG.driver + " timeout=" + CFG.timeoutSec + "s");
  }).catch(function () { log("payment_config.json 못 읽음 → 기본값(simulator)"); });

  /* ---------- 기존 키오스크 함수 접근 ---------- */
  function say(t, cb) { try { if (typeof speakText === "function") return speakText(t, cb); } catch (e) {} try { window.speakText(t, cb); } catch (e) {} }
  function ui(a, b, h) { try { updateUI(a, b, h); } catch (e) { log("updateUI 없음", e); } }
  function go(name, fn) { try { transitionTo(name, fn); } catch (e) { log("transitionTo 없음", e); fn(); } }
  function stage() { try { return currentStageName; } catch (e) { return window.currentStageName; } }
  function amountNow() {
    try {
      var sum = 0;
      orderState.items.forEach(function (i) { var p = getMenuPrice(i.item) * i.count; if (i.isSet) p += 2000 * i.count; sum += p; }); // renderSummary 와 같은 계산
      return sum;
    } catch (e) { return NaN; }
  }
  function slots(show) { var s = document.getElementById("hardware-slots"); if (s) { s.classList.toggle("opacity-0", !show); s.classList.toggle("opacity-100", !!show); } }
  function goodbye() { var g = window.showGoodbyeMessage; try { if (typeof showGoodbyeMessage === "function") g = showGoodbyeMessage; } catch (e) {} g(); }
  function emit(d) {
    P.history.push(d); if (P.history.length > 50) P.history.shift();
    try { window.dispatchEvent(new CustomEvent("so4t:payment", { detail: d })); } catch (e) {}
  }

  var BIG = 'style="font-size:1.6rem;font-weight:900;padding:18px 22px;border-radius:18px;min-width:9rem"';
  function btns() {
    return '<div class="flex flex-wrap justify-center gap-3 mt-2 v8-touch so4t-pay-touch" id="pay-choice">' +
      '<button ' + BIG + ' class="bg-emerald-500 text-white" onclick="__so4tPay.retry()">🔄 다시 하기</button>' +
      '<button ' + BIG + ' class="bg-orange-500 text-white" onclick="__so4tPay.staff()">🙋 직원 부르기</button>' +
      '<button ' + BIG + ' class="bg-gray-400 text-white" onclick="__so4tPay.back()">↩ 결제 취소</button></div>';
  }

  /* ---------- 카드 결제 흐름 ---------- */
  var cur = null;
  function startCard() {
    var ad = P.adapter();
    var amount = amountNow();
    var orderId = "K" + Date.now();
    cur = { orderId: orderId, amount: amount, token: {} };
    var tok = cur.token;
    P.busy = true; P.choice = false;
    go("guidance", function () {
      slots(true);
      ui('<span style="font-size:1.15em">💳 카드를 넣어 주세요</span>', (isFinite(amount) ? amount.toLocaleString() + "원" : "") + " · 아래 [카드 리더기]",
        '<div class="flex flex-col items-center"><div class="arrow-indicator">⬇️</div><div class="status-giant mt-2" id="pay-wait">결제 중입니다. 잠시만 기다려 주세요.</div></div>');
      say("카드를 넣어 주세요.");
    });
    if (!ad) return finish(tok, res("error", { message: "알 수 없는 driver: " + CFG.driver }));
    if (!isFinite(amount) || amount <= 0) return finish(tok, res("error", { message: "금액 계산 실패" }));
    var to = setTimeout(function () {
      try { ad.abort && ad.abort(); } catch (e) {}
      finish(tok, { status: "timeout", approvalNo: "", cardMasked: "", message: CFG.timeoutSec + "초 동안 응답 없음" });
    }, CFG.timeoutSec * 1000);
    Promise.resolve().then(function () { return ad.pay(amount, orderId); })
      .catch(function (e) { return res("error", { message: String(e && e.message || e) }); })
      .then(function (r) { clearTimeout(to); finish(tok, r); });
  }
  /* v1.2: '처음으로' 등으로 결제 화면을 벗어나면 진행 중 결제를 조용히 끝냄 (늦게 온 시간초과가 처음 화면 위에 실패 화면을 그리던 문제) */
  function payStage(st) { return st === "guidance" || st === "payment" || st === "payment_confirm"; }
  P.abort = function (why) {
    var had = !!(cur && !cur.done) || P.choice;
    if (cur && !cur.done) {
      cur.done = true;
      try { var ad = P.adapter(); ad && ad.abort && ad.abort(); } catch (e) {}
      emit({ orderId: cur.orderId, amount: cur.amount, driver: CFG.driver, status: "aborted", approvalNo: "", cardMasked: "", message: String(why || "화면 이동"), time: new Date().toISOString() });
    }
    P.busy = false; P.choice = false;
    if (had) { slots(false); log("결제 중단 (" + (why || "화면 이동") + ")"); }
    return had;
  };
  setInterval(function () { if ((P.busy || P.choice) && !payStage(stage())) P.abort("stage=" + stage()); }, 400);
  function finish(tok, r) {
    if (!cur || cur.token !== tok || cur.done) return;
    if (!payStage(stage())) { P.abort("결과 도착 전에 화면 이동: " + r.status); return; }
    cur.done = true; P.busy = false;
    var d = { orderId: cur.orderId, amount: cur.amount, driver: CFG.driver, status: r.status, approvalNo: r.approvalNo || "", cardMasked: r.cardMasked || "", message: r.message || "", time: new Date().toISOString() };
    log(d.status, d); emit(d); P.last = d;
    if (r.status === "approved") {
      ui("✅ 결제가 완료되었습니다", d.cardMasked ? "카드 " + d.cardMasked : "", '<div class="status-giant">카드를 빼 주세요.</div>');
      say("결제가 완료되었습니다. 카드를 빼 주세요.");
      setTimeout(function () { if (stage() === "guidance") goodbye(); }, 2500);
      return;
    }
    slots(false); P.choice = true;
    if (r.status === "timeout") {
      ui("⏰ 카드가 확인되지 않았어요", "다시 하거나 직원을 불러 드릴까요?", btns());
      say("카드가 확인되지 않았어요. 다시 하거나 직원을 불러 드릴까요?");
    } else if (r.status === "canceled") {
      ui("결제가 취소되었어요", "다시 하거나 직원을 불러 드릴까요?", btns());
      say("결제가 취소되었어요. 다시 하거나 직원을 불러 드릴까요?");
    } else {
      ui("❌ 결제가 안 됐어요", "다시 하거나 직원을 불러 드릴까요?", btns());
      say("결제가 안 됐어요. 다시 하거나 직원을 불러 드릴까요?");
    }
  }
  P.retry = function () { if (!P.choice) return; P.choice = false; startCard(); };
  P.staff = function () {
    try { if (typeof window.__kioskStaffCall === "function") window.__kioskStaffCall("payment"); } catch (e) {}
    ui("🙋 직원을 불렀어요", "잠시만 기다려 주세요.", btns()); say("직원을 불렀어요. 잠시만 기다려 주세요.");
  };
  P.back = function () {
    P.choice = false; cur = null; slots(false);
    try { orderState.pay = ""; } catch (e) {}
    try { go("payment", askPaymentStage); } catch (e) { log("askPaymentStage 없음", e); }
  };
  P.cancelLast = function () { var a = P.adapter(), l = P.last; if (!a || !l || l.status !== "approved") return Promise.resolve("승인 내역 없음"); return a.cancel(l.approvalNo, l.amount).then(function (r) { emit({ orderId: l.orderId, amount: l.amount, driver: CFG.driver, status: "refund_" + r.status, approvalNo: l.approvalNo, message: r.message, time: new Date().toISOString() }); return r; }); };
  P.status = function () { var a = P.adapter(); return a ? a.status() : Promise.resolve({ ok: false, driver: CFG.driver }); };
  P.test = function (kind) { simNext = kind || "approve"; return "다음 카드 결제 = " + simNext + " (CFG.driver=" + CFG.driver + ")"; };

  /* ---------- selectPayment 감싸기 ---------- */
  function hook() {
    var orig = window.selectPayment;
    if (typeof orig !== "function") return false;
    if (orig.__payHooked) return true;
    var wrapped = function payAddonSelectPayment(c) {
      try {
        var isCard = String(c || "").indexOf("현금") < 0;
        if (isCard && CFG.driver && CFG.driver !== "off" && P.adapter()) {
          if (P.busy) { log("이미 결제 중 → 무시"); return; }
          try { playBeep("success"); } catch (e) {}
          try { orderState.pay = c; } catch (e) {}
          startCard();
          return;
        }
      } catch (e) { console.warn("[payment] 오류 → 원래 흐름", e); }
      return orig.apply(this, arguments);
    };
    wrapped.__payHooked = true; wrapped.__orig = orig;
    window.selectPayment = wrapped;
    log("selectPayment hooked");
    return true;
  }
  hook(); window.addEventListener("load", function () { setTimeout(hook, 0); }); setInterval(hook, 2000);

  /* ---------- 결제 실패 화면에서 음성 대답 ("다시", "직원", "취소") ---------- */
  function hookVoice() {
    var prev = window.processVoiceCommand;
    if (typeof prev !== "function" || prev.__payVoice) return;
    var w = function (text) {
      if (P.choice && stage() === "guidance") {
        var t = String(text || "").replace(/\s+/g, "");
        if (/직원|사람|도와/.test(t)) return P.staff();
        if (/다시|재시도|한번더|네|응/.test(t)) return P.retry();
        if (/취소|그만|아니|현금|안해/.test(t)) return P.back();
      }
      return prev.apply(this, arguments);
    };
    w.__payVoice = true; w.__orderStartMenu = prev.__orderStartMenu;
    window.processVoiceCommand = w;
    try { processVoiceCommand = w; } catch (e) {}
  }
  setInterval(hookVoice, 2000); window.addEventListener("load", function () { setTimeout(hookVoice, 50); });

  /* ---------- 시험 패널: Ctrl+Shift+P ---------- */
  function panel() {
    var el = document.getElementById("so4t-pay-panel");
    if (el) { el.remove(); return; }
    el = document.createElement("div"); el.id = "so4t-pay-panel"; el.className = "v8-touch so4t-pay-touch";
    el.style.cssText = "position:fixed;right:10px;bottom:10px;z-index:99999;background:#222;color:#fff;padding:10px;border-radius:10px;font:14px sans-serif";
    el.innerHTML = "<b>결제 시험 (" + CFG.driver + ")</b><br>" + ["approve", "decline", "cancel", "error", "timeout"].map(function (k) {
      return '<button style="margin:3px;padding:6px 10px" onclick="console.log(__so4tPay.sim(\'' + k + '\'))">' + k + "</button>"; }).join("");
    document.body.appendChild(el);
  }
  P.panel = panel;
  /* 터치 잠금(body.touch-locked * { pointer-events:none })이 시험 패널·실패 선택 버튼까지 막던 문제 → 이 두 곳만 예외 (주문 화면 터치 잠금은 그대로) */
  (function () {
    if (document.getElementById("so4t-pay-touch-css")) return;
    var st = document.createElement("style"); st.id = "so4t-pay-touch-css";
    st.textContent = "body.touch-locked #so4t-pay-panel, body.touch-locked #so4t-pay-panel *, body.touch-locked #pay-choice, body.touch-locked #pay-choice * { pointer-events: auto !important; cursor: pointer !important; }";
    (document.head || document.documentElement).appendChild(st);
  })();
  /* 키보드 U: 카드 결제 대기 중이면 approve 와 같은 경로 (입력칸에 글 쓰는 중에는 무시) */
  function typing(e) {
    var t = e.target || document.activeElement;
    if (!t) return false;
    var tag = String(t.tagName || "").toUpperCase();
    return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || !!t.isContentEditable;
  }
  P.approveNow = function () {
    if (!P.busy || !cur || cur.done) return "결제 대기 중 아님";
    if (simPending) { simPending("approve"); return "ok: approve"; }
    // simulator 가 아닌 driver 라도 시연용으로 바로 승인 처리
    finish(cur.token, res("approved", { approvalNo: "KEY" + String(Date.now()).slice(-8), cardMasked: "SIM-****-****-0000", message: "키보드 U 승인" }));
    return "ok: approve(key)";
  };
  document.addEventListener("keydown", function (e) {
    if (e.ctrlKey && e.shiftKey && (e.key === "P" || e.key === "p")) { e.preventDefault(); panel(); return; }
    if (!e.ctrlKey && !e.altKey && !e.metaKey && (e.key === "u" || e.key === "U" || e.key === "ㅕ" || e.code === "KeyU") && P.busy && !typing(e)) {
      e.preventDefault(); e.stopPropagation(); log("키보드 U →", P.approveNow());
    }
  }, true);
})();
