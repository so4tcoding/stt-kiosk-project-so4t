/* so4t_fix.js v1.0 (2026-11-04) — 기존 동작 고치기만 (새 기능·삭제 없음). 다른 애드온 뒤 마지막에 로드.
   1) 수량: 수량 단계에서 '두게/세 게/네게/투 개/도 개/새 개/내 개/다서 개/Two' 같은 받아쓰기 변형이
      무관 발화 필터에서 버려지던 문제 → 수량 단계에서만 '두 개' 꼴로 고쳐서 통과
   2) 수량: '돼지국밥 두 개'처럼 메뉴+개수를 한 번에 말하면 개수가 버려지고 수량을 다시 묻던 문제
      → 수량 단계에서는 메뉴 이름을 떼고 개수만, 다른 단계에서는 메뉴 선택 뒤 수량 화면에 개수를 자동 입력
   3) '처음으로': 시니어 결제 확인 대기(pend)나 결제 대기 중에도 확실히 처음 화면으로
      (+ 1.2초 뒤에도 같은 화면 그대로면 한 번 더)
   4) 인식 지연: 옆 사람과 대화가 섞이면 '천천히 말하는 손님'으로 학습돼 말 끝 대기 1.6초·Whisper 10초 녹음까지
      늘어나던 것을 상한 1.0초·7초(원래 기본값)로 제한 (적응 기능은 그대로, 상한만)
      + Whisper 처리 중에 들어온 말이 통째로 버려지던 것 → 빠른 인식 결과로 바로 처리 (kiosk.html 한 줄 패치와 짝)
   끄기: localStorage.setItem("so4t_fix_off","1") 후 새로고침 */
(function () {
  "use strict";
  if (window.__so4tFix) return;
  var OFF = false; try { OFF = localStorage.getItem("so4t_fix_off") === "1"; } catch (e) {}
  var F = window.__so4tFix = { version: "1.0", off: OFF, log: [], stats: { qtyFixed: 0, menuCount: 0, home: 0, homeRetry: 0, capped: 0, whisperBusy: 0 } };
  if (OFF) { console.log("[fix] 꺼짐 (so4t_fix_off=1)"); return; }
  function log() { var a = [].slice.call(arguments); F.log.push(a.join(" ")); if (F.log.length > 80) F.log.shift(); try { console.log.apply(console, ["[fix]"].concat(a)); } catch (e) {} }
  function stage() { try { return String(currentStageName || ""); } catch (e) { return String(window.currentStageName || ""); } }
  function temp() { try { return tempItem; } catch (e) { return window.tempItem; } }
  function menus() { try { if (typeof getMenus === "function") return getMenus(); } catch (e) {} try { return customMenus; } catch (e) { return window.customMenus || []; } }
  function sq(s) { return String(s || "").replace(/[\s.,!?~·'"`()\[\]\-:;…]/g, ""); }
  function say(t) { try { if (typeof speakText === "function") return speakText(t); } catch (e) {} try { window.speakText && window.speakText(t); } catch (e) {} }
  var Q = function () { return window.KIOSK_QTY; };
  var QTY_ST = /^(quantity|summary_add_quantity)$/;

  /* ---------- 1) 수량 말 고치기 (수량 단계에서만) ---------- */
  var CNT = "(개|게|깨|계|잔|짠|그릇|인분|명|병|컵|접시|조각)";
  function fixQty(text) {
    var s = String(text || "").replace(/[.,?!~…]/g, " ").replace(/\s+/g, " ").trim();
    var o = s;
    s = s.replace(/\b(one|two|three|four|five)\b(\s*(pieces?|please))?/gi, function (m, w) { return { one: "한", two: "두", three: "세", four: "네", five: "다섯" }[w.toLowerCase()] + " 개"; });
    s = s.replace(new RegExp("(^|[^가-힣])(투|도|두)(\\s*)" + CNT, "g"), "$1두$3$4");
    s = s.replace(new RegExp("(^|[^가-힣])(새|쌔|쎄|세)(\\s*)" + CNT, "g"), "$1세$3$4");
    s = s.replace(new RegExp("(^|[^가-힣])(내|녜|네)(\\s*)" + CNT, "g"), "$1네$3$4");
    s = s.replace(new RegExp("(^|[^가-힣])다서(\\s*)" + CNT, "g"), "$1다섯$2$3");
    s = s.replace(new RegExp("(^|[^가-힣])여서(\\s*)" + CNT, "g"), "$1여섯$2$3");
    s = s.replace(/(한|두|세|네|다섯|여섯|일곱|여덟|아홉|열|[0-9]+)(\s*)(게|깨|계)(?![가-힣])/g, "$1$2개");
    s = s.replace(/(한|두|세|네|다섯|여섯|일곱|여덟|아홉|열|[0-9]+)(\s*)(게|깨|계)(요|만|씩|주세요|이요)/g, "$1$2개$4");
    s = s.replace(/^(투|two)$/i, "두 개");
    return s === o ? String(text || "") : s;
  }
  F.fixQty = fixQty;
  function qtyOf(t) { try { return Q() ? Q().parse(t) : 0; } catch (e) { return 0; } }
  // 문장 안 메뉴 이름 (긴 이름 먼저, 띄어쓰기 무시)
  function menuIn(text) {
    var c = sq(text), best = null;
    (menus() || []).forEach(function (m) { var n = sq(m && m.name); if (n && c.indexOf(n) >= 0 && (!best || n.length > sq(best.name).length)) best = m; });
    return best;
  }
  function stripMenu(text, name) {
    var t = String(text || ""), n = String(name || "");
    if (t.indexOf(n) >= 0) return t.replace(n, " ").replace(/\s+/g, " ").trim();
    var re = new RegExp(n.split("").map(function (ch) { return ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("\\s*"));
    return t.replace(re, " ").replace(/\s+/g, " ").trim();
  }
  // 수량 단계에서 처리할 말로 바꿔 줌 (바꿀 게 없으면 null)
  function qtyRewrite(t) {
    var st = stage(); if (!QTY_ST.test(st)) return null;
    var s = fixQty(t), ti = temp(), m = menuIn(s);
    if (m && ti && ti.item && sq(m.name) === sq(ti.item)) {
      var rest = stripMenu(s, m.name);
      if (qtyOf(rest) > 0) s = rest;
    }
    if (s !== String(t || "") && qtyOf(s) > 0) return s;
    return null;
  }
  F.qtyRewrite = qtyRewrite;

  /* ---------- 2) 다른 단계에서 '메뉴 + 개수' → 수량 화면에서 자동 입력 ---------- */
  var pendingCount = null;
  function noteMenuCount(t) {
    var st = stage(); if (QTY_ST.test(st) || /^(sleep|admin_auth|admin_panel_open|guidance|done)$/.test(st)) return;
    var s = fixQty(t), m = menuIn(s); if (!m) return;
    var n = qtyOf(stripMenu(s, m.name)); if (!(n > 0)) return;
    if (/말고|빼|취소|삭제|없애/.test(s)) return;
    pendingCount = { item: m.name, n: n, at: Date.now() };
    log("메뉴+개수 기억:", m.name, n);
  }
  setInterval(function () {
    var p = pendingCount; if (!p) return;
    if (Date.now() - p.at > 15000) { pendingCount = null; return; }
    var ti = temp();
    if (stage() === "quantity" && ti && sq(ti.item) === sq(p.item)) {
      pendingCount = null;
      setTimeout(function () {
        if (stage() !== "quantity") return;
        try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (e) {}
        F.stats.menuCount++; log("수량 화면 자동 입력:", p.item, p.n);
        try { window.processVoiceCommand(p.n + "개"); } catch (e) { console.warn("[fix] 수량 자동 입력 실패", e); }
      }, 350);
    }
  }, 150);

  /* ---------- 3) '처음으로' ---------- */
  var HOME = /처음으로|처음화면|처음부터|다시시작|첫화면|맨처음으로|홈화면|처음으로가|처음으로돌아/;
  var lastHome = 0, lastInput = 0;
  function isHome(t) { var c = sq(t); return HOME.test(c) && !/처음이|처음왔|처음와|처음인데|처음해|처음사용|처음써/.test(c); }
  // 원래 '처음으로' 처리가 막히는 단계: 시니어 결제 확인(payment_confirm, '네/아니요'만 받던 대기) · 카드 대기(guidance) · 결제 방식(payment)
  var PAY_ST = /^(payment_confirm|guidance|payment)$/;
  function showWelcome() { try { if (typeof showWelcomeScreen === "function") showWelcomeScreen(); else window.showWelcomeScreen(); } catch (e) { console.warn("[fix] showWelcomeScreen 오류", e); } }
  function goHome(src) {
    var st = stage();
    if (/^(welcome|sleep|admin_auth|admin_panel_open)$/.test(st)) return false;
    lastHome = Date.now(); F.stats.home++;
    log("처음으로 (" + src + ", stage=" + st + ")");
    try { if (window.__so4tPay && window.__so4tPay.abort) window.__so4tPay.abort("처음으로"); } catch (e) {}
    pendingCount = null;
    showWelcome();
    say("처음 화면으로 돌아갑니다.");
    armHomeWatch(st);
    return true;
  }
  // 원래 흐름으로 '처음으로'를 처리한 뒤 1.2초 뒤에도 그 단계 그대로이고 그 사이 새 말이 없으면 한 번 더 (손님이 바로 새 주문을 시작했으면 건드리지 않음)
  function armHomeWatch(st) {
    var my = lastHome;
    setTimeout(function () {
      if (lastHome !== my || lastInput > my) return;
      var s2 = stage();
      if (s2 === st && !/^(welcome|sleep)$/.test(s2)) {
        F.stats.homeRetry++; log("처음 화면이 아님(" + s2 + ") → 다시 처음으로");
        try { if (window.__so4tPay && window.__so4tPay.abort) window.__so4tPay.abort("처음으로 재시도"); } catch (e) {}
        showWelcome();
      }
    }, 1200);
  }
  function homeHook(t, src) {   // true = 여기서 처리 끝
    if (!isHome(t)) return false;
    var st = stage();
    if (/^(welcome|sleep|admin_auth|admin_panel_open)$/.test(st)) return false;
    if (PAY_ST.test(st)) return goHome(src);
    lastHome = Date.now(); armHomeWatch(st);   // 그 밖의 단계는 원래 처리 그대로 + 확인만
    return false;
  }
  F.goHome = goHome;

  /* ---------- 훅: 무관 발화 필터 / 단일 라우터 / processVoiceCommand ---------- */
  function copyFlags(from, to) { ["__senior", "__seniorPlus", "__orderStartMenu", "__payVoice", "__payHooked"].forEach(function (k) { if (from && from[k]) to[k] = from[k]; }); }
  function hookRelevance() {
    var R = window.KIOSK_RELEVANCE; if (!R || typeof R.isKioskRelated !== "function" || R.isKioskRelated.__so4tFix) return;
    var o = R.isKioskRelated;
    var w = function (text) {
      var r = o.apply(this, arguments); if (r) return r;
      try { if (QTY_ST.test(stage()) && qtyOf(fixQty(text)) > 0) { log("수량 말 통과:", text, "→", fixQty(text)); return true; } } catch (e) {}
      return r;
    };
    copyFlags(o, w); w.__so4tFix = true; w.__orig = o; R.isKioskRelated = w;
  }
  var reenter = false;
  function hookRoute() {
    var I = window.KIOSK_INTENTS; if (!I || typeof I.route !== "function" || I.route.__so4tFix) return;
    var o = I.route;
    var w = function (t, from) {
      try {
        if (!isHome(t)) lastInput = Date.now();
        if (homeHook(t, "route")) return true;
        var q = qtyRewrite(t);
        if (q !== null && !reenter && typeof window.__hybridRouteText === "function") {
          F.stats.qtyFixed++; log("수량 말 고침:", t, "→", q);
          reenter = true; try { window.__hybridRouteText(q); } finally { reenter = false; } return true;
        }
        noteMenuCount(t);
      } catch (e) { console.warn("[fix] route 오류 → 원래 흐름", e); }
      return o.apply(this, arguments);
    };
    copyFlags(o, w); w.__so4tFix = true; w.__orig = o; I.route = w;
  }
  function hookPVC() {
    var prev = window.processVoiceCommand;
    if (typeof prev !== "function" || prev.__so4tFix) return;
    var w = function so4tFixProcessVoiceCommand(text) {
      try {
        if (!isHome(text)) lastInput = Date.now();
        if (homeHook(text, "pvc")) return;
        var q = qtyRewrite(text);
        if (q !== null) { F.stats.qtyFixed++; log("수량 말 고침(pvc):", text, "→", q); var a = [].slice.call(arguments); a[0] = q; return prev.apply(this, a); }
      } catch (e) { console.warn("[fix] pvc 오류 → 원래 흐름", e); }
      return prev.apply(this, arguments);
    };
    copyFlags(prev, w); w.__so4tFix = true;
    window.processVoiceCommand = w; try { processVoiceCommand = w; } catch (e) {}
  }

  /* ---------- 4) 인식 지연: 말 끝 대기·Whisper 녹음 길이 상한 ---------- */
  function capNum(key, def) { try { var v = parseInt(localStorage.getItem(key), 10); return isFinite(v) && v > 0 ? v : def; } catch (e) { return def; } }
  function hookAcoustic() {
    var A = window.__kioskAcoustic; if (!A || typeof A.params !== "function" || A.params.__so4tFix) return;
    var o = A.params;
    var w = function () {
      var r = o.apply(this, arguments); if (!r) return r;
      var endCap = capNum("so4t_endsil_cap_ms", 1000), keepCap = capNum("so4t_keep_audio_cap_ms", 7000);
      if (r.endSilMs > endCap || r.keepAudioMs > keepCap) {
        var c = {}; for (var k in r) c[k] = r[k];
        c.endSilMs = Math.min(r.endSilMs, endCap); c.keepAudioMs = Math.min(r.keepAudioMs, keepCap); c.so4tCapped = true;
        F.stats.capped++; return c;
      }
      return r;
    };
    w.__so4tFix = true; w.__orig = o; A.params = w; log("acoustic 상한 적용 (말 끝 " + capNum("so4t_endsil_cap_ms", 1000) + "ms, Whisper " + capNum("so4t_keep_audio_cap_ms", 7000) + "ms)");
  }
  // kiosk.html 패치(__SO4T_FIX_WHISPER_BUSY__)가 이 함수를 부름: Whisper 처리 중 들어온 말 → 버리지 않고 빠른 인식 결과로 처리
  window.__so4tFixWhisperBusy = function (text) { F.stats.whisperBusy++; log("Whisper 처리 중 새 말 → 바로 처리:", text); return true; };

  function hookAll() { hookRelevance(); hookRoute(); hookPVC(); hookAcoustic(); }
  hookAll();
  window.addEventListener("load", function () { setTimeout(hookAll, 200); setTimeout(hookAll, 2500); });
  setInterval(hookAll, 2000);
  F.test = function (t) { return { home: isHome(t), qty: qtyRewrite(t), fixed: fixQty(t), n: qtyOf(fixQty(t)) }; };
  log("loaded v" + F.version);
})();
