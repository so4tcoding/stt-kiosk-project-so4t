# 소4트 키오스크 - 노트북(Windows) 시뮬레이션용 실행 스크립트
# 학습 모델(models\whisper-kiosk-ct2-int8\model.bin)이 없으면 공개 base 모델로 켬
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
if (-not (Test-Path ".\models\whisper-kiosk-ct2-int8\model.bin")) {
  Write-Host "학습 모델이 없어 WHISPER_MODEL=base 로 시작 (처음 한 번 인터넷으로 내려받음)" -ForegroundColor Yellow
  $env:WHISPER_MODEL = "base"
}
if (-not $env:KIOSK_ADMIN_PASSWORD) { $env:KIOSK_ADMIN_PASSWORD = "<ADMIN_PIN>" }   # 실제 PIN은 팀 내부에서만
$env:KIOSK_SERIAL_BRIDGE = "0"   # 노트북에는 아두이노가 없으면 끔 (있으면 이 줄 지우고 KIOSK_SERIAL_PORT=COM3 등 지정)
Start-Job { Start-Sleep -Seconds 4; Start-Process "http://127.0.0.1:8000/kiosk.html" } | Out-Null
python -m uvicorn stt_server:app --host 127.0.0.1 --port 8000
