#!/usr/bin/env python3
"""ESP32 직원 호출 보드 흉내 (보드 없이 파이 중계 시험용). 실제 스케치 so4t_call_sta.ino 와 같은 규칙:
   - 2초마다 UDP 4210 방송 "SO4T-CALL <ip>"
   - UDP 4211 "SO4T-PI" 를 들으면 파이 IP 저장 → 1초마다 http://<파이>:8021/bell 확인
   - HTTP :80 /call?id= /stop /ping /
   실행: sudo python3 fake_esp32.py [--no-http] [--no-poll] [--no-beacon]
   부저가 울리면 'BUZZER ON (how)' 를 출력."""
import argparse, socket, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ap = argparse.ArgumentParser()
ap.add_argument("--no-http", action="store_true", help="파이→보드 직접 전달이 막힌 핫스팟 흉내")
ap.add_argument("--no-poll", action="store_true", help="보드→파이 /bell 확인 끄기")
ap.add_argument("--no-beacon", action="store_true", help="보드 방송 끄기")
ap.add_argument("--port", type=int, default=80)
a = ap.parse_args()

S = {"calling": False, "last_id": "", "pi": None, "rings": 0}
def log(*x): print(time.strftime("%H:%M:%S"), "[fake-esp32]", *x, flush=True)
def ring(how):
    if not S["calling"]:
        S["rings"] += 1
        log("BUZZER ON (%s) #%d" % (how, S["rings"]))
    S["calling"] = True

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        path, _, q = self.path.partition("?")
        args = dict(p.split("=", 1) for p in q.split("&") if "=" in p)
        if path == "/call":
            if a.no_http:
                self.send_response(503); self.end_headers(); return
            cid = args.get("id", "")
            if not (cid and cid == S["last_id"]):
                if cid: S["last_id"] = cid
                ring("http")
            body = b"OK"
        elif path == "/stop":
            S["calling"] = False; log("BUZZER OFF"); body = b"STOP"
        elif path == "/ping":
            body = b"ok"
        else:
            body = ("SO4T-CALL ok\ncalling=%d\npi=%s\n" % (S["calling"], S["pi"])).encode()
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, *x): pass

def beacon():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    while True:
        for ip in ("255.255.255.255",) + ((S["pi"],) if S["pi"] else ()):
            try: s.sendto(b"SO4T-CALL fake", (ip, 4210))
            except Exception: pass
        time.sleep(2)

def listen_pi():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", 4211))
    while True:
        d, addr = s.recvfrom(64)
        if d.startswith(b"SO4T-PI") and S["pi"] != addr[0]:
            S["pi"] = addr[0]; log("파이 찾음", addr[0])

def poll():
    while True:
        time.sleep(1)
        if not S["pi"]: continue
        try:
            b = urllib.request.urlopen("http://%s:8021/bell" % S["pi"], timeout=0.7).read().decode()
            cid = b.split("id=")[1].split()[0]; age = int(b.split("age=")[1])
            if cid != S["last_id"]:
                if cid != "0" and 0 <= age <= 15: ring("bell")
                S["last_id"] = cid
        except Exception:
            pass

if not a.no_beacon: threading.Thread(target=beacon, daemon=True).start()
threading.Thread(target=listen_pi, daemon=True).start()
if not a.no_poll: threading.Thread(target=poll, daemon=True).start()
log("시작 (http=%s poll=%s beacon=%s)" % (not a.no_http, not a.no_poll, not a.no_beacon))
ThreadingHTTPServer(("0.0.0.0", a.port), H).serve_forever()
