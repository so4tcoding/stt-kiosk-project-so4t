import sys, asyncio, json, os
from playwright.async_api import async_playwright
PORT = os.environ.get("SIM_PORT", "8000")
CASES = json.load(open(sys.argv[1]))
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(executable_path=(os.environ.get("CHROME_PATH") or None))
    ctx = await b.new_context(viewport={"width":480,"height":800})
    await ctx.add_init_script("window.__SIM_MODE='flag';window.__SIM_SPEED=8;" + open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'stub.js'),encoding='utf-8').read())
    pg = await ctx.new_page(); errs=[]
    pg.on("pageerror", lambda e: errs.append(str(e)[:200]))
    await pg.goto(f"http://127.0.0.1:{PORT}/kiosk.html"); await pg.wait_for_timeout(2500)
    for shop, texts in CASES.items():
      await pg.evaluate("s=>{try{window.__kioskApplyShop&&window.__kioskApplyShop(s)}catch(e){}}", shop)
      await pg.wait_for_timeout(300)
      names = await pg.evaluate("()=>customMenus.map(m=>m.name+'/'+m.category).join(', ')")
      print("##", shop, ":", names[:400])
      for t in texts:
        r = await pg.evaluate("""t=>{const O=__so4tOneShot; const P=O.parse(t); const ms=O.multiSplit(t);
          return JSON.stringify({menu:P.menu&&P.menu.name, n:P.menuCount, qty:P.qty, temp:P.temp, place:P.place, set:P.set, cup:P.cup, bev:P.bev, food:P.food, burger:P.burger, slots:P.slots, multi:ms, multiP: ms&&ms.map(s=>{const q=O.parse(s);return [q.menu&&q.menu.name,q.qty,q.temp,q.place,q.bev,q.food]})})}""", t)
        print("  ", t, "=>", r)
    print("PAGE ERRORS:", errs)
    await b.close()
asyncio.run(main())
