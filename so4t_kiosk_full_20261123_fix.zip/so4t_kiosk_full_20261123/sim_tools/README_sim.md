# sim_tools — 헤드리스 크롬 키오스크 시뮬레이터

- `server.py` : 키오스크 파일을 내보내는 가짜 서버 (+ `/sim/press` = 큰 버튼 누름 흉내). 키오스크 폴더 경로는 파일 안 설정을 확인해 `../kiosk` 로 맞출 것.
- `stub.js`  : 가짜 speechSynthesis / SpeechRecognition (페이지에 주입). 파이처럼 늦은 이벤트를 넣어 버그 재현에 사용.
- `slot.py`, `flow.py`, `extras.py` : 시나리오 실행기 (Playwright). `t_*.json` = 시나리오, `f_*.json` = 지난 결과.
- `evalr.py` : 결과 채점.

준비: `pip install playwright` (+ `python -m playwright install chromium` 또는 `CHROME_PATH`에 Google Chrome 경로).
이번 패키징 때 stub.js 경로를 스크립트 옆 상대경로로, 크롬 경로를 `CHROME_PATH` 환경변수로 바꿈. 그 밖의 하드코딩 경로가 남아 있으면 Cursor가 맞출 것.

실행 예 (sim_tools 폴더에서):
```
python server.py ../kiosk 8000      # 가짜 서버 (실제 stt_server 대신)
python flow.py strict wakeonly      # 다른 창에서: 인자 = MODE(stub 모드, 기본 strict) PATHNAME(wakeonly/approve 등, 파일 안 확인) [결과.json]. 환경변수 FAULT, SPEED
python slot.py t_one.json out.json  # 한 문장 주문 시나리오 → 결과 파일
python evalr.py t_one.json out.json # 채점 (exp 있는 시나리오)
```
서버 포트를 8000 말고 다른 번호로 띄웠으면 `SIM_PORT=8011 python slot.py ...` 처럼 맞춤 (slot/flow/extras/probe/bell_e2e 공통).

11/23 추가:
- `t_fix1123.json` : 11/23 고친 것 23개 (말 끊김, 얼음은 적게, 고기 많이, 단계별 대답, 메뉴 두 개, 에이드 시원하게, 메뉴판 불고기 버거 등)
- `t_check_grid.json` : 메뉴판 화면에서 메뉴 이름 말하기
- `probe.py` : 한 문장 해석 결과(`__so4tOneShot.parse`/`multiSplit`)만 찍어 보기
- `fake_esp32.py` : 가짜 직원 호출 보드 (UDP 방송·/bell 확인·:80 /call). `sudo python fake_esp32.py [--no-http] [--no-poll] [--no-beacon]`
- `bell_e2e.py voice|button` : 키오스크 화면에서 직원 호출 → 중계(127.0.0.1:8020) → 가짜 보드 "BUZZER ON" 확인
  (중계: `python ../pi_setup/esp32_hotspot_1117/so4t_call_relay.py` 를 먼저 띄울 것)
