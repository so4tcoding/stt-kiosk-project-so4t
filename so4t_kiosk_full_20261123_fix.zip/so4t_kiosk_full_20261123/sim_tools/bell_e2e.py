"""키오스크 화면에서 직원 호출 → 파이 중계(127.0.0.1:8020) → (가짜) 보드. 사용: python bell_e2e.py voice|button"""
import sys, asyncio, os, urllib.request
from playwright.async_api import async_playwright
PORT = os.environ.get("SIM_PORT", "8000")
HOW = sys.argv[1] if len(sys.argv) > 1 else "voice"
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(executable_path=(os.environ.get("CHROME_PATH") or None))
    ctx = await b.new_context(viewport={"width":480,"height":800})
    await ctx.add_init_script("window.__SIM_MODE='flag';window.__SIM_SPEED=8;" + open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'stub.js'),encoding='utf-8').read())
    pg = await ctx.new_page()
    pg.on("console", lambda m: print("   C>", m.text[:160]) if ("esp32" in m.text or "직원" in m.text) else None)
    await pg.goto(f"http://127.0.0.1:{PORT}/kiosk.html"); await pg.wait_for_timeout(2500); await pg.mouse.click(240,480); await pg.wait_for_timeout(1500)
    urllib.request.urlopen(f"http://127.0.0.1:{PORT}/sim/press?msg=WAKE_BUTTON").read(); await pg.wait_for_timeout(4000)
    print("stage:", await pg.evaluate("()=>currentStageName"), "| esp32 hook:", await pg.evaluate("()=>!!(window.__kioskStaffCall&&window.__kioskStaffCall.__esp32Wrapped)"))
    if HOW == "voice":
      for _ in range(60):
        if not await pg.evaluate("()=>speechSynthesis.speaking||speechSynthesis.pending"): break
        await pg.wait_for_timeout(200)
      await pg.wait_for_timeout(600)
      print("say:", await pg.evaluate("t=>__simSay(t)", "직원 불러 주세요"))
    else:
      urllib.request.urlopen(f"http://127.0.0.1:{PORT}/sim/press?msg=STAFF_CALL").read()
    await pg.wait_for_timeout(4000)
    print("stage after:", await pg.evaluate("()=>currentStageName"))
    await b.close()
asyncio.run(main())
