(function(){
  const T0 = Date.now(); const now = () => Date.now() - T0;
  const L = window.__ttsLog = [];
  const MODE = (localStorage.getItem('__simTtsMode') || window.__SIM_MODE || 'strict');
  function allowed(){ if (MODE === 'flag') return true; try { return navigator.userActivation && navigator.userActivation.hasBeenActive; } catch(e){ return false; } }
  class Utt extends EventTarget {
    dispatchEvent(ev){ const h = this['on'+ev.type]; if (typeof h === 'function') { try { h.call(this, ev); } catch(e){ console.error('[stub] handler err', e); } } return super.dispatchEvent(ev); }
    constructor(t){ super(); this.text = t == null ? '' : String(t); this.rate=1; this.pitch=1; this.volume=1; this.voice=null; this.lang=''; this.onstart=this.onend=this.onerror=this.onboundary=this.onpause=this.onresume=this.onmark=null; }
  }
  function fire(u, type, extra){ const ev = new Event(type); Object.assign(ev, {utterance:u, charIndex:0, elapsedTime:0}, extra||{}); try { u.dispatchEvent(ev); } catch(e){} }
  const stuck = []; let faultUsed = false; const FAULT = window.__SIM_FAULT || '';
  const q = []; let cur = null, timer = null; let voicesReady = false;
  const VOICES = [{name:'Google 한국의', lang:'ko-KR', localService:false, voiceURI:'Google 한국의', default:false},{name:'Google US English', lang:'en-US', localService:false, voiceURI:'Google US English', default:true}];
  function durOf(u){ const n = u.text.replace(/\s/g,'').length; return Math.round((n*165 + 250) / (u.rate || 1) / (window.__SIM_SPEED || 1)); }
  function next(){
    if (cur || !q.length) return;
    cur = q.shift(); const u = cur; const d = durOf(u); u.__start = now();
    const LAT = Math.round(350 / (window.__SIM_SPEED || 1));  // 구글 온라인 목소리 첫 소리까지 지연
    timer = setTimeout(()=>{ if (cur !== u) return; u.__start = now(); L.push({t: now(), ev:'start', text:u.text, dur:d, rate:u.rate, voice: u.voice && u.voice.name}); fire(u, 'start');
    timer = setTimeout(()=>{ if (cur !== u) return; cur = null; L.push({t: now(), ev:'end', text:u.text}); fire(u,'end'); setTimeout(next, 0); }, d); }, LAT);
  }
  const SS = new EventTarget();
  Object.defineProperties(SS, {
    speaking: {get(){ return !!cur; }}, pending: {get(){ return q.length > 0 || stuck.length > 0; }}, paused: {get(){ return false; }},
  });
  SS.onvoiceschanged = null;
  SS.getVoices = () => voicesReady ? VOICES.slice() : [];
  SS.speak = function(u){
    if (!allowed()) { L.push({t: now(), ev:'BLOCKED(not-allowed)', text:u.text}); setTimeout(()=>fire(u,'error',{error:'not-allowed'}), 0); return; }
    if (FAULT && !faultUsed && /무엇을 드시고/.test(u.text)) { faultUsed = true;
      if (FAULT === 'drop') { L.push({t: now(), ev:'FAULT:silently-stuck', text:u.text}); stuck.push(u); return; }
      if (FAULT === 'deny') { L.push({t: now(), ev:'FAULT:not-allowed', text:u.text}); setTimeout(()=>fire(u,'error',{error:'not-allowed'}), 0); return; }
    }
    if (stuck.length) { L.push({t: now(), ev:'queued-behind-stuck', text:u.text}); stuck.push(u); return; }
    L.push({t: now(), ev:'speak', text:u.text, queued: q.length + (cur?1:0)}); q.push(u); setTimeout(next, 0);
  };
  SS.cancel = function(){
    const st = new Error().stack.split('\n').slice(2,5).map(s=>s.trim().replace(/^at /,'').replace(/https?:\/\/[^/]+\//,'')).join(' < ');
    if (stuck.length) { const st2 = stuck.splice(0); L.push({t: now(), ev:'CANCEL(stuck cleared)', n: st2.length}); st2.forEach(u => fire(u,'error',{error:'canceled'})); }
    if (cur || q.length) L.push({t: now(), ev:'CANCEL', cut: cur ? cur.text : null, cutAtMs: cur ? (now()-cur.__start) : null, dropped: q.map(x=>x.text), by: st});
    const c = cur; cur = null; clearTimeout(timer); const dq = q.splice(0);
    if (c) fire(c, 'error', {error:'interrupted'}); dq.forEach(u => fire(u, 'error', {error:'canceled'}));
  };
  SS.pause = ()=>{}; SS.resume = ()=>{};
  setTimeout(()=>{ voicesReady = true; L.push({t: now(), ev:'voiceschanged'}); try { SS.onvoiceschanged && SS.onvoiceschanged(new Event('voiceschanged')); } catch(e){} SS.dispatchEvent(new Event('voiceschanged')); }, 700);
  Object.defineProperty(window, 'speechSynthesis', {value: SS, configurable: true});
  window.SpeechSynthesisUtterance = Utt;
  // Speech recognition stub
  const recs = window.__recs = [];
  class Rec extends EventTarget { constructor(){ super(); this.lang='ko-KR'; this.continuous=false; this.interimResults=false; this.maxAlternatives=1; this.running=false; recs.push(this);} 
    start(){ if (this.running) { const e = new Error('already started'); e.name='InvalidStateError'; throw e; } this.running = true; L.push({t: now(), ev:'rec.start'}); setTimeout(()=>{ this.onstart && this.onstart(new Event('start')); this.dispatchEvent(new Event('start')); this.onaudiostart && this.onaudiostart(new Event('audiostart')); }, 20); }
    stop(){ if (!this.running) return; this.running=false; setTimeout(()=>{ this.onend && this.onend(new Event('end')); this.dispatchEvent(new Event('end')); }, 20); }
    abort(){ this.stop(); } }
  window.SpeechRecognition = window.webkitSpeechRecognition = Rec;
  window.__simSay = function(text){
    const r = recs.filter(x=>x.running).pop(); if (!r) return 'no-running-rec';
    const alt = {transcript: text, confidence: 0.95}; const res = [alt]; res.isFinal = true; res.length = 1; res.item = i=>res[i];
    const results = [res]; results.item = i=>results[i];
    const ev = new Event('result'); ev.results = results; ev.resultIndex = 0;
    L.push({t: now(), ev:'USER_SAYS', text});
    r.onresult && r.onresult(ev); r.dispatchEvent(ev); return 'ok';
  };
  window.__simNow = now;
})();
