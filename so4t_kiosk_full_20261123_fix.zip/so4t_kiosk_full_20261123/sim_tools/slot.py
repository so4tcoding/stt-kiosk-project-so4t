import sys, asyncio, json, urllib.request, time, os
from playwright.async_api import async_playwright
SPEED = float(os.environ.get("SPEED","8"))
SIM_BASE = "http://127.0.0.1:" + os.environ.get("SIM_PORT", "8000")
TESTS = json.load(open(sys.argv[1])); OUT = sys.argv[2]
STATE_JS = """()=>{let s,t=null,it=[],pl='';try{s=currentStageName}catch(e){}; try{t=JSON.parse(JSON.stringify(tempItem))}catch(e){}; try{it=JSON.parse(JSON.stringify(orderState.items)); pl=orderState.place}catch(e){}; return {stage:s,temp:t,items:it,place:pl}}"""
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(executable_path=(os.environ.get("CHROME_PATH") or None), args=["--use-fake-ui-for-media-stream","--use-fake-device-for-media-stream"])
    ctx = await b.new_context(viewport={"width":480,"height":800})
    await ctx.add_init_script(f"window.__SIM_MODE='flag';window.__SIM_SPEED={SPEED};" + open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'stub.js'),encoding='utf-8').read())
    pg = await ctx.new_page(); errs=[]
    pg.on("pageerror", lambda e: errs.append(str(e)[:200]))
    clog=[]
    pg.on("console", lambda m: clog.append(m.text[:200]))
    await pg.goto(SIM_BASE+"/kiosk.html")
    await pg.wait_for_timeout(2500); await pg.mouse.click(240,480); await pg.wait_for_timeout(2000)
    async def idle():
      for i in range(300):
        if not await pg.evaluate("()=>speechSynthesis.speaking||speechSynthesis.pending"):
          await pg.wait_for_timeout(500)
          if not await pg.evaluate("()=>speechSynthesis.speaking||speechSynthesis.pending"): return
        await pg.wait_for_timeout(100)
    results=[]
    for T in TESTS:
      shop = T.get("shop","gukbap")
      await pg.evaluate("s=>{try{window.__kioskApplyShop&&window.__kioskApplyShop(s)}catch(e){}}", shop)
      await pg.evaluate("()=>{window.enterSleepMode()}"); await pg.wait_for_timeout(300); await idle()
      urllib.request.urlopen(SIM_BASE+"/sim/press?msg=WAKE_BUTTON").read()
      await pg.wait_for_timeout(1200); await idle()
      if T.get("js"):
        await pg.evaluate(T["js"]); await pg.wait_for_timeout(600); await idle()
      if T.get("pre"):
        for pre in T["pre"]:
          await pg.evaluate("t=>__simSay(t)", pre); await pg.wait_for_timeout(800); await idle()
          print("   pre", pre, "=>", await pg.evaluate("()=>currentStageName"), flush=True)
      n0 = await pg.evaluate("()=>__ttsLog.length"); c0=len(clog)
      steps=[]
      for k, utt in enumerate(T["say"]):
        r = await pg.evaluate("t=>__simSay(t)", utt)
        await pg.wait_for_timeout(700)
        for _ in range(120):
          if not await pg.evaluate("()=>!!(window.__so4tOneShot&&__so4tOneShot.active)"): break
          await pg.wait_for_timeout(100)
        await idle(); await pg.wait_for_timeout(300); await idle()
        st = await pg.evaluate(STATE_JS)
        log = await pg.evaluate("n=>__ttsLog.slice(n)", n0); n0 += len(log)
        tts = [e['text'] for e in log if e['ev'] in ('speak',)]
        run = await pg.evaluate("()=>window.__so4tOneShot? __so4tOneShot.runs.slice(-1)[0]||null : null")
        steps.append({"run":run, "say":utt, "rec":r, "stage":st['stage'], "temp":st['temp'], "items":st['items'], "place":st['place'], "tts":tts})
      results.append({"name":T.get("name",""), "shop":shop, "steps":steps, "console":[c for c in clog[c0:] if any(k in c for k in ['kfix','fix','HYBRID 메뉴','DIRECT','slot','차단','수량'])][:60]})
      print("==", T.get("name",""), "|", " -> ".join(f"{s['say']}⇒{s['stage']}" for s in steps), flush=True)
      last=steps[-1]; print("   items:", [ (i.get('item'),i.get('count'),i.get('temp'),i.get('cupSize'),i.get('options'),i.get('beverageOptions')) for i in last['items']], "place:", last['place'], "temp:", last['temp'] and {k:last['temp'].get(k) for k in ('item','count','temp','cupSize','options','beverageOptions')})
      for s in steps: print("   TTS[", s['say'], "]:", " / ".join(s['tts'])[:400])
    json.dump(results, open(OUT,"w"), ensure_ascii=False, indent=1)
    print("PAGE ERRORS:", errs[:10])
    await b.close()
asyncio.run(main())
