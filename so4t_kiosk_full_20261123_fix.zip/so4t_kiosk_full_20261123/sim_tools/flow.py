import sys, asyncio, json, urllib.request, time, os
from playwright.async_api import async_playwright
SIM_BASE = "http://127.0.0.1:" + os.environ.get("SIM_PORT", "8000")
MODE = sys.argv[1]; PATHNAME = sys.argv[2]; OUT = sys.argv[3] if len(sys.argv)>3 else None
def press(msg="WAKE_BUTTON"): urllib.request.urlopen(SIM_BASE+"/sim/press?msg="+msg).read()
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(executable_path=(os.environ.get("CHROME_PATH") or None), args=["--use-fake-ui-for-media-stream","--use-fake-device-for-media-stream"])
    ctx = await b.new_context(viewport={"width":480,"height":800})
    await ctx.add_init_script("window.__SIM_MODE=%s;window.__SIM_FAULT=%s;window.__SIM_SPEED=%s;" % (json.dumps(MODE), json.dumps(os.environ.get("FAULT","")), os.environ.get("SPEED","1")) + ("try{localStorage.setItem('kiosk_tts_gap_ms',%s)}catch(e){};" % json.dumps(os.environ["GAP"]) if os.environ.get("GAP") else "") + open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'stub.js'),encoding='utf-8').read())
    pg = await ctx.new_page()
    errs=[]
    pg.on("pageerror", lambda e: (errs.append(str(e)[:200]), print("PAGEERR", str(e)[:200])))
    pg.on("console", lambda m: print("   C>", m.text[:170]) if any(k in m.text for k in ["[kfix1117]","[payment]","SLEEP_GATE","staff","직원","[fix]","TTS_FINAL","무시","ignore","drop"]) else None)
    await pg.goto(SIM_BASE+"/kiosk.html")
    since=[0]
    async def dump(label):
      st = await pg.evaluate("()=>{let s;try{s=currentStageName}catch(e){s=window.currentStageName}; let it=[];try{it=orderState.items.map(i=>i.item+'x'+i.count)}catch(e){}; return {stage:s, items:it, log:window.__ttsLog}}")
      print(f"---- [{label}] stage={st['stage']} cart={st['items']}")
      for e in st['log'][since[0]:]:
        if e['ev'] in ('rec.start','voiceschanged'): continue
        print("    ", json.dumps(e, ensure_ascii=False)[:330])
      since[0] = len(st['log'])
      return st
    async def idle(maxms=25000):
      t=time.time()
      while (time.time()-t)*1000 < maxms:
        busy = await pg.evaluate("()=>speechSynthesis.speaking||speechSynthesis.pending")
        if not busy:
          await pg.wait_for_timeout(700)
          if not await pg.evaluate("()=>speechSynthesis.speaking||speechSynthesis.pending"): return
        await pg.wait_for_timeout(150)
    async def say(text, label=None):
      await idle(); await pg.wait_for_timeout(400)
      r = await pg.evaluate("t=>window.__simSay(t)", text)
      if r != 'ok': print("   say failed:", r, text)
      await pg.wait_for_timeout(1500); await idle(); return await dump(label or ("say: "+text))
    await pg.wait_for_timeout(2500)
    await pg.mouse.click(240, 480)   # 부팅 화면 한 번 터치
    await pg.wait_for_timeout(1500); await idle(); await dump("boot tap -> sleep")
    press("WAKE_BUTTON"); await pg.wait_for_timeout(1500); await idle(); await pg.wait_for_timeout(int(__import__("os").environ.get("EXTRA","0"))); await idle(); await dump("WAKE_BUTTON (큰 버튼)")
    if PATHNAME == "wakeonly":
      await b.close(); return
    await say("돼지국밥 두 개 주세요")
    for i in range(12):
      st = await dump("check")
      s = st['stage']
      if s in ('payment','pay_card','card_wait') or 'pay' in str(s): break
      ans = {"quantity":"두 개","add_more_prompt":"아니요","place":"매장에서 먹을게요","summary":"네","confirm":"네","upsell":"아니요","taste_select_prompt":"아니요"}.get(s)
      if not ans:
        if 'add' in s or 'more' in s: ans = "아니요 됐어요"
        elif 'place' in s: ans = "매장"
        elif 'confirm' in s or 'summary' in s: ans = "네 맞아요"
        elif 'upsell' in s or 'set' in s: ans="아니요"
        else: ans = "네"
      await say(ans)
    st = await say("카드로 할게요")
    if PATHNAME == "approve":
      await pg.wait_for_timeout(1500); await idle()
      await dump("before U"); await pg.keyboard.press("u")
      await pg.wait_for_timeout(1000); await dump("after U (approve)")
      for i in range(20):
        await pg.wait_for_timeout(1000)
        st = await dump(f"+{i+1}s")
        if st['stage']=='sleep' and i>3: 
          await pg.wait_for_timeout(9000); await dump("sleep +9s"); break
    elif PATHNAME == "timeout":
      for i in range(30):
        await pg.wait_for_timeout(1000)
        st = await dump(f"wait {i+1}s (no U)")
    if OUT: await pg.screenshot(path=OUT)
    print("PAGE ERRORS:", errs)
    await b.close()
asyncio.run(main())
