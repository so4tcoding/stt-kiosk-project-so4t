import sys, os, json, time, threading, queue, mimetypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
ROOT = sys.argv[1]; PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8000
EVENTS = []; LOCK = threading.Lock(); SEQ = [0]
JS = {"kiosk_talk.js","kiosk_assist.js","kiosk_use_metrics.js","kiosk_customer.js","kiosk_shop.js","kiosk_presbyopia.js","kiosk_pi.js","kiosk_serial_bridge.js","kiosk_pi_perf.js","kiosk_v88.js","kiosk_v89.js","three.min.js","kiosk_acoustic.js","kiosk_icons.js"}
class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def send(self, code, body, ct="application/json"):
        if isinstance(body, (dict, list)): body = json.dumps(body).encode()
        elif isinstance(body, str): body = body.encode()
        self.send_response(code); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(body)
    def file(self, p):
        if not os.path.isfile(p): return self.send(404, {"detail": "nf"})
        ct = mimetypes.guess_type(p)[0] or "application/octet-stream"
        if p.endswith(".js"): ct = "application/javascript"
        self.send(200, open(p, "rb").read(), ct)
    def do_HEAD(self): self.do_GET()
    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/": return self.send(200, {"status": "ok", "model_ready": True})
        if path in ("/kiosk.html", "/kiosk"): return self.file(os.path.join(ROOT, "kiosk.html"))
        if path == "/menu.json": return self.file(os.path.join(ROOT, "menu.json"))
        if path.startswith("/static/"): return self.file(os.path.join(ROOT, "static", path[8:]))
        if path.lstrip("/") in JS:
            n = path.lstrip("/")
            for d in (ROOT, os.path.join(ROOT, "js")):
                if os.path.isfile(os.path.join(d, n)): return self.file(os.path.join(d, n))
        if path == "/sim/press":
            msg = self.path.split("msg=")[1] if "msg=" in self.path else "WAKE_BUTTON"
            with LOCK: SEQ[0] += 1; EVENTS.append({"id": SEQ[0], "event": msg})
            return self.send(200, {"ok": True, "id": SEQ[0]})
        if path == "/api/button-status": return self.send(200, {"connected": True, "port": "/dev/ttyUSB0"})
        if path == "/api/button-events":
            self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self.send_header("Cache-Control", "no-cache"); self.end_headers()
            last = SEQ[0]
            try:
                self.wfile.write(b"retry: 2000\n\nevent: status\ndata: " + json.dumps({"connected": True, "port": "/dev/ttyUSB0"}).encode() + b"\n\n"); self.wfile.flush()
                while True:
                    with LOCK: evs = [e for e in EVENTS if e["id"] > last]
                    for e in evs:
                        last = e["id"]; self.wfile.write(("data: " + json.dumps(e) + "\n\n").encode()); self.wfile.flush()
                    time.sleep(0.1)
            except Exception: return
        if path == "/staff_call": return self.send(200, {"calls": []})
        if path == "/kiosk_settings": return self.send(200, {"shop": "gukbap"})
        if path == "/api/acoustic-profile": return self.send(200, {})
        return self.send(404, {"detail": "not found"})
    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0); body = self.rfile.read(n) if n else b""
        path = self.path.split("?")[0]
        if path == "/transcribe": return self.send(200, {"text": "", "ok": True})
        if path == "/staff_call": print("STAFF_CALL POST", body[:200], flush=True); return self.send(200, {"ok": True, "id": 1})
        return self.send(200, {"ok": True})
    def do_OPTIONS(self): self.send(200, {})
ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
