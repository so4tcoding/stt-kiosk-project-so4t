import json, sys
T = {t['name']: t for t in json.load(open(sys.argv[1]))}
R = json.load(open(sys.argv[2]))
rows=[]; ok_n=0
for r in R:
  t = T[r['name']]; e = t.get('exp', {}); last = r['steps'][-1]
  items = last['items'] or []; it = items[-1] if items else None; tmp = last['temp'] or {}
  first_run = r['steps'][0].get('run')
  used = bool(first_run and first_run.get('raw') == t['say'][0])
  fails=[]
  if 'stage' in e and last['stage'] != e['stage']: fails.append(f"stage={last['stage']}")
  if 'stage_any' in e and last['stage'] not in e['stage_any']: fails.append(f"stage={last['stage']}")
  if 'item' in e and (not it or it.get('item') != e['item']): fails.append(f"item={it and it.get('item')}")
  if 'item_t' in e and tmp.get('item') != e['item_t']: fails.append(f"temp.item={tmp.get('item')}")
  if 'n_items' in e and len(items) != e['n_items']: fails.append(f"n_items={len(items)}")
  if 'count_t' in e and tmp.get('count') != e['count_t']: fails.append(f"temp.count={tmp.get('count')}")
  if 'cup_t' in e and tmp.get('cupSize') != e['cup_t']: fails.append(f"temp.cupSize={tmp.get('cupSize')}")
  if 'temp_t' in e and e['temp_t'] not in str(tmp.get('temp')): fails.append(f"temp.temp={tmp.get('temp')}")
  if 'items' in e:
    got = [(x.get('item'), x.get('count')) for x in items]
    if got != [tuple(x) for x in e['items']]: fails.append(f"items={got}")
  for k in ('food_t','bev_t'):
    if k in e:
      src = tmp.get({'bev_t':'beverageOptions','food_t':'foodOptions'}[k]) or {}
      for kk,vv in e[k].items():
        if src.get(kk) != vv: fails.append(f"{k}.{kk}={src.get(kk)}")
  if 'count' in e and (not it or it.get('count') != e['count']): fails.append(f"count={it and it.get('count')}")
  _ti = it or tmp
  if 'temp' in e and (not _ti or e['temp'] not in str(_ti.get('temp'))): fails.append(f"temp={_ti and _ti.get('temp')}")
  if 'place' in e and e['place'] not in str(last['place']): fails.append(f"place={last['place']}")
  for k in ('bev','food','burger'):
    if k in e:
      src = (it or {}).get({'bev':'beverageOptions','food':'foodOptions','burger':'burgerOptions'}[k]) or {}
      for kk,vv in e[k].items():
        if src.get(kk) != vv: fails.append(f"{k}.{kk}={src.get(kk)}")
  if 'oneshot' in e and used != e['oneshot']: fails.append(f"oneshot={used}")
  ok = not fails; ok_n += ok
  tts = " / ".join(sum([s['tts'] for s in r['steps']], []))[:150]
  desc = (f"{it.get('item')} x{it.get('count')} {it.get('temp') or ''} {json.dumps(it.get('beverageOptions') or it.get('foodOptions') or it.get('burgerOptions') or {}, ensure_ascii=False)}" if it else (f"(선택중) {tmp.get('item')}" if tmp.get('item') else "-"))
  rows.append((r['name'], " → ".join(t['say']), last['stage'], desc, last['place'] or "", "PASS" if ok else "FAIL: "+", ".join(fails), tts))
for row in rows: print(" | ".join(str(x) for x in row))
print(f"\n{ok_n}/{len(rows)} PASS")
