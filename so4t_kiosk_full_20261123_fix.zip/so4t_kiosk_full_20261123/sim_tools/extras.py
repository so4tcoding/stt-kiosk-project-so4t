import sys, asyncio, json, urllib.request, time, os
from playwright.async_api import async_playwright
SIM_BASE = "http://127.0.0.1:" + os.environ.get("SIM_PORT", "8000")
def press(msg="WAKE_BUTTON"): urllib.request.urlopen(SIM_BASE+"/sim/press?msg="+msg).read()
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(executable_path=(os.environ.get("CHROME_PATH") or None), args=["--use-fake-ui-for-media-stream","--use-fake-device-for-media-stream"])
    ctx = await b.new_context(viewport={"width":480,"height":800})
    await ctx.add_init_script("window.__SIM_MODE='strict';" + open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'stub.js'),encoding='utf-8').read())
    pg = await ctx.new_page(); errs=[]
    pg.on("pageerror", lambda e: errs.append(str(e)[:200]))
    pg.on("console", lambda m: print("   C>", m.text[:200]) if any(k in m.text for k in ["[kfix1117]","[payment]","직원","STAFF","staff"]) else None)
    await pg.goto(SIM_BASE+"/kiosk.html")
    since=[0]
    async def dump(label):
      st = await pg.evaluate("()=>{let s;try{s=currentStageName}catch(e){}; return {stage:s, log:window.__ttsLog}}")
      print(f"---- [{label}] stage={st['stage']}")
      for e in st['log'][since[0]:]:
        if e['ev'] in ('rec.start','voiceschanged','end'): continue
        print("    ", json.dumps(e, ensure_ascii=False)[:200])
      since[0]=len(st['log'])
    async def idle():
      for i in range(200):
        if not await pg.evaluate("()=>speechSynthesis.speaking||speechSynthesis.pending"):
          await pg.wait_for_timeout(700)
          if not await pg.evaluate("()=>speechSynthesis.speaking||speechSynthesis.pending"): return
        await pg.wait_for_timeout(150)
    async def say(t): await idle(); await pg.wait_for_timeout(300); await pg.evaluate("t=>__simSay(t)", t); await pg.wait_for_timeout(1500); await idle(); await dump("say "+t)
    await pg.wait_for_timeout(2500); await pg.mouse.click(240,480); await pg.wait_for_timeout(1000); await idle()
    bar = await pg.evaluate("()=>{const b=document.getElementById('senior-bar'); return b? {exists:true, display:getComputedStyle(b).display, visible: b.offsetParent!==null, btns:[...document.querySelectorAll('.senior-btn')].map(x=>x.textContent+':'+getComputedStyle(x).display)} : {exists:false}}")
    print("SENIOR BAR:", bar)
    await dump("sleep")
    press("STAFF_CALL"); await pg.wait_for_timeout(3000); await dump("STAFF_CALL in sleep")
    await idle(); press("WAKE_BUTTON"); await pg.wait_for_timeout(2000); await idle(); await dump("wake #1")
    await say("돼지국밥 한 개 주세요")
    press("STAFF_CALL"); await pg.wait_for_timeout(3000); await idle(); await dump("STAFF_CALL during order")
    await say("처음으로")
    await pg.wait_for_timeout(1000); await dump("after 처음으로")
    # 두 번째 손님: 절전으로 보내고 다시 깨우기
    await pg.evaluate("()=>window.enterSleepMode()"); await pg.wait_for_timeout(1500); await idle(); await dump("enterSleepMode (idle path, stage not done)")
    press("WAKE_BUTTON"); await pg.wait_for_timeout(2000); await idle(); await dump("wake #2")
    # 결제 실패 → 다시 / 직원
    await pg.evaluate("()=>{orderState.items=[{item:'돼지국밥',count:1,isSet:false,temp:'기본'}]; selectPayment('카드')}"); await pg.wait_for_timeout(1500); await idle(); await dump("card wait")
    await pg.evaluate("()=>__so4tPay.sim('fail')"); await pg.wait_for_timeout(1500); await idle(); await dump("pay fail")
    await say("다시 할게요")
    await pg.keyboard.press("u"); await pg.wait_for_timeout(1500); await idle(); await pg.wait_for_timeout(6000); await idle(); await dump("U after retry -> goodbye -> sleep")
    print("PAGE ERRORS:", errs)
    await b.close()
asyncio.run(main())
