#!/bin/bash
# ~/kiosk_project/pi/kiosk_launcher.sh  — 데스크톱(labwc 또는 wayfire) 로그인 뒤 자동 실행
#  1) 화면: HDMI만 끔. 터치 화면 방향은 바꾸지 않음 (__V891__)
#  2) 소리: 기본 출력 음량 100%
#  3) [V8.8] 서버를 기다리지 않고 바로 크롬을 '준비 중' 화면(pi/loading.html)으로 띄움 → 서버가 뜨면 자동으로 키오스크로 넘어감
#  4) Chromium 키오스크 실행, 꺼지면 5초 뒤 다시 실행
#  [V8.9] __V89__ 키오스크 주소에 ?pi=1 → 파이 모드(3D 끄고 2D, 애니메이션·그림자 끔) 확실히 켜짐. 끄려면 KIOSK_PI_PARAM= 로 빈 값
#  [V8.9.1] __V891__ DSI-1 --transform 90 을 뺌. 이 줄이 켤 때마다 화면 설정(Screen Configuration)의 180도를 90도로 덮어썼음
#  [V8.8] 크롬 가속 옵션 추가. 화면이 이상하면  touch ~/kiosk_project/pi/SAFE_FLAGS  후 재부팅 → 예전 옵션만 사용
LOG="${KIOSK_LOG:-$HOME/kiosk_project/kiosk_launcher.log}"
mkdir -p "$(dirname "$LOG")"
URL="http://localhost:8000/kiosk${KIOSK_PI_PARAM-?pi=1}"   # __V89__
LOADING="$(cd "$(dirname "$0")" && pwd)/loading.html"   # __V88__
START_URL="$URL"
if [ -f "$LOADING" ]; then START_URL="file://$LOADING${KIOSK_PI_PARAM-?pi=1}"; fi   # __V89__ loading.html 이 ?pi=1 을 키오스크 주소로 넘김
exec >>"$LOG" 2>&1
echo "==== $(date '+%F %T') launcher start (pid $$) ===="

# 한 번만 실행 (labwc/wayfire autostart가 겹쳐도 하나만)
LOCK="/tmp/kiosk_launcher.lock"
exec 9>"$LOCK"
if ! flock -n 9; then echo "already running"; exit 0; fi

export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export WAYLAND_DISPLAY="${WAYLAND_DISPLAY:-wayland-0}"

sleep 3   # 데스크톱이 화면을 다 잡을 때까지 잠깐

# ---- 1) 화면 ----
# [V8.9.1] __V891__ 방향(--transform)은 여기서 지정하지 않는다.
#   v8.9 는 켤 때마다 DSI-1 을 90도로 덮어써서, 화면 설정에 저장한 180도가 풀렸음.
#   180도는 라즈베리파이 화면 설정(Screen Configuration)에 저장해 둔 값을 그대로 쓴다.
if command -v wlr-randr >/dev/null 2>&1; then
  wlr-randr --output HDMI-A-1 --off || echo "wlr-randr HDMI-A-1 off 실패(연결 안 됨이면 정상)"
else
  echo "wlr-randr 없음 (sudo apt install wlr-randr)"
fi

# ---- 2) 소리 (PipeWire) ----
if command -v wpctl >/dev/null 2>&1; then
  for i in 1 2 3 4 5; do wpctl set-volume @DEFAULT_AUDIO_SINK@ 1.0 && break; sleep 2; done
  wpctl set-mute @DEFAULT_AUDIO_SINK@ 0 || true
fi

# ---- 3) 서버 기다리기 ----
# [V8.8] loading.html 이 있으면 기다리지 않음(그 화면이 서버를 확인하고 넘어감). 없으면 예전처럼 최대 3분 기다림
if [ "$START_URL" = "$URL" ]; then
  for i in $(seq 1 90); do
    if curl -s -o /dev/null -m 2 "http://localhost:8000/"; then echo "server up after $((i*2))s"; break; fi
    sleep 2
  done
fi

# ---- 4) Chromium (꺼지면 다시) ----
CHROMIUM="$(command -v chromium || command -v chromium-browser)"
if [ -z "$CHROMIUM" ]; then echo "chromium 없음"; exit 1; fi
PROFILE="${KIOSK_PROFILE:-/home/so4t/kiosk_chrome}"   # 시험용으로만 바꿀 수 있게; 기본값 그대로 사용
mkdir -p "$PROFILE"
# [V8.8] 렉 줄이는 크롬 옵션 (GPU로 그리기, 번역·캐스트 등 안 쓰는 기능 끄기)
EXTRA_FLAGS=(--enable-gpu-rasterization --disable-smooth-scrolling
  --disable-features=Translate,MediaRouter,OptimizationHints,AutofillServerCommunication
  --disable-pinch --overscroll-history-navigation=0 --check-for-update-interval=31536000
  --ignore-gpu-blocklist --enable-zero-copy --num-raster-threads=2)   # __V89__ 파이 GPU가 막혀 있어도 GPU로 그리기 (화면이 이상하면 SAFE_FLAGS)
if [ "${KIOSK_SAFE_FLAGS:-0}" = "1" ] || [ -f "$(dirname "$0")/SAFE_FLAGS" ]; then EXTRA_FLAGS=(); echo "safe flags (V8.8 옵션 끔)"; fi
while true; do
  # 지난번에 강제로 꺼졌으면 '복원' 말풍선이 안 뜨게 표시 정리
  sed -i 's/"exited_cleanly":false/"exited_cleanly":true/; s/"exit_type":"Crashed"/"exit_type":"Normal"/' "$PROFILE/Default/Preferences" 2>/dev/null || true
  echo "$(date '+%F %T') chromium start"
  "$CHROMIUM" \
    --user-data-dir="$PROFILE" \
    --ozone-platform=wayland \
    --kiosk \
    --enable-speech-dispatcher \
    --remote-debugging-port=9222 \
    --autoplay-policy=no-user-gesture-required \
    --password-store=basic \
    --noerrdialogs --disable-session-crashed-bubble --no-first-run \
    "${EXTRA_FLAGS[@]}" \
    "$START_URL" 9>&-
  rc=$?
  echo "$(date '+%F %T') chromium exited (code $rc) → 5초 뒤 다시 실행"
  sleep 5
done
