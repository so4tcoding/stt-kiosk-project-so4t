[v8.9.1] 화면 방향: 실행기가 켤 때마다 DSI를 90도로 되돌리던 줄을 뺐습니다. 자세한 설치는 README_v8_9_1.txt
키오스크 v8.9 (2026-10-27 KST) — 파이 렉 줄이기 + 목소리 특징 맞춤(새 기능) + 손님 녹음 저장 끄기
(기능 삭제 없음 · 하이브리드 음성 인식(크롬 Web Speech 먼저 → Whisper 보조) 그대로)

==================================================================
1. 파이 모드 (렉 줄이기) — 노트북은 v8.8과 똑같은 화려한 화면 그대로
==================================================================
[파이 모드가 켜지는 조건]
  - 주소에 ?pi=1 (v8.9 실행기 pi/kiosk_launcher.sh가 자동으로 붙임)
  - 또는 브라우저가 파이(aarch64/ARM 리눅스)라고 알려줄 때
    ※ 요즘 크롬은 파이에서도 "Linux x86_64"라고 속여서 알려 주는 경우가 있음 → v8.8 자동 감지가 파이에서
      안 켜졌을 가능성. 그래서 v8.9는 실행기에서 ?pi=1을 직접 붙임.
  - 강제로 켜기/끄기(브라우저 콘솔): localStorage.setItem("kiosk_pi_mode","1") / localStorage.setItem("kiosk_pi_off","1")

[파이 모드에서 바뀌는 것 — 기능은 그대로, 그림만 가볍게]
  1) 3D 라이브러리(three.js, 약 600KB)를 아예 안 불러옴. (노트북에서는 /three.min.js로 따로 불러옴)
  2) 토핑 떨어지는 효과 → 같은 위치·색의 2D 동그라미 효과. 떨어지는 동안만 그리고 끝나면 그림판을 1x1로 줄임.
  3) 절전 로봇 → 2D 로봇 그림을 한 번만 그림(계속 움직이지 않음).
  4) 흐림(backdrop-filter/blur), 그림자, 필터, 계속 도는 애니메이션 끔.
     - v8.8은 로봇 쪽 !important 규칙이 '가볍게' 규칙을 이겨서 주문 화면에서도 초당 60번 화면 계산을 했음 → 해결.
     - 마이크 버튼: 모양은 고정, 듣는 중에는 주황 테두리로 표시.
  5) 절전이 아닐 때 마이크 dB 계산 간격 250ms.
[서버]
  - 음성 인식 요청 기록(access log) 끔(--no-access-log) → 서비스 파일 바뀜(아래 '한 번만 할 일').
  - 시리얼/LED 실시간 알림(SSE) 반복: 새 소식이 있을 때만 목록을 훑고, 연결 확인은 1초에 1번.
  - Whisper 설정 확인: int8, beam 1, vad_filter, CPU 3코어(1코어는 화면용), 쉬는 동안 CPU 거의 0 — 그대로 유지.
  - 녹음은 디스크에 안 쓰고 메모리에서 바로 인식(실패할 때만 임시 파일 → 끝나면 바로 삭제).
[크롬 옵션] --ignore-gpu-blocklist --enable-zero-copy --num-raster-threads=2 추가
  화면이 깨지거나 검게 나오면:  touch ~/kiosk_project/pi/SAFE_FLAGS  후 재부팅 → 옵션 없이 실행
[선택] 화면 해상도를 1280x720으로 낮추면 더 가벼움(모니터가 지원할 때):
  wlr-randr --output HDMI-A-1 --mode 1280x720
  (출력 이름은 그냥 wlr-randr 쳐서 확인. 원래대로는 재부팅)

[측정 결과 — 헤드리스 크롬, CPU 6배 느리게(파이4 흉내), 1024x600]
  (같은 시간에 2번씩 잰 값. 메인 스레드 사용률 = 낮을수록 좋음. style = 1초당 화면 스타일 다시 계산 횟수)
                         v8.8 가볍게(?lite=1)     v8.9 파이 모드(?pi=1)
  처음 로딩 메인스레드     1,021~1,047ms            781~814ms
  자바스크립트 메모리      4MB (3D 포함)            2MB (3D 안 불러옴)
  시작 화면 대기           10~11%, style 60/s       3~4%, style 1/s
  주문 화면 대기           10~11%, style 60/s       2~3%, style 1/s
  주문 진행(말 5번)        21%, style 59/s          12~13%, style 14/s
  절전 화면                2~3%                     2~3%
  긴 작업(50ms 넘음) 수    로딩 3개(최대 146~151ms)   로딩 2~3개(최대 95~105ms)
  목소리 특징 맞춤 계산 비용: 1초에 1.1~1.3ms (CPU 6배 느리게 한 상태 기준, 1코어의 약 0.1%)
     맞춤 끄고 잰 v8.9 파이 모드와 사용률 차이 없음(2~3% vs 2~3%, 주문 진행 12~13% 둘 다)
  노트북 모드: v8.8과 같은 수준(시작 화면 12~13%, 주문 진행 28~29%) → 화려한 화면 그대로 유지
  ※ 여기는 GPU 없는 서버라 실제 파이와 숫자는 다름. 비교(전/후) 용도로만 보기.

==================================================================
2. 새로 추가한 기능: 목소리 특징 맞춤 (개인정보 안전)
==================================================================
※ 확인 결과 예전 버전(로컬 모든 버전 + GitHub 커밋 139개)에는 '소리 크기·높이로 단어를 배우는 기능'이
  없었음(글자 기반 자동 학습만 있었음). 그래서 v8.9에서 새로 만듦: js/kiosk_acoustic.js

[무엇을 재나 — 숫자 요약만]
  - 소리 크기: dB 평균, 범위(10%~90%)
  - 목소리 높이: F0(기본 주파수) 중앙값·범위 — 말하는 동안에만, 1초에 최대 10번 (가벼운 자기상관 계산)
  - 말 길이·속도: 한 마디 길이, 인식된 글자 수 ÷ 말한 시간(1초당 음절), 말 사이 쉼
  - 주변 소음 크기
  녹음 파일·파형·스펙트로그램·사람을 구별하는 정보(이름, 기기 번호 등)는 만들지도 저장하지도 않음.

[인식이 어떻게 바뀌나]
  - 작게 말하는 손님: '말 시작' 기준 소리 크기를 낮춤(기본 0.012 → 최저 0.004, 항상 주변 소음보다는 크게)
  - 천천히·띄엄띄엄 말하는 손님: '말 끝' 판정 쉼 시간 750ms → 최대 1600ms,
    Whisper로 보내는 최근 소리 7초 → 최대 10초  (중간에 말이 잘리는 것 방지)
  - 보통 손님: v8.8 값 그대로
  - 한 손님(세션) 동안 기억, 90초 쉬거나 절전되면 새 손님. 손님들 평균은 천천히 누적.
  - 주문이 '완료'까지 가면 그 메뉴 이름별로 평균(음절당 길이, dB, F0, 높이 구간 횟수)만 저장.
    다음에 Web Speech 후보가 여러 개로 헷갈리면(예: 순대국밥 / 소고기국밥) 말 길이·높이가 더 맞는 쪽에
    살짝 가산점. 차이가 충분할 때만 순서를 바꾸고, 근거가 없으면 원래 순서 그대로.

[저장 위치] 브라우저 localStorage "kiosk_acoustic_profile_v1" + 서버 kiosk_v8_data/acoustic_profile.json
  (숫자만, 16KB 이하, 메뉴 단어 최대 60개, 서버는 키오스크 기기 자신(localhost)에서 온 요청만 저장)
  저장 예시:
  {"v":1,"updated":"2026-10-27","global":{"sessions":0,"utterances":0,"dbMean":0,"f0Med":0,"rate":0,"floorDb":0},
   "words":{"소고기국밥":{"n":3,"msPerSyl":460,"db":57.3,"f0":130,"lo":3,"mid":0,"hi":0}}}
[지우기]  파이 터미널:  curl -X DELETE http://localhost:8000/api/acoustic-profile
          또는 키오스크 화면 콘솔: __kioskAcoustic.reset()   (둘 다 지우려면 콘솔 쪽 권장: 브라우저+서버 같이 지움)
[끄기]    콘솔: localStorage.setItem("kiosk_acoustic_off","1") 후 새로고침 → v8.8과 똑같이 동작
[보기]    콘솔: __kioskAcoustic.params()  /  __kioskAcoustic.session()  /  __kioskAcoustic.profile()
[참고] 크롬 마이크의 자동 음량 조절(AGC)이 켜져 있어서 작은 목소리가 어느 정도 키워진 뒤에 측정됨.
      그래서 실제로는 '작은 목소리' 맞춤보다 '느린 말' 맞춤이 더 자주 쓰일 것으로 예상(파이 실측 필요).

==================================================================
3. 손님 목소리 원본 저장 끔 (개인정보)
==================================================================
  - v8.8까지: 인식할 때마다 kiosk_training_data/audio/*.webm + metadata_raw.csv 저장했음.
  - v8.9: 기본 저장 안 함(폴더도 안 만듦). 꼭 필요할 때만 서비스 파일에 Environment=KIOSK_SAVE_RAW_AUDIO=1
  - 인식용 소리는 메모리에서 처리, 임시 파일이 생기면 인식 끝나고 바로 삭제.
  - 브라우저 저장소(IndexedDB)에도 소리 0개 확인.
  - 예외: /collect (자원봉사자 음성 수집 페이지)는 본인이 직접 녹음해서 보내는 기능이라 그대로
    voice_collection_data 에 저장됨(키오스크 손님 주문과는 별개).
  [이미 저장된 손님 녹음 지우기 — 직접 확인 후 실행]
    ls ~/kiosk_project/kiosk_training_data/audio | wc -l        ← 몇 개 있는지 먼저 확인
    rm -rf ~/kiosk_project/kiosk_training_data/audio ~/kiosk_project/kiosk_training_data/metadata_raw.csv
    (폴더 통째로: rm -rf ~/kiosk_project/kiosk_training_data)

==================================================================
4. 시험 결과 (여기 컴퓨터, 헤드리스 크롬)
==================================================================
  - 기존 회귀 시험(노트북 모드/파이 모드 둘 다): v8.8과 결과 똑같음 → 새로 깨진 것 없음
      test8 31/34 (3개는 시험용 menu.json 설정 문제로 v8.8도 똑같이 실패)
      offline 12/12, nosr 통과, test72 17/18 (v8.8도 같은 1개 실패: '절전 아닐 때 버튼'에 LED:LISTEN),
      led73 통과, v87 STT 12/12, SSE 오류 0, 관리자 화면 통과, e2e 통과
  - 서버 주소(API) 32개 전부 그대로 + 새 주소 3개(/api/acoustic-profile GET·POST·DELETE)
  - 함수 이름 빠진 것 없음(3D 라이브러리 내부 함수는 js/three.min.js로 옮겨짐)
  - 목소리 특징 맞춤 시험 test/test_v89_acoustic.js: 16/16
      보통 손님(크게·빠르게, F0 200Hz, 4.7음절/초) → 기본값 그대로 (0.012 / 750ms / 7초)
      작고 느린 손님(작게, F0 130Hz, 2.1음절/초)  → 0.004 / 1600ms / 10초 로 바뀜
      크롬 가짜 마이크(합성 WAV)로 실제 마이크 경로에서 F0 130Hz 측정, 2.7음절/초 → 끝 쉼 1267ms
      주문 완료 3번 → '소고기국밥' 숫자 학습 → 후보 '순대국밥/소고기국밥'에서 소고기국밥 선택(실제 인식 경로)
      저장 내용 숫자만(193바이트), 서버 사본도 숫자만, IndexedDB 소리 0개, 새로고침 후 유지, 지우기 확인
  - 녹음 저장: v8.9 서버는 kiosk_training_data 폴더 자체를 안 만듦, Whisper는 메모리로 처리 확인

==================================================================
5. 설치 / 확인 / 되돌리기
==================================================================
[버전 확인]  grep -c __V89__ ~/kiosk_project/kiosk.html   → 14 나오면 v8.9

[설치] kiosk_v8_9.zip 을 파이 홈 폴더(~)에 복사 (USB 또는 scp) 후 파이 터미널에서:
  cd ~
  [ -d ~/kiosk_project_backup_v88 ] || cp -r ~/kiosk_project ~/kiosk_project_backup_v88   ← 백업(이미 있으면 그대로 둠)
  unzip -o kiosk_v8_9.zip
  cp -r ~/kiosk_v8_9/* ~/kiosk_project/
  cp ~/kiosk_project_backup_v88/menu.json ~/kiosk_project/menu.json    ← 관리자 화면에서 고친 메뉴 유지
  chmod +x ~/kiosk_project/pi/*.sh
  sudo cp ~/kiosk_project/pi/kiosk-stt.service /etc/systemd/system/kiosk-stt.service
  sudo systemctl daemon-reload
  sudo reboot
  (v8.8을 안 깔았던 파이도 같은 명령이면 됨. 실행기·서비스 파일이 이번에 바뀜)

[확인]
  grep -c __V89__ ~/kiosk_project/kiosk.html                 → 14
  curl -s localhost:8000/                                      → "model_ready":true 면 Whisper 준비 끝
  curl -s localhost:8000/api/acoustic-profile                  → {"v":1,...,"words":{...}} (숫자만)
  ls ~/kiosk_project/kiosk_training_data 2>/dev/null           → 새 녹음 안 생김
  ps aux | grep chrom | grep -o "kiosk?pi=1" | head -1         → 파이 모드로 켜졌는지
  bash ~/kiosk_project/pi/lag_check.sh

[되돌리기 (v8.8로)]
  rm -rf ~/kiosk_project && cp -r ~/kiosk_project_backup_v88 ~/kiosk_project
  sudo cp ~/kiosk_project/pi/kiosk-stt.service /etc/systemd/system/ && sudo systemctl daemon-reload && sudo reboot

[손으로 확인해야 할 것]
- 실제 파이에서의 프레임·CPU는 파이에서만 잴 수 있음(여기는 CPU 6배 느리게 흉내). lag_check.sh 같이 보기.
- 전원(정품 5V 3A), 방열판·팬은 v8.8 README 그대로.
