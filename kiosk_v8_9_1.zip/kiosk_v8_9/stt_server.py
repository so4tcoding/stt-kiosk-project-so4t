#uvicorn stt_server:app --host 0.0.0.0 --port 8000
import asyncio
import os
import csv
import io
import uuid
import time
import shutil
import zipfile
import tempfile
from pathlib import Path
from datetime import datetime
from threading import Lock

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from faster_whisper import WhisperModel


# ============================================================
# 기본 설정
# ============================================================

ADMIN_PASSWORD = "0302"

BASE_DIR = Path(__file__).resolve().parent

KIOSK_HTML = BASE_DIR / "kiosk.html"

COLLECT_DIR = BASE_DIR / "voice_collection_data"
COLLECT_AUDIO_DIR = COLLECT_DIR / "audio"
COLLECT_META_CSV = COLLECT_DIR / "metadata.csv"

COLLECT_AUDIO_DIR.mkdir(parents=True, exist_ok=True)

RAW_DATASET_DIR = BASE_DIR / "kiosk_training_data"
RAW_AUDIO_DIR = RAW_DATASET_DIR / "audio"
RAW_METADATA_CSV = RAW_DATASET_DIR / "metadata_raw.csv"

# [V8.9] __V89__ 손님 목소리 원본(녹음 파일) 저장은 기본으로 끔. 연구용으로 꼭 필요할 때만 서비스 파일에
#   Environment=KIOSK_SAVE_RAW_AUDIO=1  을 넣어야 예전처럼 kiosk_training_data/audio 에 .webm + metadata_raw.csv 저장
SAVE_RAW_AUDIO = os.environ.get("KIOSK_SAVE_RAW_AUDIO", "0").strip() == "1"
if SAVE_RAW_AUDIO:
    RAW_AUDIO_DIR.mkdir(parents=True, exist_ok=True)

MODELS_DIR = BASE_DIR / "models"
ACTIVE_MODEL_DIR = MODELS_DIR / "whisper-kiosk-ct2-int8"

MODELS_DIR.mkdir(parents=True, exist_ok=True)

CPU_THREADS = int(os.environ.get("WHISPER_CPU_THREADS", "3"))  # [V8.4] 파이: 1코어는 크롬/TTS용
BEAM_SIZE = int(os.environ.get("WHISPER_BEAM_SIZE", "1"))  # [V8.4] 파이 기본 1 (예전 값 3은 환경변수로)
try:
    os.nice(int(os.environ.get("KIOSK_SERVER_NICE", "5")))  # [V8.4] 크롬보다 우선순위 살짝 낮춤
except Exception:
    pass

DEFAULT_MODEL_PATH = str(ACTIVE_MODEL_DIR) if ACTIVE_MODEL_DIR.exists() else "base"
MODEL_PATH = os.environ.get("WHISPER_MODEL", DEFAULT_MODEL_PATH)

model_lock = Lock()


# ============================================================
# FastAPI
# ============================================================

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# Whisper Prompt
# ============================================================

INITIAL_PROMPT = (
    "이 음성은 한국어 음식점 키오스크 주문 및 키오스크 조작 명령입니다. "
    "사용자는 메뉴명, 수량, 옵션, 결제 방식, 장소 선택, 화면 제어, 도움 요청을 짧게 말합니다. "

    "메뉴는 돼지국밥, 순대국밥, 소고기국밥, 수육 백반, 한우 불고기, 불고기 덮밥, "
    "치즈버거, 불고기버거, 아메리카노, 카페라떼, 딸기 라떼, 오렌지 주스, "
    "레몬 에이드, 쿠키 쉐이크, 콜라, 사이다, 치즈 케이크, 소프트 아이스크림입니다. "

    "카테고리는 국밥, 불고기, 햄버거, 커피, 음료, 디저트입니다. "

    "자주 나오는 주문 명령은 주문 시작, 메뉴판 보여줘, 추천해줘, 한 개, 두 개, 세 개, "
    "매장, 포장, 카드, 현금, 결제, 추가, 취소, 이전 화면, 처음으로입니다. "

    "화면 제어 명령은 화면 확대, 글씨 크게, 안 보여, 잘 안 보여, 아래 보여줘, 밑에 보여줘, "
    "원래대로, 화면 축소, 확대 해제입니다. "

    "소리 제어 명령은 소리 크게, 안 들려, 잘 안 들려, 소리 작게, 음소거입니다. "

    "도움 요청 표현은 사용법 알려줘, 이게 뭐야, 어떻게 대답하라고, 뭐라고 말하면 돼, "
    "다시 설명해줘, 메뉴 다시 말해줘, 한 번 더 말해줘입니다. "

    "장소 선택은 매장, 여기서 먹을게요, 먹고 갈게요, 포장, 들고 갈게요, 가져갈게요로 인식하세요. "
    "결제 방식은 카드, 신용카드, 체크카드, 현금, 현찰로 인식하세요. "

    "아메리카노를 아니요로 착각하지 마세요. "
    "아니요, 아니야, 아뇨는 부정 표현입니다. "
    "아메리카노, 카페라떼, 치즈 케이크, 소프트 아이스크림은 메뉴명입니다. "

    "치즈 케이크와 소프트 아이스크림은 서로 다른 메뉴입니다. "
    "케이크, 케익, 치즈케익이라고 들리면 치즈 케이크로 인식하세요. "
    "아이스크림, 소프트콘이라고 들리면 소프트 아이스크림으로 인식하세요. "
)


# ============================================================
# 모델 로딩
# ============================================================

COMPUTE_TYPE = os.environ.get("WHISPER_COMPUTE_TYPE", "int8")  # [V8.8] 바꾸고 싶을 때만 환경변수로 (기본 int8 그대로)
WAIT_READY_S = float(os.environ.get("WHISPER_WAIT_READY_S", "25"))  # [V8.8] 모델 준비 전 요청이 기다리는 최대 시간
STALE_S = float(os.environ.get("WHISPER_STALE_S", "20"))  # [V8.8] 차례를 이만큼 넘게 기다린 오래된 음성은 건너뜀


def load_whisper_model(model_path: str):
    print(f"[STT] Loading model: {model_path}")
    print(f"[STT] CPU threads: {CPU_THREADS} / compute_type: {COMPUTE_TYPE}")

    return WhisperModel(
        model_path,
        device="cpu",
        compute_type=COMPUTE_TYPE,
        cpu_threads=CPU_THREADS,
        num_workers=1
    )


# [V8.8] __V88__ 모델을 서버 시작과 동시에 '뒤에서' 불러온다.
#   예전: 모델을 다 불러올 때까지 서버가 아예 응답하지 않아서, 크롬(키오스크 화면)도 그만큼 늦게 떴다.
#   지금: 서버·화면은 바로 뜨고, 모델은 뒤에서 불러온 뒤 짧은 무음으로 한 번 '예열'해서 첫 인식도 빠르게 한다.
#   모델이 준비되기 전에 온 /transcribe 요청은 최대 WHISPER_WAIT_READY_S 초까지 기다린다.
import threading as _v88threading
model = None
MODEL_READY = _v88threading.Event()
MODEL_STATE = {"error": "", "load_s": None, "warmup_s": None}


def _v88_load_in_background():
    global model
    t0 = time.time()
    try:
        m = load_whisper_model(MODEL_PATH)
        model = m
        MODEL_STATE["load_s"] = round(time.time() - t0, 1)
        print(f"[V88] model loaded in {MODEL_STATE['load_s']}s")
        if os.environ.get("WHISPER_WARMUP", "1") != "0":
            t1 = time.time()
            try:
                import numpy as _np
                with model_lock:
                    segs, _info = m.transcribe(_np.zeros(16000, dtype=_np.float32), language="ko", beam_size=1,
                                               without_timestamps=True, condition_on_previous_text=False)
                    list(segs)
                MODEL_STATE["warmup_s"] = round(time.time() - t1, 1)
                print(f"[V88] warm-up done in {MODEL_STATE['warmup_s']}s")
            except Exception as e:
                print(f"[V88] warm-up skipped: {e}")
    except Exception as e:
        MODEL_STATE["error"] = str(e)
        print(f"[V88 MODEL ERROR] {e}")
    finally:
        MODEL_READY.set()


_v88threading.Thread(target=_v88_load_in_background, daemon=True, name="v88-model-load").start()


def reload_whisper_model(model_path: str):
    global model
    global MODEL_PATH

    print(f"[STT] Reloading model: {model_path}")
    new_model = load_whisper_model(model_path)

    MODEL_PATH = model_path
    model = new_model

    print(f"[STT] Model reloaded: {MODEL_PATH}")


# ============================================================
# 공통 유틸
# ============================================================

def check_password(password: str):
    if password != ADMIN_PASSWORD:
        raise HTTPException(status_code=403, detail="wrong password")


def normalize_kiosk_text(text: str) -> str:
    text = (text or "").strip()

    replacements = [
        # 메뉴명 보정
        ("아메리카 너", "아메리카노"),
        ("아메리카 노", "아메리카노"),
        ("아메리가노", "아메리카노"),
        ("아메리카노우", "아메리카노"),

        ("카페 라테", "카페라떼"),
        ("카페 라떼", "카페라떼"),
        ("까페라떼", "카페라떼"),
        ("까페 라떼", "카페라떼"),

        ("돼지 국밥", "돼지국밥"),
        ("순대 국밥", "순대국밥"),
        ("소고기 국밥", "소고기국밥"),

        ("불고기 보거", "불고기버거"),
        ("불고기 버거", "불고기버거"),
        ("치즈 보거", "치즈버거"),
        ("치즈 버거", "치즈버거"),

        ("오랜지", "오렌지"),
        ("쥬스", "주스"),
        ("레모네이드", "레몬 에이드"),
        ("싸이다", "사이다"),

        ("치즈 케익", "치즈 케이크"),
        ("치즈케익", "치즈 케이크"),
        ("치즈 케잌", "치즈 케이크"),
        ("치즈케잌", "치즈 케이크"),

        ("소포트 아이스크림", "소프트 아이스크림"),
        ("소프트콘", "소프트 아이스크림"),

        # 결제어 보정
        ("결재", "결제"),
        ("카도로", "카드로"),
        ("카도", "카드"),
        ("현끔", "현금"),
        ("현찰", "현금"),

        # 화면 제어 보정
        ("원래데로", "원래대로"),
        ("원레대로", "원래대로"),
        ("확대 해재", "확대 해제"),
        ("확대해재", "확대 해제"),
        ("글자 크게", "글씨 크게"),
        ("글씨 키워", "글씨 크게"),
        ("글자 키워", "글씨 크게"),
        ("안보여", "안 보여"),
        ("잘안보여", "잘 안 보여"),

        # 소리 제어 보정
        ("안들려", "안 들려"),
        ("잘안들려", "잘 안 들려"),
        ("소리 키워", "소리 크게"),
        ("소리켜줘", "소리 크게"),
        ("소리 올려", "소리 크게"),
        ("소리 줄여", "소리 작게"),
        ("소리 낮춰", "소리 작게"),

        # 이동/복구 보정
        ("이전으로", "이전 화면"),
        ("뒤로가", "이전 화면"),
        ("뒤로 가", "이전 화면"),
        ("전화면", "이전 화면"),
        ("처음 화면", "처음으로"),
        ("처음부터", "처음으로"),

        # 장소 선택 보정
        ("매장으로", "매장"),
        ("여기서 먹을게", "매장"),
        ("먹고 갈게", "매장"),
        ("먹고갈게", "매장"),
        ("안에서 먹을게", "매장"),

        ("포장해줘", "포장"),
        ("포장할게", "포장"),
        ("들고갈게", "포장"),
        ("들고 갈게", "포장"),
        ("가져갈게", "포장"),
        ("테이크 아웃", "테이크아웃"),

        # 도움말/질문 보정
        ("뭐라고 대답해", "어떻게 대답하라고"),
        ("뭐라고 말해", "뭐라고 말하면 돼"),
        ("어떻게 말해", "뭐라고 말하면 돼"),
        ("다시 말해", "다시 설명해줘"),
        ("한번 더", "한 번 더"),
    ]

    for wrong, right in replacements:
        text = text.replace(wrong, right)

    return text


def is_repeated_hallucination(text: str) -> bool:
    text = (text or "").strip()

    if not text:
        return True

    words = text.split()

    if len(words) >= 8:
        counts = {}

        for word in words:
            counts[word] = counts.get(word, 0) + 1

        max_count = max(counts.values())

        if max_count / len(words) >= 0.7:
            return True

    no_space = text.replace(" ", "")

    repeated_tokens = ["네", "예", "응", "음", "어"]

    for token in repeated_tokens:
        if len(no_space) >= len(token) * 5:
            repeat_count = len(no_space) // len(token)

            if no_space == token * repeat_count:
                return True

    return False


def save_raw_training_sample(audio_bytes: bytes, whisper_text: str) -> str:
    if not SAVE_RAW_AUDIO:   # [V8.9] __V89__ 기본: 아무것도 저장하지 않음 (기능은 남겨 둠)
        return ""
    RAW_AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    sample_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8]

    audio_filename = f"{sample_id}.webm"
    audio_path = RAW_AUDIO_DIR / audio_filename

    with open(audio_path, "wb") as f:
        f.write(audio_bytes)

    is_new_file = not RAW_METADATA_CSV.exists()

    with open(RAW_METADATA_CSV, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "id",
                "audio",
                "whisper_text",
                "correct_text",
                "created_at"
            ]
        )

        if is_new_file:
            writer.writeheader()

        writer.writerow({
            "id": sample_id,
            "audio": str(audio_path.resolve()).replace("\\", "/"),
            "whisper_text": whisper_text or "",
            "correct_text": "",
            "created_at": datetime.now().isoformat(timespec="seconds")
        })

    return sample_id


COLLECT_FIELDNAMES = [
    "id",
    "filename",
    "participant",
    "sentence",
    "intent",
    "menu",
    "quantity",
    "action",
    "domain",
    "condition",
    "dialect",
    "round_index",
    "created_at",
    "user_agent"
]


def ensure_collection_header():
    if not COLLECT_META_CSV.exists():
        with open(COLLECT_META_CSV, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=COLLECT_FIELDNAMES)
            writer.writeheader()
        return

    with open(COLLECT_META_CSV, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        old_fields = reader.fieldnames or []
        rows = list(reader)

    if old_fields == COLLECT_FIELDNAMES:
        return

    migrated_rows = []

    for row in rows:
        migrated = {}

        for field in COLLECT_FIELDNAMES:
            migrated[field] = row.get(field, "")

        if not migrated.get("intent"):
            migrated["intent"] = "UNKNOWN"

        migrated_rows.append(migrated)

    backup_path = COLLECT_META_CSV.with_suffix(".backup.csv")
    shutil.copyfile(COLLECT_META_CSV, backup_path)

    with open(COLLECT_META_CSV, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=COLLECT_FIELDNAMES)
        writer.writeheader()
        writer.writerows(migrated_rows)

    print(f"[COLLECT] metadata migrated. backup={backup_path}")


def append_collection_metadata(row: dict):
    ensure_collection_header()

    with open(COLLECT_META_CSV, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=COLLECT_FIELDNAMES,
            extrasaction="ignore"
        )
        writer.writerow(row)


def find_ct2_model_dir(root: Path) -> Path:
    candidates = []

    for path in root.rglob("model.bin"):
        candidates.append(path.parent)

    if not candidates:
        raise FileNotFoundError(
            "model.bin을 찾을 수 없습니다. 올바른 whisper-kiosk-ct2-int8.zip이 아닙니다."
        )

    return candidates[0]


# ============================================================
# 기본 / 키오스크
# ============================================================

@app.get("/")
def health_check():
    return {
        "status": "ok",
        "model": MODEL_PATH,
        "cpu_threads": CPU_THREADS,
        "model_ready": MODEL_READY.is_set() and model is not None,  # [V8.8]
        "model_error": MODEL_STATE["error"],
        "model_load_s": MODEL_STATE["load_s"],
        "warmup_s": MODEL_STATE["warmup_s"],
    }


@app.get("/kiosk.html")
def serve_kiosk_html():
    if not KIOSK_HTML.exists():
        raise HTTPException(status_code=404, detail="kiosk.html not found")

    return FileResponse(KIOSK_HTML)


@app.get("/kiosk")
def serve_kiosk_alias():
    if not KIOSK_HTML.exists():
        raise HTTPException(status_code=404, detail="kiosk.html not found")

    return FileResponse(KIOSK_HTML)


# [V8.1 추가] kiosk.html이 불러오는 보조 스크립트(kiosk_*.js) 제공
_KIOSK_JS = {"kiosk_talk.js","kiosk_assist.js","kiosk_use_metrics.js","kiosk_customer.js","kiosk_shop.js","kiosk_presbyopia.js","kiosk_pi.js","kiosk_serial_bridge.js","kiosk_pi_perf.js","kiosk_v88.js","kiosk_v89.js","three.min.js","kiosk_acoustic.js"}  # __V89__ three.min.js: 노트북에서만 불러가는 3D 라이브러리(파이 모드는 안 받음)

@app.get("/{js_name}.js")
def serve_kiosk_js(js_name: str):
    name = js_name + ".js"
    if name not in _KIOSK_JS:
        raise HTTPException(status_code=404, detail="not found")
    for d in (BASE_DIR, BASE_DIR / "js"):
        f = d / name
        if f.exists():
            return FileResponse(f, media_type="application/javascript")
    raise HTTPException(status_code=404, detail=name + " not found")


@app.get("/favicon.ico")
def favicon():
    return {"ok": True}


# ============================================================
# STT API
# ============================================================

_v88_alock = None


@app.post("/transcribe")
async def transcribe_audio(request: Request, file: UploadFile = File(...)):
    global _v88_alock
    start_time = time.time()
    if _v88_alock is None:
        _v88_alock = asyncio.Lock()  # [V8.8] 음성 인식은 한 번에 하나씩 차례대로

    suffix = ".webm"

    if file.filename:
        _, ext = os.path.splitext(file.filename)

        if ext:
            suffix = ext

    audio_bytes = await file.read()

    if not audio_bytes:
        return {
            "text": "",
            "error": "empty audio"
        }

    tmp_path = None

    try:
        def _v84_run():
            # [V8.9] __V89__ 소리를 디스크에 쓰지 않고 메모리(BytesIO)에서 바로 인식. 실패하면 임시 파일(끝나면 finally에서 바로 삭제)
            nonlocal tmp_path
            src = io.BytesIO(audio_bytes)
            try:
                return _v84_run_src(src)
            except Exception as mem_err:
                print(f"[V89 STT] 메모리 인식 실패 → 임시 파일 사용: {mem_err}")
                with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                    tmp.write(audio_bytes)
                    tmp_path = tmp.name
                return _v84_run_src(tmp_path)

        def _v84_run_src(audio_src):
            with model_lock:
                segments, info = model.transcribe(
                    audio_src,
                    language="ko",
                    task="transcribe",
                    beam_size=BEAM_SIZE,
                    best_of=max(1, BEAM_SIZE),
                    vad_filter=True,
                    vad_parameters={
                        "min_silence_duration_ms": 500,
                        "speech_pad_ms": 200
                    },
                    initial_prompt=INITIAL_PROMPT,
                    condition_on_previous_text=False,
                    temperature=0.0,
                    compression_ratio_threshold=2.4,
                    log_prob_threshold=-1.0,
                    no_speech_threshold=0.6,
                    without_timestamps=True
                )
                return list(segments), info

        # [V8.8] 모델이 아직 준비 중이면 잠깐 기다림 (화면이 먼저 떠도 안전)
        if not MODEL_READY.is_set():
            await asyncio.to_thread(MODEL_READY.wait, WAIT_READY_S)
        if model is None:
            return {"text": "", "error": "model_loading" if not MODEL_READY.is_set() else ("model_error: " + MODEL_STATE["error"]),
                    "elapsed": round(time.time() - start_time, 3)}

        async with _v88_alock:
            # [V8.8] 차례를 기다리는 동안 화면이 연결을 끊었거나 너무 오래 기다린 음성은 건너뜀(쌓인 요청이 CPU를 계속 잡지 않게)
            waited = time.time() - start_time
            try:
                gone = await request.is_disconnected()
            except Exception:
                gone = False
            if gone or waited > STALE_S:
                why = "client_gone" if gone else "stale"
                print(f"[V88 STT SKIP] {why} waited={round(waited, 1)}s")
                return {"text": "", "filtered": why, "elapsed": round(waited, 3)}
            segments, info = await asyncio.to_thread(_v84_run)  # [V8.4] 이벤트 루프 막지 않음

        text = " ".join([segment.text for segment in segments]).strip()
        text = normalize_kiosk_text(text)

        elapsed = round(time.time() - start_time, 3)

        if is_repeated_hallucination(text):
            print(f"[STT] repeated hallucination ignored: {text} / elapsed={elapsed}s")

            return {
                "text": "",
                "language": info.language,
                "duration": info.duration,
                "elapsed": elapsed,
                "filtered": "repeated_hallucination"
            }

        sample_id = save_raw_training_sample(audio_bytes, text)  # [V8.9] 기본은 저장 안 함("" 반환)

        print(f"[STT] text={text} / elapsed={elapsed}s" + (f" / sample_id={sample_id}" if sample_id else ""))

        return {
            "text": text,
            "language": info.language,
            "duration": info.duration,
            "elapsed": elapsed,
            "sample_id": sample_id
        }

    except Exception as e:
        elapsed = round(time.time() - start_time, 3)

        print(f"[STT ERROR] {str(e)} / elapsed={elapsed}s")

        return {
            "text": "",
            "error": str(e),
            "elapsed": elapsed
        }

    finally:
        if tmp_path:
            try:
                os.remove(tmp_path)
            except Exception:
                pass


# ============================================================
# 수집 앱 HTML
# ============================================================

COLLECT_HTML = r"""
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>키오스크 음성 수집</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{
    font-family:system-ui,"Noto Sans KR",sans-serif;
    background:#f5ead7;
    margin:0;
    padding:18px;
    color:#3f3326;
}
.app{
    max-width:720px;
    margin:auto;
    background:white;
    border-radius:24px;
    padding:22px;
    box-shadow:0 20px 50px #0002;
}
input,button{
    font-size:18px;
    padding:14px;
    border-radius:14px;
    margin:6px 0;
}
input{
    width:100%;
    border:2px solid #d8b98e;
    box-sizing:border-box;
}
button{
    border:0;
    background:#e76f51;
    color:white;
    font-weight:900;
    cursor:pointer;
}
button:disabled{
    opacity:.5;
    cursor:not-allowed;
}
.box{
    background:#fff8ec;
    border-radius:18px;
    padding:16px;
    margin:12px 0;
}
.sentence{
    font-size:30px;
    font-weight:900;
    line-height:1.25;
}
.meta{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
    margin:10px 0;
}
.badge{
    background:#ffe2bd;
    border-radius:999px;
    padding:8px 12px;
    font-weight:900;
    font-size:14px;
}
.condition,.dialect{
    font-size:18px;
    font-weight:800;
    background:#fde7cf;
    border-radius:14px;
    padding:10px;
    margin-top:8px;
}
.dialect{
    background:#e8f3e8;
}
.hidden{
    display:none;
}
audio{
    width:100%;
    margin-top:10px;
}
.small{
    color:#7c6b58;
    font-size:14px;
}
</style>
</head>
<body>
<div class="app">
<h1>키오스크 음성 학습 수집</h1>
<p>주문 문장, 키오스크 기능어, 도움 요청, 일반 대화를 다양하게 수집합니다.</p>

<div id="loginBox" class="box">
<p>비밀번호: 0302</p>
<input id="passwordInput" type="password" placeholder="비밀번호">
<input id="participantInput" placeholder="이름 또는 닉네임">
<button onclick="login()">시작하기</button>
</div>

<div id="taskBox" class="hidden">
<div id="counterText">0개 완료</div>

<div class="box">
<div>읽을 문장</div>
<div class="sentence" id="sentenceText"></div>

<div class="meta">
<span class="badge" id="intentBadge">INTENT</span>
<span class="badge" id="domainBadge">DOMAIN</span>
<span class="badge" id="menuBadge">MENU</span>
<span class="badge" id="quantityBadge">QTY</span>
</div>

<div>말하는 조건</div>
<div class="condition" id="conditionText"></div>

<div>말투/사투리 조건</div>
<div class="dialect" id="dialectText"></div>

<div class="small">
같은 문장은 한 바퀴 동안 다시 나오지 않습니다. 다른 문장을 누르면 다음 고유 문장으로 넘어갑니다.
</div>
</div>

<button onclick="speakPrompt()">문장 읽어주기</button>
<button id="recordBtn" onclick="startRecording()">녹음 시작</button>
<button id="stopBtn" onclick="stopRecording()" disabled>녹음 종료</button>
<audio id="playback" controls class="hidden"></audio>
<br>
<button id="uploadBtn" onclick="uploadRecording()" disabled>서버에 업로드</button>
<button onclick="nextTask()">다른 문장</button>
<div id="statusText">대기 중</div>
</div>
</div>

<script>
const PASSWORD_KEY="kiosk_collect_password";
const PARTICIPANT_KEY="kiosk_collect_participant";

let password="";
let participant="";
let completedCount=0;
let roundIndex=0;

let currentSentence="";
let currentIntent="";
let currentMenu="";
let currentQuantity="";
let currentAction="";
let currentDomain="";
let currentCondition="";
let currentDialect="";

let mediaStream=null;
let recorder=null;
let chunks=[];
let recordedBlob=null;

const REPEAT_PER_SENTENCE = 1;

const menuItems = [
    { name:"돼지국밥", category:"soup" },
    { name:"순대국밥", category:"soup" },
    { name:"소고기국밥", category:"soup" },
    { name:"수육 백반", category:"meal" },
    { name:"한우 불고기", category:"meal" },
    { name:"불고기 덮밥", category:"meal" },

    { name:"치즈버거", category:"burger" },
    { name:"불고기버거", category:"burger" },

    { name:"아메리카노", category:"coffee" },
    { name:"카페라떼", category:"coffee" },
    { name:"딸기 라떼", category:"latte" },

    { name:"오렌지 주스", category:"juice" },
    { name:"레몬 에이드", category:"ade" },
    { name:"쿠키 쉐이크", category:"shake" },
    { name:"콜라", category:"soda" },
    { name:"사이다", category:"soda" },

    { name:"치즈 케이크", category:"dessert" },
    { name:"소프트 아이스크림", category:"icecream" }
];

const quantities = [
    ["한 개", "1"],
    ["하나", "1"],
    ["1개", "1"],
    ["두 개", "2"],
    ["둘", "2"],
    ["2개", "2"],
    ["세 개", "3"],
    ["셋", "3"],
    ["3개", "3"],
    ["네 개", "4"],
    ["4개", "4"],
    ["다섯 개", "5"],
    ["5개", "5"]
];

const highQuantities = [
    ["열 개", "10"],
    ["10개", "10"],
    ["50개", "50"],
    ["99개", "99"]
];

const orderTemplates = [
    "{menu} {qty} 주세요",
    "{menu} {qty} 주문할게요",
    "{menu} {qty} 담아 주세요",
    "{menu} {qty} 추가해 주세요",
    "{menu} {qty} 시킬게요",
    "{menu} {qty} 할게요",
    "{menu} {qty} 부탁해요",
    "{menu} {qty} 넣어 주세요"
];

const shortOrderTemplates = [
    "{menu} 주세요",
    "{menu} 추가",
    "{menu} 할게요",
    "{menu} 주문할게요",
    "{menu} 부탁해요"
];

const singleMenuTemplates = [
    "{menu}",
    "{menu}요",
    "{menu} 할게요"
];

const soupMealOptionTemplates = [
    "{menu} 포장해 주세요",
    "{menu} 매장에서 먹을게요",
    "{menu} 덜 맵게 해 주세요",
    "{menu} 맵게 해 주세요",
    "{menu} 밥 적게 주세요",
    "{menu} 밥 많이 주세요",
    "{menu} 국물 많이 주세요"
];

const burgerOptionTemplates = [
    "{menu} 세트로 주세요",
    "{menu} 단품으로 주세요",
    "{menu} 피클 빼 주세요",
    "{menu} 소스 빼 주세요",
    "{menu} 치즈 추가해 주세요",
    "{menu} 양상추 빼 주세요",
    "{menu} 포장해 주세요",
    "{menu} 매장에서 먹을게요"
];

const coffeeOptionTemplates = [
    "{menu} 아이스로 주세요",
    "{menu} 따뜻하게 주세요",
    "{menu} 샷 추가해 주세요",
    "{menu} 시럽 추가해 주세요",
    "{menu} 시럽 빼 주세요",
    "{menu} 200ml로 주세요",
    "{menu} 350ml로 주세요",
    "{menu} 500ml로 주세요",
    "{menu} 얼음 적게 해 주세요",
    "{menu} 얼음 많이 해 주세요",
    "{menu} 연하게 해 주세요",
    "{menu} 진하게 해 주세요"
];

const latteOptionTemplates = [
    "{menu} 아이스로 주세요",
    "{menu} 따뜻하게 주세요",
    "{menu} 샷 추가해 주세요",
    "{menu} 시럽 추가해 주세요",
    "{menu} 시럽 빼 주세요",
    "{menu} 200ml로 주세요",
    "{menu} 350ml로 주세요",
    "{menu} 500ml로 주세요",
    "{menu} 얼음 적게 해 주세요",
    "{menu} 얼음 많이 해 주세요"
];

const coldDrinkOptionTemplates = [
    "{menu} 얼음 적게 해 주세요",
    "{menu} 얼음 많이 해 주세요",
    "{menu} 200ml로 주세요",
    "{menu} 350ml로 주세요",
    "{menu} 500ml로 주세요",
    "{menu} 당도 낮게 해 주세요",
    "{menu} 당도 보통으로 해 주세요",
    "{menu} 당도 높게 해 주세요"
];

const pearlDrinkOptionTemplates = [
    "{menu} 펄 추가해 주세요",
    "{menu} 펄 빼 주세요"
];

const sodaOptionTemplates = [
    "{menu} 얼음 적게 주세요",
    "{menu} 얼음 많이 주세요",
    "{menu} 라지로 주세요",
    "{menu} 미디엄으로 주세요",
    "{menu} 포장해 주세요"
];

const dessertOptionTemplates = [
    "{menu} 포장해 주세요",
    "{menu} 매장에서 먹을게요"
];

const icecreamOptionTemplates = [
    "{menu} 하나 주세요",
    "{menu} 두 개 주세요",
    "{menu} 포장해 주세요",
    "{menu} 컵으로 주세요",
    "{menu} 콘으로 주세요"
];

const modifyTemplates = [
    "{menu} 빼 주세요",
    "{menu} 취소해 주세요",
    "{menu} 하나 더 추가해 주세요",
    "{menu} 두 개로 바꿔 주세요",
    "{menu} 말고 다른 걸로 할게요"
];

const paySentences = [
    "결제할게요",
    "카드로 결제할게요",
    "현금으로 계산할게요",
    "현금으로 결제할게요",
    "주문 완료할게요",
    "이대로 결제해 주세요",
    "계산할게요"
];

const cancelSentences = [
    "주문 취소해 주세요",
    "전체 취소해 주세요",
    "다시 주문할게요",
    "처음부터 다시 할게요",
    "방금 주문 취소해 주세요"
];

const navigationSentences = [
    "주문 시작",
    "바로 주문",
    "주문할게요",
    "이전 화면",
    "이전으로",
    "뒤로",
    "뒤로 가",
    "처음으로",
    "처음 화면",
    "처음부터 다시",
    "국밥 보여줘",
    "불고기 보여줘",
    "햄버거 메뉴 보여줘",
    "커피 메뉴 보여줘",
    "음료 보여줘",
    "디저트 보여줘",
    "화면 확대",
    "글씨 크게",
    "안 보여",
    "아래 보여줘",
    "원래대로",
    "소리 크게",
    "안 들려",
    "소리 작게",
    "사용법 알려줘",
    "메뉴 다시 말해줘",
    "이게 뭐야",
    "네",
    "예",
    "맞아",
    "이대로",
    "아니요",
    "아니야",
    "다시"
];

const categoryCommandSentences = [
    "국밥",
    "국밥 보여줘",
    "국밥 메뉴 보여줘",
    "불고기",
    "불고기 보여줘",
    "불고기 메뉴 보여줘",
    "햄버거",
    "햄버거 보여줘",
    "햄버거 메뉴 보여줘",
    "커피",
    "커피 보여줘",
    "커피 메뉴 보여줘",
    "음료",
    "음료 보여줘",
    "음료 메뉴 보여줘",
    "디저트",
    "디저트 보여줘",
    "디저트 메뉴 보여줘",
    "메뉴판",
    "메뉴판 보여줘",
    "메뉴 보여줘",
    "메뉴 알려줘",
    "뭐 있어요",
    "뭐가 있어요",
    "음식 뭐 있어요",
    "주문할 메뉴 보여줘"
];

const placeSentences = [
    "매장",
    "매장에서",
    "매장에서 먹을게요",
    "여기서 먹을게요",
    "여기서 먹고 갈게요",
    "먹고 갈게요",
    "안에서 먹을게요",
    "포장",
    "포장해 주세요",
    "포장할게요",
    "들고 갈게요",
    "가져갈게요",
    "밖에서 먹을게요",
    "테이크아웃",
    "테이크아웃 할게요"
];

const paymentWordSentences = [
    "결제",
    "결제할게요",
    "계산",
    "계산할게요",
    "이대로 결제",
    "주문 완료",
    "주문 끝",
    "카드",
    "카드로",
    "카드로 결제",
    "신용카드",
    "체크카드",
    "카드 결제할게요",
    "현금",
    "현금으로",
    "현금으로 결제",
    "현찰",
    "돈으로 낼게요"
];

const screenCommandSentences = [
    "화면 확대",
    "화면 확대해줘",
    "글씨 크게",
    "글씨 크게 해줘",
    "글자 크게",
    "글자 크게 해줘",
    "안 보여",
    "잘 안 보여",
    "글씨가 안 보여",
    "메뉴가 안 보여",
    "돋보기",
    "돋보기 켜줘",
    "더 크게 보여줘",
    "아래 보여줘",
    "밑에 보여줘",
    "밑에 안 보여",
    "아래가 안 보여",
    "아랫부분 보여줘",
    "더 아래 보여줘",
    "위로 올려줘",
    "위쪽 보여줘",
    "처음 부분 보여줘",
    "원래대로",
    "화면 원래대로",
    "화면 확대 해제",
    "확대 해제",
    "화면 축소",
    "작게 해줘",
    "글씨 작게",
    "줄여줘"
];

const volumeCommandSentences = [
    "소리 크게",
    "소리 크게 해줘",
    "소리 키워줘",
    "소리 올려줘",
    "잘 안 들려",
    "안 들려",
    "목소리가 작아",
    "더 크게 말해줘",
    "소리 작게",
    "소리 줄여줘",
    "소리 낮춰줘",
    "너무 시끄러워",
    "목소리가 너무 커",
    "음소거",
    "소리 꺼줘",
    "소리 켜줘",
    "음소거 해제"
];

const navigationMoreSentences = [
    "이전",
    "이전 화면",
    "이전으로",
    "뒤로",
    "뒤로 가",
    "뒤로가기",
    "전화면",
    "전 화면",
    "한 단계 전으로",
    "처음",
    "처음으로",
    "처음 화면",
    "처음부터",
    "다시 시작",
    "처음부터 다시 할게요",
    "취소",
    "그만",
    "안 할래요",
    "주문 취소",
    "전체 취소",
    "다시 주문할게요"
];

const repeatGuideSentences = [
    "메뉴 다시 말해줘",
    "메뉴 다시 읽어줘",
    "메뉴판 다시 말해줘",
    "메뉴판 다시 읽어줘",
    "한 번 더 말해줘",
    "다시 말해줘",
    "다시 설명해줘",
    "천천히 말해줘",
    "방금 뭐라고 했어",
    "다시 알려줘"
];

const helpQuestionSentences = [
    "사용법 알려줘",
    "키오스크 사용법 알려줘",
    "키오스크 사용 방식 알려줘",
    "주문 방법 알려줘",
    "어떻게 주문해",
    "어떻게 사용해",
    "처음이라 모르겠어",
    "잘 모르겠어",
    "뭘 해야 돼",
    "뭘 말해야 돼",
    "뭐라고 말하면 돼",
    "어떻게 대답하라고",
    "어떻게 대답해야 돼",
    "여기서 뭐라고 해야 돼",
    "이게 뭐야",
    "이 버튼 뭐야",
    "마이크가 뭐야",
    "장바구니가 뭐야",
    "결제는 어떻게 해",
    "수량은 어떻게 말해",
    "옵션은 어떻게 골라",
    "컵 용량은 뭐야",
    "매장 포장 뭐야",
    "매장하고 포장 중에 뭐라고 해",
    "여기서 먹는 건 뭐라고 말해",
    "들고 가는 건 뭐라고 말해",
    "카드 현금 뭐라고 말해",
    "카드로 하려면 뭐라고 해",
    "현금으로 하려면 뭐라고 해",
    "추천해줘",
    "아무거나 추천해줘",
    "뭐 먹을지 모르겠어",
    "뭐가 맛있어",
    "인기 메뉴 알려줘"
];

const standaloneOptionSentences = [
    "밥",
    "밥 적게",
    "밥 많이",
    "밥 보통",
    "국물 많이",
    "국물 적게",
    "맵게",
    "덜 맵게",
    "순하게",
    "얼큰하게",
    "채소",
    "채소 빼기",
    "채소 많이",
    "피클",
    "피클 빼기",
    "피클 많이",
    "소스",
    "소스 적게",
    "소스 많이",
    "치즈 추가",
    "양파 빼기",
    "토마토 빼기",
    "아이스",
    "차갑게",
    "따뜻하게",
    "핫",
    "얼음",
    "얼음 적게",
    "얼음 많이",
    "얼음 빼기",
    "샷",
    "샷 추가",
    "시럽",
    "시럽 적게",
    "시럽 많이",
    "당도",
    "당도 낮게",
    "당도 높게",
    "휘핑",
    "휘핑 많이",
    "펄",
    "펄 추가",
    "크럼블",
    "크럼블 추가",
    "200ml",
    "이백 밀리리터",
    "350ml",
    "삼백오십 밀리리터",
    "500ml",
    "오백 밀리리터",
    "스몰",
    "미디엄",
    "라지"
];

const positionSelectSentences = [
    "왼쪽",
    "오른쪽",
    "왼쪽 거",
    "오른쪽 거",
    "위에 왼쪽",
    "위에 오른쪽",
    "아래 왼쪽",
    "아래 오른쪽",
    "밑에서 왼쪽",
    "밑에서 오른쪽",
    "첫 번째",
    "두 번째",
    "세 번째",
    "네 번째",
    "1번",
    "2번",
    "3번",
    "4번",
    "마지막",
    "맨 아래",
    "끝에 있는 거"
];

const yesNoSentences = [
    "네",
    "예",
    "넵",
    "옙",
    "맞아",
    "맞습니다",
    "이대로",
    "아니요",
    "아니야",
    "아뇨",
    "틀려",
    "다시",
    "다시 고를게요"
];

const kioskRelatedQuestionSentences = [
    "이 메뉴 무슨 맛이야",
    "이 메뉴 설명해줘",
    "이 메뉴 특징 알려줘",
    "아메리카노 무슨 맛이야",
    "돼지국밥 무슨 맛이야",
    "치즈 케이크 설명해줘",
    "이백 밀리리터가 얼마나 돼",
    "삼백오십 밀리리터가 얼마나 돼",
    "오백 밀리리터가 얼마나 돼"
];

const ignoreSentences = [
    "너 국밥 먹을래",
    "너 뭐 먹을래",
    "엄마 나 뭐 먹지",
    "야 이거 되는 거 맞아",
    "이거 녹음 되고 있냐",
    "마이크 켜졌어",
    "잠깐만 기다려 봐",
    "나 아직 못 정했어",
    "오늘 학교 끝나고 뭐 해",
    "이따가 피시방 갈래",
    "이거 말하면 되는 거야",
    "아니 너 먼저 골라",
    "나는 배 안 고파",
    "아까 먹은 거 또 먹을래",
    "국밥집 갈래",
    "편의점 갈까",
    "집에 가서 먹자",
    "여기 사람 많다",
    "뒤에 사람 기다린다",
    "빨리 골라",
    "이거 카메라 찍히는 거야",
    "소리 너무 작지 않아",
    "내 말 들려",
    "이거 테스트야",
    "아무 말이나 해 봐",
    "너 오늘 뭐 했어",
    "점심 뭐 먹었어",
    "이 메뉴 맛있나",
    "사진 찍지 마",
    "장난치지 마",
    "여기 말고 다른 데 가자",
    "아직 고르는 중이야",
    "나한테 물어보지 마"
];

const extraIgnoreSentences = [
    "나 키오스크 잘 못해",
    "키오스크 어렵다",
    "키오스크 무섭다",
    "뒤에 사람 많다",
    "나중에 주문할게",
    "아직 고르는 중이야",
    "뭐 먹을지 생각 중이야",
    "이거 말하면 주문되는 거야",
    "아직 말하지 마",
    "이 메뉴 맛있어 보여",
    "저 사람 먼저 해도 돼",
    "직원 불러야 하나",
    "어디를 눌러야 하는지 모르겠다"
];

const contextIgnoreTemplates = [
    "너 {menu} 먹을래",
    "나는 {menu} 별로야",
    "{menu} 맛있어 보여",
    "{menu} 먹으러 갈까",
    "어제 {menu} 먹었어",
    "{menu} 말고 다른 데 가자",
    "너는 {menu} 좋아해",
    "집에 {menu} 있어",
    "{menu} 생각난다",
    "{menu} 먹고 싶긴 한데 여기서는 말고",
    "나중에 {menu} 먹자",
    "{menu}는 어제 먹었잖아"
];

const conditions=[
    "평소 목소리로 말하세요.",
    "저음으로 낮게 말하세요.",
    "고음으로 높게 말하세요.",
    "천천히 또박또박 말하세요.",
    "조금 빠르게 말하세요.",
    "작은 목소리로 말하세요.",
    "큰 목소리로 말하세요.",
    "마이크에서 조금 멀리 떨어져 말하세요.",
    "마이크 가까이에서 말하세요.",
    "고개를 왼쪽으로 돌리고 말하세요.",
    "고개를 오른쪽으로 돌리고 말하세요.",
    "피곤한 목소리로 말하세요.",
    "어르신처럼 천천히 말하세요.",
    "의자에 기대서 말하세요."
];

const dialects=[
    "표준어로 말하세요.",
    "경상도 느낌으로 말하세요. 예: 주이소, 맞다, 아이다.",
    "전라도 느낌으로 말하세요. 예: 줘잉, 맞당께, 아니랑께.",
    "충청도 느낌으로 말하세요. 예: 줘유, 맞아유, 아녀유.",
    "어르신 말투로 말하세요.",
    "친구에게 말하듯 자연스럽게 말하세요.",
    "키오스크 앞에서 주문하듯 말하세요.",
    "단어를 또박또박 끊어서 말하세요."
];

function fillTemplate(template, menu, qtyText){
    return template
        .replaceAll("{menu}", menu)
        .replaceAll("{qty}", qtyText || "");
}

function getAllowedOptionTemplates(category){
    if(category === "soup" || category === "meal"){
        return soupMealOptionTemplates;
    }

    if(category === "burger"){
        return burgerOptionTemplates;
    }

    if(category === "coffee"){
        return coffeeOptionTemplates;
    }

    if(category === "latte"){
        return latteOptionTemplates;
    }

    if(category === "juice" || category === "ade" || category === "shake"){
        return coldDrinkOptionTemplates;
    }

    if(category === "soda"){
        return sodaOptionTemplates;
    }

    if(category === "dessert"){
        return dessertOptionTemplates;
    }

    if(category === "icecream"){
        return icecreamOptionTemplates;
    }

    return [];
}

function canUsePearl(category){
    return category === "latte" || category === "ade" || category === "shake";
}

function canUseHighQuantity(category){
    return category === "soda" || category === "dessert" || category === "icecream";
}

function buildPromptBank(){
    const rows=[];
    const seen=new Set();

    function add(sentence, intent, menu="", quantity="", action="", domain="kiosk"){
        sentence=String(sentence).replace(/\s+/g," ").trim();

        if(!sentence) return;

        const key=sentence + "||" + intent;

        if(seen.has(key)) return;

        seen.add(key);

        rows.push({
            sentence,
            intent,
            menu,
            quantity,
            action,
            domain
        });
    }

    for(const item of menuItems){
        const menu = item.name;
        const category = item.category;

        let quantityList = [...quantities];

        if(canUseHighQuantity(category)){
            quantityList = quantityList.concat(highQuantities);
        }

        for(const [qtyText, qtyNum] of quantityList){
            for(const template of orderTemplates){
                add(fillTemplate(template, menu, qtyText), "ORDER", menu, qtyNum, "add", "kiosk");
            }
        }

        for(const template of shortOrderTemplates){
            add(fillTemplate(template, menu, ""), "ORDER", menu, "", "add", "kiosk");
        }

        for(const template of singleMenuTemplates){
            add(fillTemplate(template, menu, ""), "ORDER", menu, "", "select", "kiosk");
        }

        const allowedOptions = getAllowedOptionTemplates(category);

        for(const template of allowedOptions){
            add(fillTemplate(template, menu, ""), "ORDER", menu, "", "option", "kiosk");
        }

        if(canUsePearl(category)){
            for(const template of pearlDrinkOptionTemplates){
                add(fillTemplate(template, menu, ""), "ORDER", menu, "", "option", "kiosk");
            }
        }

        for(const template of modifyTemplates){
            add(fillTemplate(template, menu, ""), "MODIFY", menu, "", "modify", "kiosk");
        }
    }

    for(const sentence of categoryCommandSentences){
        add(sentence, "CONTROL", "", "", "category_or_menu_board", "kiosk");
    }

    for(const sentence of placeSentences){
        add(sentence, "CONTROL", "", "", "place", "kiosk");
    }

    for(const sentence of paymentWordSentences){
        add(sentence, "PAY", "", "", "pay", "kiosk");
    }

    for(const sentence of screenCommandSentences){
        add(sentence, "CONTROL", "", "", "screen", "kiosk");
    }

    for(const sentence of volumeCommandSentences){
        add(sentence, "CONTROL", "", "", "volume", "kiosk");
    }

    for(const sentence of navigationMoreSentences){
        add(sentence, "CONTROL", "", "", "navigation", "kiosk");
    }

    for(const sentence of repeatGuideSentences){
        add(sentence, "CONTROL", "", "", "repeat_guide", "kiosk");
    }

    for(const sentence of helpQuestionSentences){
        add(sentence, "CONTROL", "", "", "help", "kiosk");
    }

    for(const sentence of standaloneOptionSentences){
        add(sentence, "CONTROL", "", "", "option_word", "kiosk");
    }

    for(const sentence of positionSelectSentences){
        add(sentence, "CONTROL", "", "", "position_select", "kiosk");
    }

    for(const sentence of yesNoSentences){
        add(sentence, "CONTROL", "", "", "yes_no", "kiosk");
    }

    for(const sentence of kioskRelatedQuestionSentences){
        add(sentence, "CONTROL", "", "", "kiosk_question", "kiosk");
    }

    for(const sentence of paySentences){
        add(sentence, "PAY", "", "", "pay", "kiosk");
    }

    for(const sentence of cancelSentences){
        add(sentence, "CANCEL", "", "", "cancel", "kiosk");
    }

    for(const sentence of navigationSentences){
        add(sentence, "CONTROL", "", "", "control", "kiosk");
    }

    for(const sentence of ignoreSentences){
        add(sentence, "IGNORE", "", "", "", "non_kiosk");
    }

    for(const sentence of extraIgnoreSentences){
        add(sentence, "IGNORE", "", "", "", "non_kiosk");
    }

    for(const item of menuItems){
        const menu = item.name;

        for(const template of contextIgnoreTemplates){
            add(fillTemplate(template, menu, ""), "IGNORE", menu, "", "", "non_kiosk");
        }
    }

    return rows;
}

function hashString(str){
    let h=2166136261;

    for(let i=0;i<str.length;i++){
        h^=str.charCodeAt(i);
        h+=(h<<1)+(h<<4)+(h<<7)+(h<<8)+(h<<24);
    }

    return Math.abs(h>>>0);
}

function seededRandom(seed){
    let t=seed+0x6D2B79F5;

    return function(){
        t+=0x6D2B79F5;
        let r=Math.imul(t^(t>>>15),1|t);
        r^=r+Math.imul(r^(r>>>7),61|r);
        return ((r^(r>>>14))>>>0)/4294967296;
    };
}

function shuffledCopy(arr, seedText){
    const copy=[...arr];
    const rand=seededRandom(hashString(seedText));

    for(let i=copy.length-1;i>0;i--){
        const j=Math.floor(rand()*(i+1));
        [copy[i],copy[j]]=[copy[j],copy[i]];
    }

    return copy;
}

let PROMPT_BANK=[];
let PROMPT_ORDER=[];

function rebuildPromptOrder(){
    PROMPT_BANK=buildPromptBank();
    PROMPT_ORDER=shuffledCopy(PROMPT_BANK, participant || "default");
}

function getTotalTasks(){
    return PROMPT_BANK.length * REPEAT_PER_SENTENCE;
}

function buildTaskByIndex(index){
    if(PROMPT_ORDER.length===0){
        rebuildPromptOrder();
    }

    const zero=index-1;
    const promptIndex=zero % PROMPT_ORDER.length;
    const repeatCycle=Math.floor(zero / PROMPT_ORDER.length);

    if(repeatCycle >= REPEAT_PER_SENTENCE){
        return null;
    }

    const prompt=PROMPT_ORDER[promptIndex];

    const conditionIndex=(promptIndex + repeatCycle) % conditions.length;
    const dialectIndex=(promptIndex * 3 + repeatCycle) % dialects.length;

    return {
        sentence: prompt.sentence,
        intent: prompt.intent,
        menu: prompt.menu,
        quantity: prompt.quantity,
        action: prompt.action,
        domain: prompt.domain,
        condition: conditions[conditionIndex],
        dialect: dialects[dialectIndex]
    };
}

function saveLocalProgress(){
    localStorage.setItem("kiosk_collect_completed_"+participant,String(completedCount));
}

function loadLocalProgress(){
    const v=localStorage.getItem("kiosk_collect_completed_"+participant);
    const n=parseInt(v||"0",10);
    return Number.isNaN(n)?0:n;
}

async function login(){
    password=document.getElementById("passwordInput").value.trim();
    participant=document.getElementById("participantInput").value.trim();

    if(password!=="0302"){
        alert("비밀번호가 틀렸습니다.");
        return;
    }

    if(!participant){
        alert("이름 또는 닉네임을 입력하세요.");
        return;
    }

    localStorage.setItem(PASSWORD_KEY,password);
    localStorage.setItem(PARTICIPANT_KEY,participant);

    rebuildPromptOrder();

    try{
        const res=await fetch(`/api/progress?password=$${encodeURIComponent(password)}&participant=$${encodeURIComponent(participant)}`);

        if(res.ok){
            const data=await res.json();
            completedCount=Number(data.completed||0);
        }else{
            completedCount=loadLocalProgress();
        }
    }catch(e){
        completedCount=loadLocalProgress();
    }

    roundIndex=completedCount+1;

    document.getElementById("loginBox").classList.add("hidden");
    document.getElementById("taskBox").classList.remove("hidden");

    showTask(roundIndex);
}

function showTask(index){
    const totalTasks=getTotalTasks();

    if(index>totalTasks){
        document.getElementById("sentenceText").textContent="모든 녹음이 완료되었습니다.";
        document.getElementById("conditionText").textContent="수고하셨습니다.";
        document.getElementById("dialectText").textContent="종료해도 됩니다.";
        document.getElementById("counterText").textContent=`${totalTasks}개 완료`;
        return;
    }

    const task=buildTaskByIndex(index);

    if(!task){
        document.getElementById("sentenceText").textContent="모든 녹음이 완료되었습니다.";
        document.getElementById("conditionText").textContent="수고하셨습니다.";
        document.getElementById("dialectText").textContent="종료해도 됩니다.";
        document.getElementById("counterText").textContent=`${totalTasks}개 완료`;
        return;
    }

    currentSentence=task.sentence;
    currentIntent=task.intent;
    currentMenu=task.menu;
    currentQuantity=task.quantity;
    currentAction=task.action;
    currentDomain=task.domain;
    currentCondition=task.condition;
    currentDialect=task.dialect;
    roundIndex=index;

    recordedBlob=null;
    chunks=[];

    document.getElementById("sentenceText").textContent=currentSentence;
    document.getElementById("intentBadge").textContent=currentIntent || "UNKNOWN";
    document.getElementById("domainBadge").textContent=currentDomain || "";
    document.getElementById("menuBadge").textContent=currentMenu || "";
    document.getElementById("quantityBadge").textContent=currentQuantity ? ("수량 " + currentQuantity) : "";

    document.getElementById("conditionText").textContent=currentCondition;
    document.getElementById("dialectText").textContent=currentDialect;

    document.getElementById("counterText").textContent=`$${completedCount}개 완료 / 전체 $${totalTasks}개`;
    document.getElementById("statusText").textContent=`${roundIndex}번째 문장입니다.`;

    document.getElementById("recordBtn").disabled=false;
    document.getElementById("stopBtn").disabled=true;
    document.getElementById("uploadBtn").disabled=true;

    const playback=document.getElementById("playback");
    playback.classList.add("hidden");
    playback.src="";

    speakPrompt();
}

function nextTask(){
    showTask(roundIndex+1);
}

function speakPrompt(){
    const text=`읽을 문장입니다. $${currentSentence}. 조건입니다. $${currentCondition}. 말투 조건입니다. ${currentDialect}`;
    const u=new SpeechSynthesisUtterance(text);

    u.lang="ko-KR";
    u.rate=0.95;

    speechSynthesis.cancel();
    speechSynthesis.speak(u);
}

async function startRecording(){
    try{
        chunks=[];
        recordedBlob=null;

        mediaStream=await navigator.mediaDevices.getUserMedia({
            audio:{
                echoCancellation:true,
                noiseSuppression:true,
                autoGainControl:true
            }
        });

        let mimeType="";
        const candidates=[
            "audio/webm;codecs=opus",
            "audio/webm",
            "audio/mp4",
            "audio/aac"
        ];

        for(const c of candidates){
            if(MediaRecorder.isTypeSupported(c)){
                mimeType=c;
                break;
            }
        }

        recorder=mimeType ? new MediaRecorder(mediaStream,{mimeType}) : new MediaRecorder(mediaStream);

        recorder.ondataavailable=e=>{
            if(e.data&&e.data.size>0){
                chunks.push(e.data);
            }
        };

        recorder.onstop=()=>{
            recordedBlob=new Blob(chunks,{type:mimeType||"audio/webm"});

            const playback=document.getElementById("playback");
            playback.src=URL.createObjectURL(recordedBlob);
            playback.classList.remove("hidden");

            document.getElementById("uploadBtn").disabled=false;
            document.getElementById("statusText").textContent="녹음 완료. 확인 후 업로드하세요.";

            if(mediaStream){
                mediaStream.getTracks().forEach(t=>t.stop());
            }
        };

        recorder.start();

        document.getElementById("recordBtn").disabled=true;
        document.getElementById("stopBtn").disabled=false;
        document.getElementById("statusText").textContent="녹음 중입니다.";
    }catch(e){
        console.error(e);
        alert("마이크 권한을 허용해주세요.");
    }
}

function stopRecording(){
    if(recorder&&recorder.state==="recording"){
        recorder.stop();
    }

    document.getElementById("recordBtn").disabled=false;
    document.getElementById("stopBtn").disabled=true;
}

async function uploadRecording(){
    if(!recordedBlob){
        alert("녹음 파일이 없습니다.");
        return;
    }

    const formData=new FormData();

    formData.append("password",password);
    formData.append("participant",participant);
    formData.append("sentence",currentSentence);
    formData.append("intent",currentIntent);
    formData.append("menu",currentMenu);
    formData.append("quantity",currentQuantity);
    formData.append("action",currentAction);
    formData.append("domain",currentDomain);
    formData.append("condition",currentCondition);
    formData.append("dialect",currentDialect);
    formData.append("round_index",String(roundIndex));
    formData.append("file",recordedBlob,`recording_${Date.now()}.webm`);

    document.getElementById("statusText").textContent="업로드 중...";

    const res=await fetch("/api/upload",{
        method:"POST",
        body:formData
    });

    if(!res.ok){
        const txt=await res.text();
        console.error(txt);
        alert("업로드 실패");
        document.getElementById("statusText").textContent="업로드 실패";
        return;
    }

    const data=await res.json();

    completedCount=roundIndex;
    saveLocalProgress();

    document.getElementById("statusText").textContent=`업로드 완료: ${data.id}`;

    setTimeout(()=>{
        showTask(roundIndex+1);
    },800);
}

window.addEventListener("load",()=>{
    document.getElementById("passwordInput").value=localStorage.getItem(PASSWORD_KEY)||"";
    document.getElementById("participantInput").value=localStorage.getItem(PARTICIPANT_KEY)||"";
});
</script>
</body>
</html>
"""


# ============================================================
# 관리자 HTML
# ============================================================

COLLECT_ADMIN_HTML = r"""
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>키오스크 음성 수집 관리자</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{
    font-family:system-ui,"Noto Sans KR",sans-serif;
    background:#f5ead7;
    padding:24px;
    color:#3f3326;
}
.wrap{
    max-width:1200px;
    margin:auto;
    background:white;
    border-radius:24px;
    padding:24px;
}
input{
    padding:12px;
    font-size:16px;
    border-radius:12px;
    border:2px solid #d8b98e;
}
button,a.btn{
    display:inline-block;
    border:0;
    background:#e76f51;
    color:white;
    font-weight:900;
    padding:12px 16px;
    border-radius:999px;
    text-decoration:none;
    cursor:pointer;
    margin:4px;
}
table{
    border-collapse:collapse;
    width:100%;
    margin-top:18px;
    font-size:13px;
}
th,td{
    border-bottom:1px solid #eee;
    padding:8px;
    text-align:left;
    vertical-align:top;
}
th{
    background:#fff4df;
}
</style>
</head>
<body>
<div class="wrap">
<h1>키오스크 음성 수집 관리자</h1>
<input id="pw" type="password" placeholder="비밀번호">
<button onclick="loadList()">목록 보기</button>
<button onclick="downloadZip()">전체 ZIP 다운로드</button>
<div id="summary"></div>
<table>
<thead>
<tr>
<th>ID</th>
<th>참여자</th>
<th>문장</th>
<th>Intent</th>
<th>Menu</th>
<th>Qty</th>
<th>Action</th>
<th>Domain</th>
<th>조건</th>
<th>사투리</th>
<th>Round</th>
<th>시간</th>
<th>파일</th>
</tr>
</thead>
<tbody id="tbody"></tbody>
</table>
</div>

<script>
function getPw(){
    return document.getElementById("pw").value.trim();
}

async function loadList(){
    const pw=getPw();
    const res=await fetch(`/api/list?password=${encodeURIComponent(pw)}`);

    if(!res.ok){
        alert("비밀번호가 틀렸거나 오류입니다.");
        return;
    }

    const data=await res.json();

    document.getElementById("summary").innerHTML=`<h3>총 ${data.count}개</h3>`;

    const tbody=document.getElementById("tbody");
    tbody.innerHTML="";

    for(const row of data.rows.reverse()){
        const filename=(row.filename||"").split("/").pop().split("\\\\").pop();

        const tr=document.createElement("tr");

        tr.innerHTML=`
<td>${row.id||""}</td>
<td>${row.participant||""}</td>
<td>${row.sentence||""}</td>
<td>${row.intent||""}</td>
<td>${row.menu||""}</td>
<td>${row.quantity||""}</td>
<td>${row.action||""}</td>
<td>${row.domain||""}</td>
<td>${row.condition||""}</td>
<td>${row.dialect||""}</td>
<td>${row.round_index||""}</td>
<td>${row.created_at||""}</td>
<td><a class="btn" href="/download/audio/$${filename}?password=$${encodeURIComponent(pw)}">다운</a></td>
`;

        tbody.appendChild(tr);
    }
}

function downloadZip(){
    const pw=getPw();

    if(!pw){
        alert("비밀번호를 입력하세요.");
        return;
    }

    location.href=`/download/all.zip?password=${encodeURIComponent(pw)}`;
}
</script>
</body>
</html>
"""


# ============================================================
# 수집 앱 API
# ============================================================

@app.get("/collect", response_class=HTMLResponse)
def collect_index():
    return HTMLResponse(COLLECT_HTML)


@app.get("/collect/", response_class=HTMLResponse)
def collect_index_slash():
    return HTMLResponse(COLLECT_HTML)


@app.get("/collect/admin", response_class=HTMLResponse)
def collect_admin():
    return HTMLResponse(COLLECT_ADMIN_HTML)


@app.post("/api/upload")
async def collect_upload_audio(
    request: Request,
    password: str = Form(...),
    participant: str = Form(...),
    sentence: str = Form(...),
    intent: str = Form(default="UNKNOWN"),
    menu: str = Form(default=""),
    quantity: str = Form(default=""),
    action: str = Form(default=""),
    domain: str = Form(default=""),
    condition: str = Form(...),
    dialect: str = Form(...),
    round_index: str = Form(...),
    file: UploadFile = File(...)
):
    check_password(password)

    audio_bytes = await file.read()

    if not audio_bytes:
        raise HTTPException(status_code=400, detail="empty audio")

    sample_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8]

    content_type = file.content_type or ""

    if "mp4" in content_type:
        ext = ".mp4"
    elif "aac" in content_type:
        ext = ".aac"
    elif "mpeg" in content_type:
        ext = ".mp3"
    elif "wav" in content_type:
        ext = ".wav"
    else:
        ext = ".webm"

    filename = f"{sample_id}{ext}"
    audio_path = COLLECT_AUDIO_DIR / filename

    with open(audio_path, "wb") as f:
        f.write(audio_bytes)

    append_collection_metadata({
        "id": sample_id,
        "filename": f"audio/{filename}",
        "participant": participant,
        "sentence": sentence,
        "intent": intent or "UNKNOWN",
        "menu": menu,
        "quantity": quantity,
        "action": action,
        "domain": domain,
        "condition": condition,
        "dialect": dialect,
        "round_index": round_index,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "user_agent": request.headers.get("user-agent", "")
    })

    return {
        "ok": True,
        "id": sample_id,
        "filename": filename
    }


@app.get("/api/progress")
def collect_get_progress(password: str, participant: str):
    check_password(password)
    ensure_collection_header()

    count = 0
    max_round = 0

    if COLLECT_META_CSV.exists():
        with open(COLLECT_META_CSV, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)

            for row in reader:
                if (row.get("participant") or "").strip() == participant.strip():
                    count += 1

                    try:
                        r = int(row.get("round_index") or "0")
                    except Exception:
                        r = 0

                    if r > max_round:
                        max_round = r

    return {
        "participant": participant,
        "count": count,
        "completed": max_round,
        "next_index": max_round + 1
    }


@app.get("/api/list")
def collect_list_files(password: str):
    check_password(password)
    ensure_collection_header()

    rows = []

    if COLLECT_META_CSV.exists():
        with open(COLLECT_META_CSV, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

    return {
        "count": len(rows),
        "rows": rows
    }


@app.get("/download/all.zip")
def collect_download_all(password: str):
    check_password(password)
    ensure_collection_header()

    zip_buffer = io.BytesIO()

    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(COLLECT_META_CSV, "metadata.csv")

        for audio_file in COLLECT_AUDIO_DIR.glob("*"):
            if audio_file.is_file():
                z.write(audio_file, f"audio/{audio_file.name}")

    zip_buffer.seek(0)

    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={
            "Content-Disposition": "attachment; filename=kiosk_voice_collection.zip"
        }
    )


@app.get("/download/audio/{filename}")
def collect_download_audio(filename: str, password: str):
    check_password(password)

    audio_path = COLLECT_AUDIO_DIR / filename

    if not audio_path.exists():
        raise HTTPException(status_code=404, detail="file not found")

    return FileResponse(audio_path, filename=filename)


# ============================================================
# 모델 관리 API
# ============================================================

@app.get("/admin/model-info")
def admin_model_info(password: str):
    check_password(password)

    return {
        "model_path": MODEL_PATH,
        "active_model_dir_exists": ACTIVE_MODEL_DIR.exists(),
        "active_model_dir": str(ACTIVE_MODEL_DIR),
        "models_dir": str(MODELS_DIR)
    }


@app.post("/admin/upload-model")
async def admin_upload_model(
    password: str = Form(...),
    file: UploadFile = File(...)
):
    check_password(password)

    if not file.filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="zip 파일만 업로드 가능합니다.")

    upload_dir = MODELS_DIR / "_upload_tmp"
    extract_dir = MODELS_DIR / "_extract_tmp"
    new_dir = MODELS_DIR / "whisper-kiosk-ct2-int8.new"
    backup_dir = MODELS_DIR / "whisper-kiosk-ct2-int8.backup"

    for p in [upload_dir, extract_dir, new_dir]:
        if p.exists():
            shutil.rmtree(p)

    upload_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)

    zip_path = upload_dir / "uploaded_model.zip"

    model_bytes = await file.read()

    if not model_bytes:
        raise HTTPException(status_code=400, detail="empty zip file")

    with open(zip_path, "wb") as f:
        f.write(model_bytes)

    try:
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(extract_dir)

        actual_model_dir = find_ct2_model_dir(extract_dir)

        shutil.copytree(actual_model_dir, new_dir)

        if backup_dir.exists():
            shutil.rmtree(backup_dir)

        if ACTIVE_MODEL_DIR.exists():
            ACTIVE_MODEL_DIR.rename(backup_dir)

        new_dir.rename(ACTIVE_MODEL_DIR)

        with model_lock:
            reload_whisper_model(str(ACTIVE_MODEL_DIR))

        return {
            "ok": True,
            "message": "model uploaded, extracted, and reloaded",
            "model_path": str(ACTIVE_MODEL_DIR)
        }

    except Exception as e:
        try:
            if ACTIVE_MODEL_DIR.exists():
                shutil.rmtree(ACTIVE_MODEL_DIR)

            if backup_dir.exists():
                backup_dir.rename(ACTIVE_MODEL_DIR)
        except Exception as restore_error:
            print("[MODEL RESTORE ERROR]", restore_error)

        raise HTTPException(status_code=500, detail=str(e))

    finally:
        for p in [upload_dir, extract_dir]:
            if p.exists():
                shutil.rmtree(p)

# ============================================================
# [V8 추가] 직원 호출 · 관리자 메뉴(menu.json) · 통계(/events, /dashboard) · /static
#   - 위의 기존 라우트(/, /kiosk, /transcribe, /collect, /api/*, /download/*, /admin/model-info,
#     /admin/upload-model)는 한 줄도 바꾸지 않았다. 아래는 새 라우트만 덧붙인 것.
#   - 관리자 PIN: 환경변수 KIOSK_ADMIN_PIN → admin_pin.txt(첫 줄) → 기본값 ADMIN_PASSWORD("0302")
# ============================================================
import json as _v8json
import html as _v8html
from collections import Counter as _V8Counter, defaultdict as _v8defaultdict
from fastapi.staticfiles import StaticFiles as _V8StaticFiles
from fastapi.responses import JSONResponse as _V8JSONResponse

V8_DATA_DIR = BASE_DIR / "kiosk_v8_data"
V8_DATA_DIR.mkdir(parents=True, exist_ok=True)
V8_MENU_JSON = BASE_DIR / "menu.json"
V8_EVENTS_JSONL = V8_DATA_DIR / "events.jsonl"
V8_STAFF_JSONL = V8_DATA_DIR / "staff_calls.jsonl"
V8_STATIC_DIR = BASE_DIR / "static"
V8_STATIC_DIR.mkdir(parents=True, exist_ok=True)
V8_PIN_FILE = BASE_DIR / "admin_pin.txt"
v8_lock = Lock()


def v8_admin_pin() -> str:
    env = os.environ.get("KIOSK_ADMIN_PIN", "").strip()
    if env:
        return env
    try:
        if V8_PIN_FILE.exists():
            first = V8_PIN_FILE.read_text(encoding="utf-8").strip().splitlines()
            if first and first[0].strip():
                return first[0].strip()
    except Exception as e:
        print("[V8 PIN FILE ERROR]", e)
    return ADMIN_PASSWORD


def v8_check_pin(pin: str):
    if not pin or str(pin).strip() != v8_admin_pin():
        raise HTTPException(status_code=403, detail="wrong pin")


def v8_append_jsonl(path: Path, row: dict):
    line = _v8json.dumps(row, ensure_ascii=False)
    with v8_lock:
        with open(path, "a", encoding="utf-8") as f:
            f.write(line + "\n")


def v8_read_jsonl(path: Path, limit: int = 200000):
    rows = []
    if not path.exists():
        return rows
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i >= limit:
                break
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(_v8json.loads(line))
            except Exception:
                continue
    return rows


V8_BASE_CSS = """
body{font-family:'Malgun Gothic','NanumGothic','Noto Sans KR',sans-serif;margin:0;background:#fdf8f0;color:#3b2f20}
header{background:#c2510f;color:#fff;padding:12px 16px;font-size:20px;font-weight:800}
main{padding:14px;max-width:1100px;margin:0 auto}
.card{background:#fff;border-radius:12px;padding:12px 14px;margin:10px 0;box-shadow:0 1px 4px rgba(0,0,0,.08)}
button{font-family:inherit;font-weight:800;border:none;border-radius:8px;padding:8px 14px;cursor:pointer;background:#c2510f;color:#fff;font-size:15px}
button.gray{background:#6b7280} button.red{background:#b91c1c}
input,select{font-family:inherit;font-size:15px;padding:6px;border:1px solid #d6c7b0;border-radius:6px}
table{border-collapse:collapse;width:100%} td,th{border-bottom:1px solid #eee;padding:6px;text-align:left;font-size:14px}
.muted{color:#8a7a63;font-size:13px} .big{font-size:28px;font-weight:900}
nav a{color:#fff;margin-left:14px;font-size:14px}
"""


def v8_page(title: str, body: str) -> HTMLResponse:
    return HTMLResponse(
        "<!doctype html><html lang='ko'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{_v8html.escape(title)}</title><style>{V8_BASE_CSS}</style></head><body>"
        f"<header>{_v8html.escape(title)}<nav style='display:inline'><a href='/staff'>직원 호출</a>"
        "<a href='/admin'>메뉴 관리</a><a href='/dashboard'>통계</a></nav></header>"
        f"<main>{body}</main></body></html>",
        headers={"Cache-Control": "no-store"},
    )


# ---------------- 4) 직원 호출 ----------------
def v8_staff_state():
    calls = {}
    for row in v8_read_jsonl(V8_STAFF_JSONL):
        cid = row.get("id")
        if not cid:
            continue
        if row.get("type") == "call":
            calls[cid] = dict(row, status="pending")
        elif row.get("type") == "done" and cid in calls:
            calls[cid]["status"] = "done"
            calls[cid]["done_time"] = row.get("time")
    return list(calls.values())


@app.post("/staff_call")
async def v8_staff_call(request: Request):
    try:
        body = await request.json()
        if not isinstance(body, dict):
            body = {}
    except Exception:
        body = {}
    row = {
        "type": "call",
        "id": uuid.uuid4().hex[:10],
        "time": datetime.now().isoformat(timespec="seconds"),
        "source": str(body.get("source", "unknown"))[:20],
        "stage": str(body.get("stage", ""))[:40],
        "items": body.get("items", [])[:20] if isinstance(body.get("items", []), list) else [],
        "offline": bool(body.get("offline", False)),
    }
    v8_append_jsonl(V8_STAFF_JSONL, row)
    print(f"[STAFF CALL] {row['time']} source={row['source']} stage={row['stage']} id={row['id']}")
    return {"ok": True, "id": row["id"]}


@app.get("/staff_call")
def v8_staff_list(all: int = 0):
    calls = v8_staff_state()
    if not all:
        calls = [c for c in calls if c.get("status") == "pending"]
    calls.reverse()  # 기록된 순서의 반대 = 최신 먼저 (같은 초에 여러 건이어도 순서 유지)
    return {"pending": sum(1 for c in v8_staff_state() if c.get("status") == "pending"), "calls": calls[:100]}


@app.post("/staff_call/{call_id}/done")
def v8_staff_done(call_id: str):
    ids = {c["id"] for c in v8_staff_state() if c.get("status") == "pending"}
    if call_id not in ids:
        raise HTTPException(status_code=404, detail="no such pending call")
    v8_append_jsonl(V8_STAFF_JSONL, {"type": "done", "id": call_id, "time": datetime.now().isoformat(timespec="seconds")})
    return {"ok": True}


@app.get("/staff", response_class=HTMLResponse)
def v8_staff_page():
    body = """
<div class='card'><div class='big' id='cnt'>불러오는 중…</div>
<div class='muted'>3초마다 새로 고칩니다. 새 호출이 오면 소리가 납니다(처음 한 번 화면을 눌러 소리 허용).</div></div>
<div id='list'></div>
<script>
let known=new Set(), first=true, ac=null;
document.addEventListener('click',()=>{ if(!ac) ac=new (window.AudioContext||window.webkitAudioContext)(); });
function ding(){ try{ if(!ac) return; [880,660,880].forEach((f,i)=>{const o=ac.createOscillator(),g=ac.createGain(),t=ac.currentTime+i*.3;o.frequency.value=f;g.gain.setValueAtTime(.3,t);g.gain.exponentialRampToValueAtTime(.001,t+.28);o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.3);}); }catch(e){} }
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
const SRC={voice:'음성',button:'버튼(길게)',screen:'화면 버튼'};
async function load(){
  try{ const r=await fetch('/staff_call',{cache:'no-store'}); const d=await r.json();
    document.getElementById('cnt').textContent = d.pending ? ('🙋 기다리는 호출 '+d.pending+'건') : '기다리는 호출 없음';
    let fresh=false; d.calls.forEach(c=>{ if(!known.has(c.id)){ known.add(c.id); if(!first) fresh=true; } });
    if(fresh) ding(); first=false;
    document.getElementById('list').innerHTML = d.calls.map(c=>`<div class='card'><b>${esc(c.time.replace('T',' '))}</b> · ${esc(SRC[c.source]||c.source)} · 화면: ${esc(c.stage||'-')}${c.offline?' · 오프라인 모드':''}
      <div class='muted'>${(c.items||[]).map(i=>esc(i.item+' '+i.count+'개')).join(', ')||'담은 메뉴 없음'}</div>
      <button onclick="done('${esc(c.id)}')">처리 완료</button></div>`).join('');
  }catch(e){ document.getElementById('cnt').textContent='서버 연결 안 됨'; }
}
async function done(id){ await fetch('/staff_call/'+id+'/done',{method:'POST'}); load(); }
load(); setInterval(load,3000);
</script>"""
    return v8_page("직원 호출", body)


# ---------------- 6) 관리자: 메뉴 · 가격 · 품절 ----------------
@app.get("/menu.json")
def v8_menu_json():
    if not V8_MENU_JSON.exists():
        return _V8JSONResponse({"detail": "menu.json not found"}, status_code=404, headers={"Cache-Control": "no-store"})
    try:
        data = _v8json.loads(V8_MENU_JSON.read_text(encoding="utf-8"))
    except Exception as e:
        return _V8JSONResponse({"detail": f"menu.json broken: {e}"}, status_code=500, headers={"Cache-Control": "no-store"})
    return _V8JSONResponse(data, headers={"Cache-Control": "no-store"})


@app.post("/admin/login")
async def v8_admin_login(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {}
    v8_check_pin(str((body or {}).get("pin", "")))
    return {"ok": True}


def v8_validate_menus(menus):
    if not isinstance(menus, list) or not menus:
        raise HTTPException(status_code=400, detail="menus must be a non-empty list")
    out, seen = [], set()
    for m in menus:
        if not isinstance(m, dict):
            raise HTTPException(status_code=400, detail="menu item must be an object")
        name = str(m.get("name", "")).strip()
        category = str(m.get("category", "")).strip()
        if not name or len(name) > 30:
            raise HTTPException(status_code=400, detail=f"bad name: {name!r}")
        if name in seen:
            raise HTTPException(status_code=400, detail=f"duplicate name: {name}")
        if not category or len(category) > 20:
            raise HTTPException(status_code=400, detail=f"bad category for {name}")
        try:
            price = int(m.get("price"))
        except Exception:
            raise HTTPException(status_code=400, detail=f"bad price for {name}")
        if price < 0 or price > 1000000:
            raise HTTPException(status_code=400, detail=f"price out of range for {name}")
        seen.add(name)
        out.append({"name": name, "price": price, "category": category,
                    "taste": str(m.get("taste", ""))[:60], "soldOut": bool(m.get("soldOut", False))})
    return out


@app.post("/admin/menu")
async def v8_admin_save_menu(request: Request):
    v8_check_pin(request.headers.get("X-Admin-Pin", ""))
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="json body required")
    menus = v8_validate_menus((body or {}).get("menus"))
    old = {}
    if V8_MENU_JSON.exists():
        try:
            old = _v8json.loads(V8_MENU_JSON.read_text(encoding="utf-8"))
        except Exception:
            old = {}
    new_names = {m["name"] for m in menus}
    removed = set(old.get("removed", []) if isinstance(old.get("removed", []), list) else [])
    for m in old.get("menus", []) if isinstance(old.get("menus"), list) else []:
        if isinstance(m, dict) and m.get("name") and m["name"] not in new_names:
            removed.add(m["name"])
    removed -= new_names
    data = {"version": int(old.get("version", 0) or 0) + 1, "full": True,
            "updated": datetime.now().isoformat(timespec="seconds"),
            "menus": menus, "removed": sorted(removed)}
    with v8_lock:
        if V8_MENU_JSON.exists():
            shutil.copyfile(V8_MENU_JSON, BASE_DIR / "menu.json.bak")
        tmp = BASE_DIR / "menu.json.tmp"
        tmp.write_text(_v8json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, V8_MENU_JSON)
    print(f"[ADMIN MENU] saved v{data['version']} items={len(menus)} soldOut={sum(m['soldOut'] for m in menus)}")
    return {"ok": True, "version": data["version"], "count": len(menus)}


# [V8.2 추가] 키오스크 설정(가게 종류) — 읽기는 누구나, 쓰기는 PIN
V8_SETTINGS_JSON = BASE_DIR / "kiosk_settings.json"
V8_SHOP_TYPES = {"": "설정 안 함 (켤 때마다 물어보기)", "gukbap": "국밥집", "cafe": "카페", "burger": "햄버거집",
                 "flower": "꽃집", "stationery": "문구점", "gift": "선물가게"}


def v8_read_settings() -> dict:
    try:
        if V8_SETTINGS_JSON.exists():
            d = _v8json.loads(V8_SETTINGS_JSON.read_text(encoding="utf-8"))
            if isinstance(d, dict):
                return d
    except Exception as e:
        print("[V8.2 SETTINGS ERROR]", e)
    return {}


@app.get("/kiosk_settings")
def v8_get_settings():
    d = v8_read_settings()
    return _V8JSONResponse({"shop": str(d.get("shop", "") or ""), "shopTypes": V8_SHOP_TYPES,
                            "updated": d.get("updated", "")}, headers={"Cache-Control": "no-store"})


@app.post("/admin/settings")
async def v8_save_settings(request: Request):
    v8_check_pin(request.headers.get("X-Admin-Pin", ""))
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="json body required")
    shop = str((body or {}).get("shop", "") or "").strip()
    if shop not in V8_SHOP_TYPES:
        raise HTTPException(status_code=400, detail=f"unknown shop: {shop}")
    d = v8_read_settings()
    d["shop"] = shop
    d["updated"] = datetime.now().isoformat(timespec="seconds")
    with v8_lock:
        tmp = BASE_DIR / "kiosk_settings.json.tmp"
        tmp.write_text(_v8json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, V8_SETTINGS_JSON)
    print(f"[ADMIN SETTINGS] shop={shop or '(unset)'}")
    return {"ok": True, "shop": shop}


@app.get("/admin", response_class=HTMLResponse)
def v8_admin_page():
    body = """
<div class='card' id='login'><b>관리자 PIN</b> <input id='pin' type='password' inputmode='numeric' autocomplete='off'>
<button onclick='login()'>들어가기</button> <span id='lmsg' class='muted'></span></div>
<div id='editor' style='display:none'>
<div class='card'><b>가게 종류</b> <select id='shop'></select> <button onclick='saveShop()'>가게 저장</button> <span id='shmsg' class='muted'></span><br>
<span class='muted'>정해 두면 키오스크가 켜질 때 "무슨 가게인가요?"를 묻지 않고 바로 그 가게로 시작합니다. 키오스크 화면을 새로고침(또는 재부팅)하면 반영됩니다.</span></div>
<div class='card'><span class='muted'>가격·품절을 고친 뒤 <b>저장</b>을 누르세요. 키오스크는 처음 화면(대기/절전)에 있을 때 2분 안에, 또는 새로 켤 때 바로 반영합니다.
메뉴 이름을 지우면 키오스크에서도 빠집니다. 새 메뉴의 그림은 종류(카테고리)에 맞는 기본 그림이 나옵니다.</span></div>
<div class='card'><table><thead><tr><th>메뉴 이름</th><th>종류</th><th>가격(원)</th><th>설명</th><th>품절</th><th></th></tr></thead><tbody id='rows'></tbody></table>
<div style='margin-top:10px'><button class='gray' onclick='addRow()'>+ 메뉴 추가</button> <button onclick='save()'>저장</button> <span id='smsg' class='muted'></span></div></div>
</div>
<script>
let PIN='', CATS=[];
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function login(){
  PIN=document.getElementById('pin').value.trim();
  const r=await fetch('/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pin:PIN})});
  if(!r.ok){ document.getElementById('lmsg').textContent='PIN이 틀렸습니다.'; return; }
  document.getElementById('login').style.display='none'; document.getElementById('editor').style.display='block'; load(); loadShop();
}
document.getElementById('pin').addEventListener('keydown',e=>{ if(e.key==='Enter') login(); });
function row(m){
  return `<tr><td><input class='n' value='${esc(m.name)}' maxlength='30'></td><td><input class='c' value='${esc(m.category)}' list='cats' size='8'></td>
  <td><input class='p' type='number' min='0' step='100' value='${esc(m.price)}' style='width:90px'></td><td><input class='t' value='${esc(m.taste||'')}' size='18'></td>
  <td><input class='s' type='checkbox' ${m.soldOut?'checked':''}></td><td><button class='red' onclick='this.closest("tr").remove()'>삭제</button></td></tr>`;
}
async function load(){
  const r=await fetch('/menu.json',{cache:'no-store'}); let d={menus:[]}; if(r.ok) d=await r.json();
  const ms=Array.isArray(d)?d:(d.menus||[]); CATS=[...new Set(ms.map(m=>m.category))];
  document.getElementById('rows').innerHTML=ms.map(row).join('')+`<datalist id='cats'>${CATS.map(c=>`<option value='${esc(c)}'>`).join('')}</datalist>`;
}
async function loadShop(){
  const r=await fetch('/kiosk_settings',{cache:'no-store'}); const d=r.ok?await r.json():{shop:'',shopTypes:{}};
  document.getElementById('shop').innerHTML=Object.entries(d.shopTypes||{}).map(([k,v])=>`<option value='${esc(k)}' ${k===d.shop?'selected':''}>${esc(v)}</option>`).join('');
}
async function saveShop(){
  const shop=document.getElementById('shop').value;
  const r=await fetch('/admin/settings',{method:'POST',headers:{'Content-Type':'application/json','X-Admin-Pin':PIN},body:JSON.stringify({shop})});
  const d=await r.json().catch(()=>({})); document.getElementById('shmsg').textContent = r.ok ? '저장했습니다. 키오스크를 새로고침하세요.' : ('저장 실패: '+(d.detail||r.status));
}
function addRow(){ document.getElementById('rows').insertAdjacentHTML('beforeend',row({name:'',category:CATS[0]||'',price:0,taste:'',soldOut:false})); }
async function save(){
  const menus=[...document.querySelectorAll('#rows tr')].map(tr=>({name:tr.querySelector('.n').value.trim(),category:tr.querySelector('.c').value.trim(),
    price:Number(tr.querySelector('.p').value),taste:tr.querySelector('.t').value.trim(),soldOut:tr.querySelector('.s').checked})).filter(m=>m.name);
  const r=await fetch('/admin/menu',{method:'POST',headers:{'Content-Type':'application/json','X-Admin-Pin':PIN},body:JSON.stringify({menus})});
  const d=await r.json().catch(()=>({})); document.getElementById('smsg').textContent = r.ok ? ('저장했습니다 (판 '+d.version+', '+d.count+'개)') : ('저장 실패: '+(d.detail||r.status));
}
</script>"""
    return v8_page("메뉴 관리", body)


# ---------------- 7) 통계 ----------------
@app.post("/events")
async def v8_events(request: Request):
    raw = await request.body()
    if len(raw) > 65536:
        raise HTTPException(status_code=413, detail="event too large")
    try:
        ev = _v8json.loads(raw.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="json body required")
    if not isinstance(ev, dict):
        raise HTTPException(status_code=400, detail="event must be an object")
    ev["server_time"] = datetime.now().isoformat(timespec="seconds")
    v8_append_jsonl(V8_EVENTS_JSONL, ev)
    return {"ok": True}


STAGE_KO = {
    "welcome": "첫 화면", "open_order_prompt": "메뉴 말하기", "category_select": "종류 고르기", "menu_grid": "메뉴판",
    "menu_confirm": "메뉴 확인", "temp": "온도", "upsell": "세트 여부", "quantity": "개수", "cup_size": "컵 크기",
    "beverage_option_prompt": "음료 옵션 묻기", "beverage_option_step": "음료 옵션", "beverage_result": "옵션 확인",
    "add_more_prompt": "추가 주문", "summary": "주문 내역 확인", "summary_add_quantity": "추가 개수", "place": "매장/포장",
    "payment": "결제 방법", "guidance": "결제 안내", "done": "완료", "taste_select_prompt": "맛 고르기", "guide": "사용법",
}


def v8_bar_svg(pairs, unit="", color="#c2510f", width=520):
    if not pairs:
        return "<div class='muted'>아직 자료가 없습니다.</div>"
    mx = max(v for _, v in pairs) or 1
    h = 26 * len(pairs) + 6
    out = [f"<svg width='100%' viewBox='0 0 {width} {h}' role='img' style='max-width:{width}px'>"]
    for i, (label, v) in enumerate(pairs):
        y = 4 + i * 26
        w = int((width - 230) * (v / mx))
        out.append(f"<text x='0' y='{y + 15}' font-size='13' fill='#3b2f20'>{_v8html.escape(str(label))[:16]}</text>")
        out.append(f"<rect x='140' y='{y}' width='{max(w, 2)}' height='18' rx='4' fill='{color}'/>")
        vs = f"{v:g}" if isinstance(v, (int, float)) else str(v)
        out.append(f"<text x='{146 + w}' y='{y + 14}' font-size='12' fill='#3b2f20'>{vs}{unit}</text>")
    out.append("</svg>")
    return "".join(out)


def v8_day_svg(days):
    if not days:
        return "<div class='muted'>아직 자료가 없습니다.</div>"
    days = days[-14:]
    mx = max(c + a for _, c, a in days) or 1
    W, H, bw = 560, 170, 34
    out = [f"<svg width='100%' viewBox='0 0 {W} {H + 34}' style='max-width:{W}px'>"]
    for i, (d, c, a) in enumerate(days):
        x = 10 + i * (bw + 5)
        hc = int(H * c / mx); ha = int(H * a / mx)
        out.append(f"<rect x='{x}' y='{H - hc}' width='{bw}' height='{hc}' fill='#c2510f'/>")
        out.append(f"<rect x='{x}' y='{H - hc - ha}' width='{bw}' height='{ha}' fill='#d6c7b0'/>")
        out.append(f"<text x='{x + bw / 2}' y='{H - hc - ha - 3}' font-size='11' text-anchor='middle'>{c + a}</text>")
        out.append(f"<text x='{x + bw / 2}' y='{H + 14}' font-size='10' text-anchor='middle'>{_v8html.escape(d[5:])}</text>")
    out.append(f"<text x='10' y='{H + 30}' font-size='11' fill='#8a7a63'>■ 주황: 결제까지 끝낸 주문 · ■ 회색: 중간에 그만둔 주문</text></svg>")
    return "".join(out)


@app.get("/dashboard", response_class=HTMLResponse)
def v8_dashboard(pin: str = ""):
    if pin.strip() != v8_admin_pin():
        return v8_page("통계", "<div class='card'><form method='get'><b>관리자 PIN</b> <input name='pin' type='password' inputmode='numeric'> <button>보기</button></form>"
                       + ("<div class='muted'>PIN이 틀렸습니다.</div>" if pin else "") + "</div>")
    events = [e for e in v8_read_jsonl(V8_EVENTS_JSONL) if e.get("type") == "order"]
    done = [e for e in events if e.get("result") == "completed"]
    menu_cnt = _V8Counter()
    for e in done:
        for it in e.get("items") or []:
            try:
                menu_cnt[str(it.get("item"))] += int(it.get("count") or 1)
            except Exception:
                pass
    durs = [e.get("durationMs", 0) / 1000 for e in done if isinstance(e.get("durationMs"), (int, float))]
    avg = (sum(durs) / len(durs)) if durs else 0
    stuck = _V8Counter()
    stage_ms = _v8defaultdict(list)
    for e in events:
        for s in e.get("stuck") or []:
            stuck[STAGE_KO.get(s, s)] += 1
        for s, v in (e.get("stages") or {}).items():
            if isinstance(v, dict) and isinstance(v.get("ms"), (int, float)):
                stage_ms[STAGE_KO.get(s, s)].append(v["ms"] / 1000)
    per_day = _v8defaultdict(lambda: [0, 0])
    for e in events:
        d = str(e.get("server_time") or e.get("end") or "")[:10]
        if d:
            per_day[d][0 if e.get("result") == "completed" else 1] += 1
    days = [(d, v[0], v[1]) for d, v in sorted(per_day.items())]
    fb = sum(1 for e in events if e.get("fallback"))
    staff = sum(int(e.get("staffCalls") or 0) for e in events)
    stage_avg = sorted(((k, round(sum(v) / len(v), 1)) for k, v in stage_ms.items() if v), key=lambda x: -x[1])[:10]
    body = f"""
<div class='card' style='display:flex;gap:24px;flex-wrap:wrap'>
 <div><div class='muted'>전체 주문 시도</div><div class='big'>{len(events)}</div></div>
 <div><div class='muted'>결제까지 완료</div><div class='big'>{len(done)}</div></div>
 <div><div class='muted'>평균 주문 시간(완료)</div><div class='big'>{avg:.0f}초</div></div>
 <div><div class='muted'>오프라인 모드 사용</div><div class='big'>{fb}</div></div>
 <div><div class='muted'>직원 호출(주문 중)</div><div class='big'>{staff}</div></div>
</div>
<div class='card'><b>많이 팔린 메뉴 (완료 주문, 개수)</b>{v8_bar_svg(menu_cnt.most_common(10), '개')}</div>
<div class='card'><b>막힌 단계</b> <span class='muted'>(한 화면에서 3번 이상 말했거나 30초 넘게 머문 주문 수)</span>{v8_bar_svg(stuck.most_common(10), '건', '#b91c1c')}</div>
<div class='card'><b>단계별 평균 머문 시간</b>{v8_bar_svg(stage_avg, '초', '#6b7280')}</div>
<div class='card'><b>날짜별 주문 수 (최근 14일)</b>{v8_day_svg(days)}</div>
<div class='muted'>자료 파일: {_v8html.escape(str(V8_EVENTS_JSONL))}</div>"""
    return v8_page("통계", body)


# ---------------- 9) 메뉴 그림(twemoji) 등 정적 파일 ----------------
app.mount("/static", _V8StaticFiles(directory=str(V8_STATIC_DIR)), name="static")


# =====================================================================
# [V8.3 추가] 아두이노 시리얼 브리지 (기존 기능 삭제 없음)
#  - 서버가 /dev/ttyUSB* /dev/ttyACM* 를 자동으로 찾아 9600bps로 연다 (포트 선택창 불필요)
#  - 연결 직후 2초 동안 들어온 데이터는 버림 (보드 리셋 직후 잡음 방지)
#  - 알려진 줄(WAKE_BUTTON, STAFF_CALL 등)만 정확히 일치할 때 화면으로 보냄 (SSE: /api/button-events)
#  - 화면 → 아두이노 LED 명령: POST /api/button-command
#  - 사용 기록: POST /api/use-metrics (use_metrics.jsonl 에 한 줄씩 추가)
# =====================================================================
import threading as _v83threading
import asyncio as _v83asyncio
import glob as _v83glob

V83_BAUD = int(os.environ.get("KIOSK_SERIAL_BAUD", "9600"))
V83_BOOT_IGNORE_SEC = 2.0
V83_ALLOWED = {"WAKE_BUTTON", "STAFF_CALL", "START_BUTTON", "BUTTON_PRESSED", "TOGGLE_MIC"}
V83_CMD_ALLOWED = {"LED_SLEEP", "LED_OFF", "LED_READY", "BUTTON_LED_ON", "LED_ON", "LED_BLINK",
                   "BUTTON_LED_BLINK", "LED_WAKE_PROMPT", "LED_IDLE", "LED_IDLE_SOFT"}
_v83_state = {"port": None, "connected": False, "seq": 0, "events": [], "ser": None, "last_error": ""}
_v83_cond = _v83threading.Condition()


def _v83_push(name: str):
    with _v83_cond:
        _v83_state["seq"] += 1
        _v83_state["events"].append({"id": _v83_state["seq"], "event": name, "at": time.time()})
        _v83_state["events"] = _v83_state["events"][-50:]
        _v83_cond.notify_all()


def _v83_find_port():
    env = os.environ.get("KIOSK_SERIAL_PORT", "").strip()
    if env:
        return env if os.path.exists(env) else None
    c = sorted(_v83glob.glob("/dev/ttyUSB*")) + sorted(_v83glob.glob("/dev/ttyACM*"))
    return c[0] if c else None


def _v83_serial_loop():
    try:
        import serial  # pyserial
    except Exception as e:
        _v83_state["last_error"] = "pyserial 없음: " + str(e)
        print("[V83 SERIAL] pyserial이 설치되지 않아 시리얼 브리지를 끕니다. (pip install pyserial)")
        return
    while True:
        port = _v83_find_port()
        if not port:
            _v83_state["connected"] = False
            time.sleep(2)
            continue
        try:
            ser = serial.Serial(port, V83_BAUD, timeout=0.2)
            _v83_state.update(port=port, connected=True, ser=ser, last_error="")
            print("[V83 SERIAL] 연결:", port, V83_BAUD)
            opened = time.time()
            buf = b""
            while True:
                data = ser.read(64)
                if time.time() - opened < V83_BOOT_IGNORE_SEC:
                    buf = b""
                    continue
                if not data:
                    continue
                buf += data
                if len(buf) > 512:
                    buf = buf[-128:]
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    msg = line.decode("utf-8", "ignore").strip()
                    if msg in V83_ALLOWED:
                        print("[V83 SERIAL] 버튼:", msg)
                        if msg == "STAFF_CALL":   # v8.5: 직원 호출(2초 길게) 수신 확인용 로그
                            print("[V85 STAFF_CALL] 아두이노 2초 길게 누름 수신 -> 화면으로 전달", datetime.now().isoformat(timespec="seconds"))
                        _v83_push(msg)
                    elif msg:
                        print("[V83 SERIAL] 무시:", msg[:40])
        except Exception as e:
            _v83_state["last_error"] = str(e)
            print("[V83 SERIAL] 끊김/오류:", e)
        try:
            if _v83_state.get("ser"):
                _v83_state["ser"].close()
        except Exception:
            pass
        _v83_state.update(connected=False, ser=None)
        time.sleep(2)


if os.environ.get("KIOSK_SERIAL_BRIDGE", "1") != "0":
    _v83threading.Thread(target=_v83_serial_loop, daemon=True, name="v83-serial").start()


@app.get("/api/button-status")
def v83_button_status():
    return {"connected": _v83_state["connected"], "port": _v83_state["port"],
            "baud": V83_BAUD, "last_error": _v83_state["last_error"]}


@app.get("/api/button-events")
async def v83_button_events(request: Request):
    async def gen():
        last = _v83_state["seq"]   # 접속 전에 쌓인 이벤트는 보내지 않음
        yield "retry: 2000\n\n"
        yield "event: status\ndata: " + _v8json.dumps({"connected": _v83_state["connected"], "port": _v83_state["port"]}) + "\n\n"
        tick = 0
        while True:
            # [V8.9] __V89__ 새 버튼 이벤트가 있을 때만 목록을 훑고, 연결 끊김 확인은 1초에 한 번 (파이 CPU 아끼기, 반응 속도 0.1초 그대로)
            if tick % 10 == 0 and await request.is_disconnected():
                break
            evs = [e for e in list(_v83_state["events"]) if e["id"] > last] if _v83_state["seq"] != last else ()
            for e in evs:
                last = e["id"]
                yield "data: " + _v8json.dumps(e) + "\n\n"
            tick += 1
            if tick % 50 == 0:
                yield "event: status\ndata: " + _v8json.dumps({"connected": _v83_state["connected"], "port": _v83_state["port"]}) + "\n\n"
            await _v83asyncio.sleep(0.1)
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/api/button-command")
async def v83_button_command(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {}
    cmd = str((body or {}).get("cmd", "")).strip()
    import re as _v83re
    if not _v83re.fullmatch(r"[A-Z_]{1,32}", cmd):
        return {"ok": False, "reason": "unknown cmd"}
    ser = _v83_state.get("ser")
    if not ser:
        return {"ok": False, "reason": "not connected"}
    try:
        ser.write((cmd + "\n").encode())
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "reason": str(e)}


V83_USE_METRICS_FILE = BASE_DIR / "use_metrics.jsonl"


@app.post("/api/use-metrics")
async def v83_use_metrics(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {"raw": (await request.body()).decode("utf-8", "ignore")[:20000]}
    try:
        if isinstance(body, dict) and body.get("type") == "v86_offline_on":
            print(f"[V86 OFFLINE_ON] reason={body.get('reason')} navigator.onLine={body.get('online')}", flush=True)
    except Exception:
        pass
    try:
        v8_append_jsonl(V83_USE_METRICS_FILE, {"received_at": datetime.now().isoformat(timespec="seconds"), "data": body})
    except Exception as e:
        return {"ok": False, "reason": str(e)}
    return {"ok": True}


# ============================================================
# [V8.9] __V89__ 목소리 특징 맞춤: 숫자 요약만 저장 (녹음·파형 없음)
#   GET    /api/acoustic-profile  → 저장된 요약
#   POST   /api/acoustic-profile  → 저장 (키오스크 기기에서만, 숫자만 남기고 16KB 이하)
#   DELETE /api/acoustic-profile  → 지우기 (키오스크 기기에서만)
# ============================================================
V89_ACOUSTIC_FILE = V8_DATA_DIR / "acoustic_profile.json"
_V89_WORD_RE = __import__("re").compile(r"^[\uAC00-\uD7A3A-Za-z0-9 ]{1,20}$")


def _v89_num(v):
    try:
        f = float(v)
        return round(f, 4) if f == f and abs(f) < 1e7 else 0
    except Exception:
        return 0


def v89_sanitize_acoustic(d):
    out = {"v": 1, "updated": "", "global": {}, "words": {}}
    if not isinstance(d, dict):
        return out
    if isinstance(d.get("updated"), str):
        out["updated"] = d["updated"][:10]
    g = d.get("global") if isinstance(d.get("global"), dict) else {}
    for k in ("sessions", "utterances", "dbMean", "f0Med", "rate", "floorDb"):
        out["global"][k] = _v89_num(g.get(k, 0))
    ws = d.get("words") if isinstance(d.get("words"), dict) else {}
    for k in list(ws.keys())[:60]:
        if not isinstance(k, str) or not _V89_WORD_RE.match(k) or not isinstance(ws[k], dict):
            continue
        out["words"][k] = {f: _v89_num(ws[k].get(f, 0)) for f in ("n", "msPerSyl", "db", "f0", "lo", "mid", "hi")}
    return out


def _v89_local(request: Request) -> bool:
    host = (request.client.host if request.client else "") or ""
    return host in ("127.0.0.1", "::1", "localhost") or host.startswith("127.")


@app.get("/api/acoustic-profile")
def v89_acoustic_get():
    try:
        if V89_ACOUSTIC_FILE.exists():
            return v89_sanitize_acoustic(_v8json.loads(V89_ACOUSTIC_FILE.read_text(encoding="utf-8")))
    except Exception:
        pass
    return v89_sanitize_acoustic({})


@app.post("/api/acoustic-profile")
async def v89_acoustic_post(request: Request):
    if not _v89_local(request):
        raise HTTPException(status_code=403, detail="kiosk only")
    raw = await request.body()
    if len(raw) > 16384:
        raise HTTPException(status_code=413, detail="too large")
    try:
        body = _v8json.loads(raw.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="bad json")
    clean = v89_sanitize_acoustic(body)
    tmp = V89_ACOUSTIC_FILE.with_suffix(".tmp")
    tmp.write_text(_v8json.dumps(clean, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, V89_ACOUSTIC_FILE)
    return {"ok": True, "words": len(clean["words"])}


@app.delete("/api/acoustic-profile")
def v89_acoustic_delete(request: Request):
    if not _v89_local(request):
        raise HTTPException(status_code=403, detail="kiosk only")
    try:
        V89_ACOUSTIC_FILE.unlink()
    except FileNotFoundError:
        pass
    return {"ok": True}
