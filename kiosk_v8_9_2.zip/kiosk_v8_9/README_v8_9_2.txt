키오스크 v8.9.2 (2026-10-28 KST)
v8.9.1 의 화면 방향 수정은 그대로입니다. 이번에 고친 것은 세 가지입니다.

1. 메뉴 그림 칸에 글자만 나오던 것
   - 그림 파일이 없는 메뉴(꽃, 화분, 선물, 볼펜, 수첩 등)는 실패하면 이름 첫 글자만 남았습니다.
     그 그림 파일을 넣었습니다.
   - 파이에서는 메뉴 그림을 PNG로 띄웁니다. SVG가 깨지면 그림 칸에 메뉴 이름이 글자로 남습니다.
   - 서버가 .svg 와 .png 를 그림 종류로 알려 줍니다.

2. 재부팅 뒤 와이파이 연결을 기다리던 시간
   - 키오스크는 인터넷 없이 이 기기 안에서 동작합니다.
   - 부팅이 와이파이 연결 완료를 기다리지 않게 했습니다.
   - 저장해 둔 와이파이는 화면이 뜬 뒤에 붙습니다.
   - 와이파이 절전을 끕니다. 절전이 켜져 있으면 붙는 데 오래 걸리고, 붙은 뒤에도 화면이 끊깁니다.

3. 남아 있던 렉
   - 파이에서 메뉴 카드 모양을 1.5초마다, 그리고 화면이 바뀔 때마다 다시 칠하던 일을 멈췄습니다.
   - 크롬 그림 캐시를 SD카드 대신 메모리에 둡니다.
   - 화면 그리기 스레드는 1개입니다. 음성 인식이 코어를 쓰는 동안 화면이 덜 멈춥니다.

[확인]
  grep __V892__ ~/kiosk_project/kiosk.html ~/kiosk_project/pi/kiosk_launcher.sh
  글자가 나오면 v8.9.2 입니다.
  grep -c __V89__ ~/kiosk_project/kiosk.html    → 14 (v8.9 표시는 그대로)

[설치] kiosk_v8_9_2.zip 을 파이 홈 폴더(~)에 복사한 뒤:
  cd ~
  unzip -o kiosk_v8_9_2.zip
  cp -r ~/kiosk_v8_9/* ~/kiosk_project/
  if [ -f ~/kiosk_project_backup_v88/menu.json ]; then cp ~/kiosk_project_backup_v88/menu.json ~/kiosk_project/menu.json; fi
  chmod +x ~/kiosk_project/pi/*.sh
  sudo cp ~/kiosk_project/pi/kiosk-stt.service /etc/systemd/system/kiosk-stt.service
  sudo systemctl daemon-reload
  bash ~/kiosk_project/pi/wifi_fast.sh
  sudo reboot

화면 방향 180도는 화면 설정(Screen Configuration)에 저장해 둔 값을 그대로 씁니다.
실행기는 그 방향을 90도로 되돌리지 않습니다.

[여기 컴퓨터에서는 파이 화면과 와이파이에 연결해 보지 못했습니다]
  그림이 보이는지, 재부팅이 덜 걸지는 파이에서 확인해야 합니다.
