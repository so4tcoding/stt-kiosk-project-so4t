# kiosk v8.5 — 버튼 2초 길게 = 직원 호출 수정 (기존 기능 삭제 없음)
- 원인(가장 유력): 아두이노에 STAFF_CALL을 보내지 않는 예전 스케치(v7.3)가 올라가 있음. 서버·화면 코드 경로(STAFF_CALL 허용 → SSE → __kioskStaffCall)는 정상.
- 수정: kiosk_button_led.ino(v8 기능, STAFF_CALL 포함)를 다시 업로드 / 서버 로그 [V85 STAFF_CALL] 추가 / 화면 직원호출 함수 준비 전이면 재시도 후 서버 /staff_call 직접 기록.
- 확인: journalctl -u kiosk-stt -f | grep -E "V83|V85|STAFF"
