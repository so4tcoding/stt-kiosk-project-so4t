// v8.7 하이브리드 STT 시뮬레이션 (가짜 SpeechRecognition + 모의 Whisper(/transcribe) 서버). 60초 시험 타이머는 3초로 줄임.
process.env.PRE=(process.env.PRE||'')+';(function(){const si=window.setInterval;window.setInterval=function(f,ms,...a){return si(f,ms===60000?3000:ms,...a);};})();';
const {open}=require('/workspace/gen8_6/test/flow8'); const fs=require('fs'); const W=ms=>new Promise(r=>setTimeout(r,ms));
const CALLS='/tmp/srv/stub_calls.log'; const nCalls=()=>fs.existsSync(CALLS)?fs.readFileSync(CALLS,'utf8').trim().split('\n').filter(Boolean).length:0;
const res=[]; const ok=(n,c,i)=>{res.push(!!c); console.log((c?'✔ ':'✘ ')+n+(i!==undefined?'  '+JSON.stringify(i).slice(0,260):''));};
(async()=>{ fs.writeFileSync('/tmp/srv/stub_text.txt','');
 const k=await open('kiosk',20); const st=()=>k.ev(()=>currentStageName);
 const bad=[]; k.p.on('response',r=>{ if(r.status()>=400) bad.push(r.status()+' '+r.url()); });
 await k.ev(()=>document.getElementById('boot-btn').click()); await W(4000); await k.ev(()=>__serialPush('WAKE_BUTTON')); await W(3000);
 await k.idle();
 // 1) 1초 안 성공
 let c0=nCalls(); let t0=Date.now(); await k.ev(()=>__say('돼지국밥')); let s=''; while(Date.now()-t0<3000){ s=await st(); if(s!=='open_order_prompt') break; await W(20);} const dt=Date.now()-t0;
 ok('Web Speech 1차 인식 성공 → 1초 안 다음 단계, Whisper 호출 없음', s==='quantity' && dt<1000 && nCalls()===c0, {s,dt,calls:nCalls()-c0});
 // 2) '네'는 수량 아님
 let r=await k.say('네'); ok("수량 화면 '네' → 4개로 안 받음", r.stage==='quantity' && !(await k.ev(()=>tempItem.count===4)), r.spoken);
 // 3) 긴/수량 섞인 말 → Whisper 2차 (모의 결과 사용)
 await k.ev(()=>{ transitionTo('open_order_prompt', typeof renderOpenOrderPrompt==='function'?renderOpenOrderPrompt:()=>{}); }); await k.idle();
 fs.writeFileSync('/tmp/srv/stub_text.txt','순대국밥 두 개 주세요'); c0=nCalls();
 r=await k.say('돼지국밥 두 개 주세요'); await W(1500);
 const ti=await k.ev(()=>({i:tempItem.item,c:tempItem.count,cart:orderState.items.map(x=>x.item+'x'+x.count)}));
 ok('수량 섞인 말 → Whisper 2차 호출, Whisper 결과(순대국밥) 사용', nCalls()===c0+1 && (ti.i==='순대국밥'||ti.cart.some(x=>/순대국밥/.test(x))), {calls:nCalls()-c0,ti,st:await st()});
 // 4) Whisper 빈 결과 → Web Speech 1차 결과로 진행
 await k.ev(()=>{ orderState.items.length=0; resetTempItemOnly(); transitionTo('open_order_prompt', typeof renderOpenOrderPrompt==='function'?renderOpenOrderPrompt:()=>{}); }).catch(()=>{}); await k.idle();
 fs.writeFileSync('/tmp/srv/stub_text.txt',''); c0=nCalls();
 r=await k.say('불고기버거 한 개 주세요'); await W(1500);
 const t2=await k.ev(()=>({i:tempItem.item,c:tempItem.count,st:currentStageName,cart:orderState.items.map(x=>x.item)}));
 ok('Whisper 빈 결과 → Web Speech 결과(불고기버거)로 계속', nCalls()===c0+1 && (t2.i==='불고기버거'||t2.cart.includes('불고기버거')), t2);
 // 5) no-speech 오류 → 오프라인 아님, 빠른 재시작
 await k.idle(); const fire=async e=>k.ev(e=>{ const rec=window.__recs.filter(r=>r._running).pop(); if(!rec) return 'none'; const ev=new Event('error'); ev.error=e; rec.dispatchEvent(ev); rec.stop(); return 'ok'; },e);
 let n0=await k.ev(()=>__TEST_LOG.filter(x=>x.ev==='rec.start').length); await fire('no-speech'); await W(600);
 ok('no-speech(결과 없음) → 오프라인 아님 + 바로 다시 듣기', !(await k.ev(()=>__kioskV8.fallback.offline)) && (await k.ev(()=>__TEST_LOG.filter(x=>x.ev==='rec.start').length))>n0);
 // 6) not-allowed x3 → 오프라인
 for(let i=0;i<3;i++){ await k.ev(()=>new Promise(res=>{const t=Date.now();(function w(){ if(window.__recs.some(r=>r._running)||Date.now()-t>6000) res(); else setTimeout(w,50);})();})); await fire('not-allowed'); await W(300); }
 await W(500); const fb=await k.ev(()=>({off:__kioskV8.fallback.offline,reason:__kioskV8.fallback.reason,badge:getComputedStyle(document.getElementById('v8-offline-badge')).display}));
 ok('not-allowed 3번 → 오프라인 모드(배지 표시)', fb.off && /not-allowed/.test(fb.reason) && fb.badge==='block', fb);
 await W(800); const slog=fs.readFileSync('/tmp/srv_server.log','utf8');
 ok('서버에 [V86 OFFLINE_ON] 원인 기록(/api/use-metrics)', /V86 OFFLINE_ON\] reason=web-speech:not-allowed/.test(slog) || /v86_offline_on/.test(slog), (slog.match(/.*V86 OFFLINE_ON.*/g)||[]).slice(-1));
 // 7) 오프라인: Whisper 전용으로 주문
 fs.writeFileSync('/tmp/srv/stub_text.txt','');
 // 8) 줄인 시험 타이머(60초→3초)로 자동 복귀
 const t3=Date.now(); let back=false; while(Date.now()-t3<20000){ if(!(await k.ev(()=>__kioskV8.fallback.offline))){back=true;break;} await W(250);} 
 ok('60초 시험(3초로 줄임) 자동 실행 → 하이브리드로 복귀', back, {ms:Date.now()-t3, log:await k.ev(()=>__kioskV8.log.filter(x=>/probe|offline/.test(x.kind)).map(x=>x.kind+':'+x.extra))});
 // 9) TTS 중 마이크 끔
 await k.idle(); await k.ev(()=>window.speakText('테스트 안내 문장입니다. 조금 길게 말합니다. 마이크가 꺼져야 합니다.')); await W(400);
 const sb=await st(); const mute=await k.ev(()=>({flag:window.__TTS_FINAL_MIC_OFF, running:window.__recs.filter(r=>r._running).length, say:window.__say('돼지국밥')})); await W(500); const sa=await st();
 ok('TTS 말하는 중 → 마이크 차단(그때 들어온 말은 버림)', mute.flag===true && sb===sa, {mute,sb,sa});
 await k.idle(); ok('TTS 끝나면 다시 듣기', await k.ev(()=>window.__recs.some(r=>r._running)));
 const errs=k.logs.filter(l=>/PAGEERROR|Uncaught/.test(l));
 ok('페이지 오류 없음', errs.length===0, errs.slice(0,5)); ok('HTTP 4xx/5xx 없음', bad.length===0, bad.slice(0,8));
 console.log('결과: '+res.filter(Boolean).length+'/'+res.length); await k.close(); })();
