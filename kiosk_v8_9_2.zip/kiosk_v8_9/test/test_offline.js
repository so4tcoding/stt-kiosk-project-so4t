const {open}=require('./flow8'); const W=ms=>new Promise(r=>setTimeout(r,ms)); const fs=require('fs');
const res=[]; const ok=(n,c,i)=>{res.push({n,pass:!!c}); console.log((c?'✔ ':'✘ ')+n+(i!==undefined?'  '+JSON.stringify(i).slice(0,300):''));};
const CALLS='/tmp/srv/stub_calls.log'; const nCalls=()=>fs.existsSync(CALLS)?fs.readFileSync(CALLS,'utf8').trim().split('\n').filter(Boolean).length:0;
(async()=>{ const k=await open('kiosk',20);
 const st=()=>k.ev(()=>currentStageName);
 const waitQuiet=async()=>{ for(let i=0;i<200;i++){ if(!(await k.ev(()=>speechSynthesis.speaking||speechSynthesis.pending))) break; await W(100);} await W(300); };
 await k.ev(()=>document.getElementById('boot-btn').click());
 for(let i=0;i<100;i++){ if(await k.ev(()=>__kioskSleepGate.state().cueReady)) break; await W(100);}
 await W(400); await k.ev(()=>__serialPush('WAKE_BUTTON')); await W(2500); await waitQuiet();
 // 오류 1번 → 재시작 간격
 const fire=(err)=>k.ev((err)=>{ const r=window.__recs.filter(x=>x._running&&!x.__kioskProbe).pop(); if(!r) return 'none'; const e=new Event('error'); e.error=err; r.dispatchEvent(e); r._running=false; r.dispatchEvent(new Event('end')); return 'ok'; },err);
 const starts=()=>k.ev(()=>__TEST_LOG.filter(e=>e.ev==='rec.start').map(e=>e.t));
 let s0=(await starts()).length; const t0=Date.now(); ok('인식 중인 Web Speech 있음', (await fire('no-speech'))==='ok');
 await W(500); let s1=await starts(); ok('평소(no-speech) 재시작은 빠름(80ms)', s1.length>s0, s1.length-s0);
 const tA=await k.ev(()=>Date.now()); await fire('network'); await W(1500); let sB=await starts(); const nb=sB.filter(t=>t>tA).length;
 await W(1500); let sC=await starts(); const after=sC.filter(t=>t>tA);
 ok('network 오류 뒤 재시작은 2초 이상 기다림(80ms 반복 없음)', nb===0 && after.length===1 && after[0]-tA>=1900, {within1_5s:nb, delay:after.map(t=>t-tA)});
 ok('오류 1번으로는 오프라인 아님', !(await k.ev(()=>__kioskV8.fallback.offline)));
 await fire('network'); await W(3200); await fire('network'); await W(300);
 const fb=await k.ev(()=>({off:__kioskV8.fallback.offline, reason:__kioskV8.fallback.reason, badge:getComputedStyle(document.getElementById('v8-offline-badge')).display, wo:__kioskV8.whisperOnly.on}));
 ok('10초 안 network 오류 3번 → 오프라인 모드(표시 + Whisper 전용 듣기)', fb.off && fb.badge==='block' && fb.wo, fb);
 const sOff=(await starts()).length; await W(6000); const sOff2=(await starts()).length;
 ok('오프라인 모드에서는 Web Speech 재시작 안 함', sOff2===sOff, sOff2-sOff);
 // 가짜 마이크 소리 → VAD → /transcribe → 주문 흐름
 fs.writeFileSync('/tmp/srv/stub_text.txt','돼지국밥');
 const c0=nCalls(); const stg0=await st();
 let moved=false; for(let i=0;i<40;i++){ await W(500); if(nCalls()>c0 && (await st())!==stg0){ moved=true; break; } }
 const lastTxt=await k.ev(()=>__kioskV8.whisperOnly.lastText);
 ok('Whisper 전용: 말소리 구간을 /transcribe로 보내고 결과로 주문 진행', nCalls()>c0 && moved, {calls:nCalls()-c0, stage:await st(), lastTxt});
 fs.writeFileSync('/tmp/srv/stub_text.txt','');
 const led=await k.ev(()=>__SERIAL_OUT.slice(-30).map(x=>x.cmd).filter(x=>/^LED:/.test(x)));
 ok('오프라인 모드에서도 LED:LISTEN 표시', led.includes('LED:LISTEN'), [...new Set(led)]);
 // 시험(probe): 실패하면 그대로
 await waitQuiet();
 await k.ev(()=>{ window.__probeFail=true; const C=window.webkitSpeechRecognition; const o=C.prototype.start; C.prototype.start=function(){ const r=o.apply(this,arguments); if(this.__kioskProbe&&window.__probeFail){ setTimeout(()=>{ const e=new Event('error'); e.error='network'; this.dispatchEvent(e); },100);} return r; }; });
 await k.ev(()=>__kioskV8.probe()); await W(4500);
 ok('60초 시험이 network로 실패하면 오프라인 유지', await k.ev(()=>__kioskV8.fallback.offline));
 await k.ev(()=>{window.__probeFail=false;});
 await waitQuiet(); await k.ev(()=>__kioskV8.probe()); await W(4800);
 const back=await k.ev(()=>({off:__kioskV8.fallback.offline, badge:getComputedStyle(document.getElementById('v8-offline-badge')).display, wo:__kioskV8.whisperOnly.on, run:window.__hybridSttIsRunning()}));
 ok('시험 성공 → 하이브리드(기본)로 복귀, 표시 숨김', !back.off && back.badge==='none' && !back.wo, back);
 await W(1500); ok('복귀 뒤 Web Speech 다시 듣는 중', await k.ev(()=>window.__hybridSttIsRunning() || window.__recs.some(r=>r._running&&!r.__kioskProbe)));
 const pi=await k.ev(()=>setInterval.toString().length>0); 
 ok('페이지 오류 없음', !k.logs.some(l=>/PAGEERROR/.test(l)), k.logs.filter(l=>/PAGEERROR/.test(l)).slice(0,3));
 console.log('\n결과:', res.filter(x=>x.pass).length+'/'+res.length);
 await k.close(); })().catch(e=>{console.error(e);process.exit(1)});
