# 실제 stt_server.py(faster_whisper만 모의) + 가상 시리얼(pty) → SSE → 헤드리스 크롬
import os, pty, tty, time, subprocess, json, urllib.request
def get(u): return urllib.request.urlopen('http://127.0.0.1:8000'+u).read().decode()
def post(u,d,h={}):
    r=urllib.request.Request('http://127.0.0.1:8000'+u,data=json.dumps(d).encode(),headers={'Content-Type':'application/json',**h},method='POST')
    try: return urllib.request.urlopen(r).status, urllib.request.urlopen(r).read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()[:120]
m,s=pty.openpty(); tty.setraw(s); name=os.ttyname(s)
def start():
    env=dict(os.environ,KIOSK_SERIAL_PORT=name,PYTHONPATH='/tmp/mockfw')
    p=subprocess.Popen(['/tmp/sv/bin/python','-m','uvicorn','stt_server:app','--host','127.0.0.1','--port','8000'],cwd='/tmp/srv',env=env,stdout=open('/tmp/srv_server.log','a'),stderr=subprocess.STDOUT)
    for i in range(60):
        try: get('/api/button-status'); break
        except Exception: time.sleep(0.5)
    return p
subprocess.run('pkill -f "uvicorn stt_server:app"',shell=True); time.sleep(1.5)
srv=start(); print('button-status', get('/api/button-status'))
st=json.loads(get('/kiosk_settings')); keys=list(st['shopTypes']); print('shopTypes',keys,'now',st['shop'])
target=[k for k in keys if k!=st['shop']][0]
print('wrong pin', post('/admin/settings',{'shop':target},{'X-Admin-Pin':'1111'})[0])
print('save', post('/admin/settings',{'shop':target},{'X-Admin-Pin':'0302'}))
srv.terminate(); srv.wait(); time.sleep(1); srv=start()
print('after restart shop=', json.loads(get('/kiosk_settings'))['shop'], 'expected', target)
n0=sum(1 for _ in open('/tmp/srv/kiosk_v8_data/use_metrics.jsonl')) if os.path.exists('/tmp/srv/kiosk_v8_data/use_metrics.jsonl') else None
print('use-metrics POST', post('/api/use-metrics',{'type':'sim_test','v':1}))
import glob; print('use-metrics files', glob.glob('/tmp/srv/**/*metric*',recursive=True))
for f in ['/tmp/sse_ready','/tmp/sse_ready2','/tmp/sse_wake_sent','/tmp/sse_staff_sent']:
    if os.path.exists(f): os.remove(f)
staff0=json.loads(get('/staff_call'))
br=subprocess.Popen(['node','/workspace/gen8_7/test/sse_browser.js'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
while not os.path.exists('/tmp/sse_ready'): time.sleep(0.1)
os.write(m,b'WAKE_BUTTON\n'); open('/tmp/sse_wake_sent','w').write('1')
while not os.path.exists('/tmp/sse_ready2'): time.sleep(0.1)
os.write(m,b'WAKE_BUTTON\n'); time.sleep(2.05); os.write(m,b'STAFF_CALL\n'); open('/tmp/sse_staff_sent','w').write('1')
print(br.communicate(timeout=90)[0][-3000:])
print('staff_call before', str(staff0)[:150]); print('staff_call after', get('/staff_call')[:300])
os.system("grep -E 'SERIAL|STAFF|버튼' /tmp/srv_server.log | tail -8")
