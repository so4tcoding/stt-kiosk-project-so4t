const {open}=require('/workspace/gen7c/flow'); const W=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ const k=await open(process.argv[2]||'kiosk',25);
 await k.ev(()=>document.getElementById('boot-btn').click());
 for(let i=0;i<100;i++){ if(await k.ev(()=>__kioskSleepGate.state().cueReady)) break; await W(100);}
 await W(500); await k.ev(()=>__serialPush('WAKE_BUTTON')); await W(2000);
 const steps=JSON.parse(process.argv[3]);
 for(const s of steps){ const r=await k.say(s); const sp=(r.spoken||[]); console.log('### '+s+' → '+r.stage+' | '+JSON.stringify(sp).slice(0,400)); console.log('   cart=', JSON.stringify(await k.ev(()=>orderState.items.map(i=>i.item+'x'+i.count+(i.isSet?'S':''))))); }
 console.log(k.logs.filter(l=>/PAGEERROR|\[V8\]/.test(l)).slice(-15).join('\n'));
 await k.close(); })().catch(e=>{console.error(e);process.exit(1)});
