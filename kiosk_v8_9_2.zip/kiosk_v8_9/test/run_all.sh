#!/bin/bash
# gen8 전체 시험 (서버: stub 모델로 127.0.0.1:8000 에서 /tmp/srv 실행 중이어야 함)
export BASE=http://127.0.0.1:8000/
for build in kiosk.html kiosk_fixed_v8.html; do
  cp /workspace/gen8/$build /tmp/srv/kiosk.html
  echo "######## $build"
  echo "== test8 (기능 1~9 + 기존 기능)"; timeout 600 node test8.js kiosk 2>&1 | grep -E '✘|결과'
  echo "== test_offline (오프라인 자동 전환)"; timeout 400 node test_offline.js 2>&1 | grep -E '✘|결과'
  echo "== test_nosr (Web Speech 없음)"; PRE='delete window.SpeechRecognition; delete window.webkitSpeechRecognition;' timeout 200 node test_nosr.js 2>&1 | grep -E '✔|✘'
  echo "== gen7c/test72 (절전·버튼 기존 회귀)"; (cd /workspace/gen7c && timeout 600 node test72.js kiosk 2>&1 | grep -E '✘|결과')
  echo "== gen7e/test_led73 (LED)"; (cd /workspace/gen7e && timeout 300 node test_led73.js kiosk 2>&1 | grep -vE '^\s*$' | head -4)
done
cp /workspace/gen8/kiosk.html /tmp/srv/kiosk.html
