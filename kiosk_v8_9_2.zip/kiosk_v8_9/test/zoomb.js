const {open}=require('./flow8'); const W=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ const k=await open(process.argv[2],20);
 await k.ev(()=>document.getElementById('boot-btn').click());
 for(let i=0;i<100;i++){ if(await k.ev(()=>__kioskSleepGate.state().cueReady)) break; await W(100);}
 await W(400); await k.ev(()=>__serialPush('WAKE_BUTTON')); await W(2500);
 for(const s of ['글씨 크게 해줘','글씨 크게 해줘','글씨 작게 해줘','글씨 작게','화면 확대','화면 축소']){ const r=await k.say(s); console.log(s,'→ zoom',await k.ev(()=>zoomLevel),'|',(r.spoken||[]).join(' / ')); }
 await k.close(); })();
