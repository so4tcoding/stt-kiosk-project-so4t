const puppeteer = require('/workspace/gen7c/node_modules/puppeteer-core');
const fs=require('fs');
async function open(file, msPerChar){
  const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome', headless:'new', args:['--no-sandbox','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=no-user-gesture-required']});
  const p = await b.newPage();
  const logs=[]; p.on('console', m=>logs.push(m.text())); p.on('pageerror', e=>logs.push('PAGEERROR '+e.message)); p.on('dialog', d=>{ logs.push('DIALOG '+d.message()); d.dismiss().catch(()=>{}); });
  await p.evaluateOnNewDocument('window.__TEST_MS_PER_CHAR='+(msPerChar||25)+';'+fs.readFileSync('/workspace/gen7c/stubs.js','utf8')+';'+fs.readFileSync('/workspace/gen7c/serialstub.js','utf8')+';'+(process.env.PRE||''));
  await p.goto((process.env.BASE||'http://localhost:8767/')+file,{waitUntil:(process.env.WAITU||'load'),timeout:60000});
  await new Promise(r=>setTimeout(r,3500));
  const api = {b,p,logs,
    async idle(maxMs=20000){ const t0=Date.now(); while(Date.now()-t0<maxMs){ const ok=await p.evaluate(()=>!window.speechSynthesis.speaking && window.__recs.some(r=>r._running) && window.__TTS_FINAL_MIC_OFF!==true); if(ok){ await new Promise(r=>setTimeout(r,250)); return true;} await new Promise(r=>setTimeout(r,100)); } return false; },
    async say(text, alts){ await api.idle(); const mark=logs.length; const tl=await p.evaluate(()=>window.__TEST_LOG.length); const r=await p.evaluate((t,a)=>window.__say(t,a),text,alts||[]); await new Promise(r=>setTimeout(r,600)); await api.idle(); const st=await api.state(); const spoken=await p.evaluate(n=>window.__TEST_LOG.slice(n).filter(x=>x.ev==='speak').map(x=>x.text),tl); return {said:text, r, stage:st.stage, spoken, logs:logs.slice(mark)}; },
    async state(){ return p.evaluate(()=>{ let lz='?'; try{ lz=zoomLevel; }catch(e){} return {stage:(typeof currentStageName!=='undefined')?currentStageName:'?', wz:window.zoomLevel, lz, body:document.body.className, cart:(typeof orderState!=='undefined'&&orderState.items)?orderState.items.map(i=>({n:i.name||i.menu&&i.menu.name,q:i.quantity||i.qty,o:i.options||i.size||i.cup})):null}; }); },
    async ev(fn,...a){ return p.evaluate(fn,...a); },
    close(){ return b.close(); }
  };
  return api;
}
module.exports={open};
if (require.main===module){ (async()=>{
  const k=await open(process.argv[2]||'kiosk.html');
  const steps=JSON.parse(process.argv[3]||'[]');
  for(const s of steps){ const r=await k.say(s); console.log('\n### '+s+' → stage='+r.stage+' r='+r.r); console.log('  spoken:', JSON.stringify(r.spoken)); console.log('  logs:', r.logs.filter(l=>!/^\[TTS_FINAL_MIC_OFF_PATCH_V1\] (start skipped)/.test(l)).slice(0,14).map(l=>l.slice(0,160)).join('\n        ')); }
  console.log(JSON.stringify(await k.state()));
  await k.close(); })(); }
