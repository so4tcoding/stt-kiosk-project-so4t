const {open}=require('./flow8'); const W=ms=>new Promise(r=>setTimeout(r,ms)); const fs=require('fs');
(async()=>{ const k=await open('kiosk',20);
 await k.ev(()=>document.getElementById('boot-btn').click());
 for(let i=0;i<100;i++){ if(await k.ev(()=>__kioskSleepGate.state().cueReady)) break; await W(100);}
 await W(400); await k.ev(()=>__serialPush('WAKE_BUTTON')); await W(3000);
 fs.writeFileSync('/tmp/srv/stub_text.txt','돼지국밥');
 let stg=''; for(let i=0;i<30;i++){ await W(500); stg=await k.ev(()=>currentStageName); if(stg==='quantity') break; }
 fs.writeFileSync('/tmp/srv/stub_text.txt','');
 const r=await k.ev(()=>({sr:!!(window.SpeechRecognition||window.webkitSpeechRecognition), off:__kioskV8.fallback.offline, reason:__kioskV8.fallback.reason, wo:__kioskV8.whisperOnly.on, badge:getComputedStyle(document.getElementById('v8-offline-badge')).display}));
 console.log(JSON.stringify(r), 'stage=',stg);
 console.log((!r.sr && r.off && r.wo && r.badge==='block' && stg==='quantity')?'✔ Web Speech 없음 → 처음부터 오프라인 모드로 주문 가능':'✘ no-SR');
 console.log('PAGEERRORS', k.logs.filter(l=>/PAGEERROR/.test(l)).slice(0,3));
 await k.close(); })().catch(e=>{console.error(e);process.exit(1)});
