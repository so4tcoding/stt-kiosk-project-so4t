// 실제 서버 SSE(/api/button-events) 경로: Web Serial 가짜 없이 kiosk_serial_bridge.js만 사용
const puppeteer=require('/workspace/gen7c/node_modules/puppeteer-core'); const fs=require('fs'); const W=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{ const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=no-user-gesture-required']});
 const p=await b.newPage(); const logs=[]; const bad=[]; p.on('console',m=>logs.push(m.text())); p.on('pageerror',e=>logs.push('PAGEERROR '+e.message)); p.on('response',r=>{ if(r.status()>=400) bad.push(r.status()+' '+r.url()); });
 await p.evaluateOnNewDocument('window.__TEST_MS_PER_CHAR=20;'+fs.readFileSync('/workspace/gen7c/stubs.js','utf8')+';try{Object.defineProperty(navigator,"serial",{value:undefined,configurable:true});}catch(e){}');
 await p.goto(process.argv[2]||'http://127.0.0.1:8000/kiosk.html',{waitUntil:'load'}); await W(3500);
 await p.evaluate(()=>document.getElementById('boot-btn').click()); await W(5000);
 const st=()=>p.evaluate(()=>currentStageName);
 const out={boot:await st()}; fs.writeFileSync('/tmp/sse_ready','1');
 while(!fs.existsSync('/tmp/sse_wake_sent')) await W(100); await W(2500); out.afterWake=await st();
 fs.writeFileSync('/tmp/sse_ready2','1'); while(!fs.existsSync('/tmp/sse_staff_sent')) await W(100); await W(2500);
 out.overlay=await p.evaluate(()=>{ const o=[...document.querySelectorAll('div')].find(d=>/직원/.test(d.textContent)&&getComputedStyle(d).position==='fixed'&&getComputedStyle(d).display==='flex'); return o?'flex':'none'; });
 out.afterStaff=await st(); out.shop=await p.evaluate(()=>{ try{ return (window.KioskShop&&KioskShop.current&&KioskShop.current())||document.body.dataset.shop||''; }catch(e){return 'err'} });
 out.bridge=logs.filter(l=>/SERIAL_BRIDGE|STAFF|WAKE/.test(l)).slice(0,12); out.err=logs.filter(l=>/PAGEERROR/.test(l)); out.bad=bad;
 console.log(JSON.stringify(out,null,1)); await b.close(); })();
