# 합성 '말소리' WAV (사람 목소리 아님): 기본 주파수 + 배음, 음절 모양 envelope, 작은 배경 소음
import math, random, struct, sys, wave
def make(path, amp, f0, syl_ms, n_syl, gap_ms, lead_ms=1500, tail_ms=2500, rate=48000):
    random.seed(1); x=[]
    def noise(ms):
        for _ in range(int(rate*ms/1000)): x.append((random.random()-0.5)*0.002)
    noise(lead_ms); t=0
    for s in range(n_syl):
        n=int(rate*syl_ms/1000)
        for i in range(n):
            env=math.sin(math.pi*i/n); v=sum(math.sin(2*math.pi*f0*h*t/rate)/h for h in range(1,5))
            x.append(amp*env*v*0.6+(random.random()-0.5)*0.002); t+=1
        noise(gap_ms)
    noise(tail_ms)
    with wave.open(path,'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(b''.join(struct.pack('<h',int(max(-1,min(1,v))*32767)) for v in x))
make('/tmp/quiet_slow.wav', 0.02, 130, 330, 6, 160)   # 작고 느린 말 (어르신 가정)
make('/tmp/normal_loud.wav', 0.25, 200, 160, 6, 40)   # 보통 크기·빠르기
print('ok')
