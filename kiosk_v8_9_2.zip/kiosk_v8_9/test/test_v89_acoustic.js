// [V8.9] 목소리 특징 맞춤 시험: 배운다 → 적용한다 → 녹음은 저장 안 한다
// 사용: BASE=http://127.0.0.1:8089/ BASE88=http://127.0.0.1:8088/ SRVLOG=/tmp/srv89_run.log SRVLOG88=/tmp/srv88_run.log node test_v89_acoustic.js
const puppeteer=require('/workspace/gen7c/node_modules/puppeteer-core'); const fs=require('fs'); const W=ms=>new Promise(r=>setTimeout(r,ms));
const BASE=process.env.BASE||'http://127.0.0.1:8089/', BASE88=process.env.BASE88||'';
const res=[]; const ok=(n,c,i)=>{res.push(!!c); console.log((c?'✔ ':'✘ ')+n+(i!==undefined?'  '+JSON.stringify(i).slice(0,600):''));};
async function launch(base,file,wav,pre,wu){
  const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--use-file-for-fake-audio-capture='+wav,'--autoplay-policy=no-user-gesture-required']});
  const p=await b.newPage(); const logs=[]; p.on('pageerror',e=>logs.push('PAGEERROR '+e.message));
  await p.evaluateOnNewDocument('window.__TEST_MS_PER_CHAR=20;'+fs.readFileSync('/workspace/gen7c/stubs.js','utf8')+';'+fs.readFileSync('/workspace/gen7c/serialstub.js','utf8')+';'+(pre||''));
  await p.goto(base+file,{waitUntil:wu||'load',timeout:90000}); await W(wu?6000:3000);
  return {b,p,logs,ev:(f,...a)=>p.evaluate(f,...a)};
}
const SYNTH=`window.__synth=function(o){ // 합성 말소리(16kHz) 조각들을 실제 속도(85ms마다)로 넣음
  const R=16000,x=[];let t=0;const nz=ms=>{for(let i=0;i<R*ms/1000;i++){x.push((Math.random()-0.5)*0.002);t++;}};
  nz(600);for(let s=0;s<o.n;s++){const n=R*o.syl/1000;for(let i=0;i<n;i++){const e=Math.sin(Math.PI*i/n);let v=0;for(let h=1;h<=4;h++)v+=Math.sin(2*Math.PI*o.f0*h*t/R)/h;x.push(o.amp*e*v*0.6+(Math.random()-0.5)*0.002);t++;}nz(o.gap);}nz(1600);
  const a=Float32Array.from(x);return new Promise(res=>{let i=0;(function step(){if(i>=a.length)return res(a.length);window.__kioskAcoustic.feed(a.subarray(i,i+1365),'test');i+=1365;setTimeout(step,85);})();});};`;
const QUIET={amp:0.02,f0:130,syl:330,n:9,gap:160}, LOUD={amp:0.25,f0:200,syl:170,n:9,gap:40};
(async()=>{
 // ---------- 1) 실제 마이크 경로(하이브리드 오디오 큐) → 작은 목소리 숫자 요약이 생기는지 ----------
 let k=await launch(BASE,'kiosk?pi=1','/tmp/quiet_slow.wav');
 await k.ev(()=>{__kioskAcoustic.reset();document.getElementById('boot-btn').click();}); await W(3500); await k.ev(()=>__serialPush('WAKE_BUTTON')); await W(14000);
 let s1=await k.ev(()=>({s:__kioskAcoustic.session(),p:__kioskAcoustic.params()}));
 ok('실제 마이크 경로(하이브리드 오디오 큐, 크롬 가짜 마이크=합성 WAV): 말 구간·목소리 높이 F0≈130Hz 측정', s1.s.utterances>=1 && Math.abs(s1.s.f0Med-130)<12, s1.s);
 // Web Speech가 이 말을 '돼지국밥 두 개 주세요'(9음절)로 알아들었다고 넣음 → 말 속도 계산 → 느린 손님 맞춤
 await k.ev(()=>__say('돼지국밥 두 개 주세요')); await W(1500);
 s1=await k.ev(()=>({s:__kioskAcoustic.session(),p:__kioskAcoustic.params(),r:__kioskAcoustic.session().rate}));
 ok('실제 마이크 경로: 말 속도 계산 → 끝 쉼 시간이 750ms보다 길어짐', s1.s.rate>0 && s1.p.endSilMs>750 && s1.p.why.includes('slow'), {rate:s1.s.rate,p:s1.p});
 console.log('   참고: 크롬 마이크 자동 음량 조절(AGC)이 작은 소리를 키워서 측정 dB =', s1.s.dbMean);
 await k.b.close();

 // ---------- 2) 보통 손님 vs 작고 느린 손님: 맞춤 값 비교 (같은 화면에서 합성 소리를 넣음) ----------
 k=await launch(BASE,'kiosk','/tmp/silence.wav'); await k.ev(SYNTH);
 await k.ev(()=>{__kioskAcoustic.reset();__kioskAcoustic._only('test');});
 await k.ev(o=>__synth(o),LOUD); await k.ev(()=>__kioskAcoustic.onText('돼지국밥 두 개 주세요'));
 await W(300); const pLoud=await k.ev(()=>({s:__kioskAcoustic.session(),p:__kioskAcoustic.params()}));
 await k.ev(()=>__kioskAcoustic.endSession());
 await k.ev(o=>__synth(o),QUIET); await k.ev(()=>__kioskAcoustic.onText('돼지국밥 두 개 주세요'));
 await W(300); const pQuiet=await k.ev(()=>({s:__kioskAcoustic.session(),p:__kioskAcoustic.params()}));
 console.log('   보통 손님:', JSON.stringify(pLoud)); console.log('   작고 느린 손님:', JSON.stringify(pQuiet));
 ok('보통 크기·빠르기 손님 → v8.8 기본값 그대로(시작 0.012, 끝 쉼 750ms, Whisper 7초)', pLoud.p.startRms>=0.012 && pLoud.p.endSilMs===750 && pLoud.p.keepAudioMs===7000, pLoud.p);
 ok('작고 느린 손님 → 시작 기준↓, 끝 쉼 시간↑, Whisper로 보내는 길이↑', pQuiet.p.startRms<0.012 && pQuiet.p.endSilMs>=1000 && pQuiet.p.keepAudioMs>7000, pQuiet.p);
 ok('말 속도·목소리 높이 측정 (느린 손님 음절/초 < 보통 손님, F0 130Hz/200Hz 근처)', pQuiet.s.rate>0 && pQuiet.s.rate<pLoud.s.rate && Math.abs(pQuiet.s.f0Med-130)<12 && Math.abs(pLoud.s.f0Med-200)<20, {quiet:[pQuiet.s.rate,pQuiet.s.f0Med],loud:[pLoud.s.rate,pLoud.s.f0Med]});

 // ---------- 3) 주문 완료 → 메뉴 단어 숫자 학습 → 헷갈리는 후보에서 동점 깨기 ----------
 await k.ev(()=>{__kioskAcoustic.reset();__kioskAcoustic._only('test');});
 const SOGOGI={amp:0.02,f0:130,syl:330,n:5,gap:160};
 for(let i=0;i<3;i++){
   await k.ev(o=>__synth(o),SOGOGI); await k.ev(()=>__kioskAcoustic.onText('소고기국밥'));
   if(i===0){ await k.ev(()=>{ orderState.items=[{item:'소고기국밥',count:1,price:9000}]; try{ transitionTo('done', function(){}); }catch(e){} }); } // 실제 '주문 완료' 화면 전환으로 확정
   else await k.ev(()=>__kioskAcoustic.confirmWords(['소고기국밥']));
   await W(200);
 }
 const prof=await k.ev(()=>__kioskAcoustic.profile());
 ok('주문 완료(done) 3번 → 메뉴 단어별 숫자만 저장(n·음절당 ms·dB·F0·높이 구간)', prof.words['소고기국밥']&&prof.words['소고기국밥'].n===3, prof.words);
 await k.ev(o=>__synth(o),SOGOGI);
 const rk=await k.ev(()=>{ const out=__kioskAcoustic.rank(['순대국밥','소고기국밥'],()=>true); return {out,info:__kioskAcoustic.lastRank}; });
 ok('Web Speech 1순위 "순대국밥" vs 2순위 "소고기국밥" → 말 길이·학습값으로 "소고기국밥" 선택', rk.out[0]==='소고기국밥', rk);
 const rk2=await k.ev(()=>__kioskAcoustic.rank(['콜라','사이다'],()=>true));
 ok('학습 근거 없는 후보끼리는 순서 그대로(기존 동작 유지)', rk2[0]==='콜라', rk2);
 // 실제 인식 경로(onresult)에서도 적용되는지: 주문 받는 화면에서 후보 2개를 줌
 await k.ev(()=>__serialPush && __serialPush('WAKE_BUTTON')).catch(()=>{});
 await k.ev(()=>{ try{ orderState.items=[]; resetTempItemOnly(); transitionTo('open_order_prompt', typeof renderOpenOrderPrompt==='function'?renderOpenOrderPrompt:()=>{}); }catch(e){} });
 await W(2500); await k.ev(o=>__synth(o),SOGOGI);
 await k.ev(()=>__say('순대국밥',['소고기국밥'])); await W(2500);
 const ti=await k.ev(()=>({i:(typeof tempItem!=='undefined'&&tempItem)?tempItem.item:null, st:currentStageName, lr:__kioskAcoustic.lastRank}));
 ok('실제 인식 경로(onresult)에서 동점 깨기 적용 → 소고기국밥 주문 진행', ti.i==='소고기국밥', ti);

 // ---------- 4) 저장 내용: 숫자만, 녹음 없음 / 재시작 뒤에도 남음 / 지우기 ----------
 await W(2500);
 const stored=await k.ev(()=>__kioskAcoustic.stored());
 const srv=await (await fetch(BASE+'api/acoustic-profile')).json();
 const walk=(o,bad,path='')=>{ for(const [kk,v] of Object.entries(o)){ if(v&&typeof v==='object'){ if(Array.isArray(v)) bad.push(path+kk+':array'); else walk(v,bad,path+kk+'.'); } else if(typeof v!=='number' && !(kk==='updated'&&/^\d{4}-\d\d-\d\d$/.test(v)) && !(kk==='updated'&&v==='')) bad.push(path+kk+':'+typeof v); } return bad; };
 const badL=walk(JSON.parse(stored||'{}'),[]), badS=walk(srv,[]);
 console.log('   저장 예시(localStorage):', stored);
 ok('저장된 값은 숫자뿐 (배열·문자열·오디오 없음), 크기 2KB 미만', stored && stored.length<2048 && !badL.length && !/data:|base64|RIFF|webm/i.test(stored), {len:stored&&stored.length,badL});
 ok('서버 사본(kiosk_v8_data/acoustic_profile.json)도 숫자뿐', srv.words && srv.words['소고기국밥'] && !badS.length, {badS, words:Object.keys(srv.words)});
 const idb=await k.ev(async()=>{ const out=[]; const dbs=indexedDB.databases?await indexedDB.databases():[]; for(const d of dbs){ const db=await new Promise((r,j)=>{const q=indexedDB.open(d.name);q.onsuccess=()=>r(q.result);q.onerror=j;}); for(const st of db.objectStoreNames){ const n=await new Promise(r=>{const tx=db.transaction(st,'readonly');const q=tx.objectStore(st).getAll();q.onsuccess=()=>r(q.result.filter(v=>v&&Object.values(v).some(x=>x instanceof Blob)).length);q.onerror=()=>r(-1);}); out.push(d.name+'/'+st+':'+n);} db.close(); } return out; });
 ok('브라우저 IndexedDB에 저장된 소리(Blob) 0개', idb.every(x=>/:0$/.test(x)), idb);
 await k.p.reload({waitUntil:'load'}); await W(2500);
 const after=await k.ev(()=>__kioskAcoustic.profile());
 ok('다시 켜도(새로고침) 학습한 숫자가 남아 있음', after.words['소고기국밥']&&after.words['소고기국밥'].n>=3, after.words['소고기국밥']);
 await k.ev(()=>__kioskAcoustic.reset()); await W(800);
 const srv2=await (await fetch(BASE+'api/acoustic-profile')).json(); const st2=await k.ev(()=>__kioskAcoustic.stored());
 ok('지우기(reset) → localStorage·서버 파일 모두 비워짐', !st2 && Object.keys(srv2.words).length===0, {st2, srv2:srv2.words});
 ok('페이지 오류 없음', !k.logs.length, k.logs.slice(0,3));
 await k.b.close();

 // ---------- 5) 오프라인(Whisper 전용) 듣기에서 작은 목소리가 실제로 잡히는지: v8.8 vs v8.9 ----------
 const countPosts=f=>fs.existsSync(f)?(fs.readFileSync(f,'utf8').match(/POST \/transcribe/g)||[]).length:0;
 async function offlineRun(base,log){
   // 인터넷 끊김 흉내(network 오류 3번, test_offline.js와 같은 방법) → Whisper 전용 듣기 모드
   const kk=await launch(base,'kiosk','/tmp/quiet_slow.wav');
   await kk.ev(()=>{ try{__kioskAcoustic&&__kioskAcoustic.reset();}catch(e){} document.getElementById('boot-btn').click();}); await W(3500); await kk.ev(()=>__serialPush('WAKE_BUTTON')); await W(4000);
   const fire=()=>kk.ev(()=>{ const r=window.__recs.filter(x=>x._running&&!x.__kioskProbe).pop(); if(!r) return 'none'; const e=new Event('error'); e.error='network'; r.dispatchEvent(e); r._running=false; r.dispatchEvent(new Event('end')); return 'ok'; });
   for(let i=0;i<60;i++){ if(await kk.ev(()=>__kioskV8.whisperOnly.on)) break; await fire(); await W(500); }
   const wo=await kk.ev(()=>__kioskV8.whisperOnly.on);
   const c0=countPosts(log); await W(20000); const n=countPosts(log)-c0;
   const p=await kk.ev(()=>window.__kioskAcoustic?__kioskAcoustic.params():null); await kk.b.close(); return {wo,posts:n,params:p};
 }
 if (BASE88 && process.env.SRVLOG88) {
   const o88=await offlineRun(BASE88,process.env.SRVLOG88), o89=await offlineRun(BASE,process.env.SRVLOG||'/tmp/srv89_run.log');
   console.log('   오프라인 20초 동안 Whisper로 보낸 말 조각 수: v8.8 =',o88.posts,' v8.9 =',o89.posts, JSON.stringify(o89.params));
   ok('오프라인(Whisper 전용) 듣기: v8.9도 작은 목소리 말 구간을 잡아서 Whisper로 보냄 (v8.8 숫자는 비교용)', o89.wo && o89.posts>=1, {v88:o88,v89:o89});
 }
 console.log('결과: '+res.filter(Boolean).length+'/'+res.length);
 process.exit(0);
})().catch(e=>{console.error(e);process.exit(1);});
