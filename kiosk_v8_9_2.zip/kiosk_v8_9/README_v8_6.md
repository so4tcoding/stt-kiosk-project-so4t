# v8.6 (v8.5 기반, 기능 삭제 없음)
- '오프라인 모드' 원인 기록: 들어갈 때 콘솔 `[V86 OFFLINE_ON] <원인>` + POST /api/use-metrics (use_metrics.jsonl 에 type=v86_offline_on, reason)
- 60초 복귀 시험: 렉으로 시작 못 한 시험을 '복귀 성공'으로 착각해 오프라인↔하이브리드가 깜빡이던 문제 방지
- 배지 문구: "📴 오프라인 모드 (기기 음성인식으로 정상 동작)"
