#!/bin/bash
# [V8.8] 파이 렉 원인 점검 (키오스크가 켜진 상태에서):  bash ~/kiosk_project/pi/lag_check.sh
#   계속 보기:  watch -n 2 bash ~/kiosk_project/pi/lag_check.sh
echo "===== $(date '+%F %T') 라즈베리파이 렉 점검 ====="

if command -v vcgencmd >/dev/null 2>&1; then
  echo "[온도] $(vcgencmd measure_temp)   (80도 넘으면 느려짐 → 방열판/팬)"
  T=$(vcgencmd get_throttled | cut -d= -f2)
  echo "[전원·발열 제한] get_throttled=$T"
  V=$((T))
  [ $((V & 0x1)) -ne 0 ]     && echo "  ⚠ 지금 전압 부족! → 정품 5V 3A 어댑터(USB-C)로 바꾸세요"
  [ $((V & 0x2)) -ne 0 ]     && echo "  ⚠ 지금 CPU 속도 제한 중"
  [ $((V & 0x4)) -ne 0 ]     && echo "  ⚠ 지금 발열로 속도 제한 중 → 방열판/팬"
  [ $((V & 0x8)) -ne 0 ]     && echo "  ⚠ 지금 온도 한계(soft temp limit)"
  [ $((V & 0x10000)) -ne 0 ] && echo "  · 켠 뒤로 전압 부족이 한 번 이상 있었음 (랜덤 렉의 흔한 원인)"
  [ $((V & 0x20000)) -ne 0 ] && echo "  · 켠 뒤로 CPU 속도 제한이 있었음"
  [ $((V & 0x40000)) -ne 0 ] && echo "  · 켠 뒤로 발열 제한이 있었음"
  [ "$V" -eq 0 ] && echo "  ✓ 전원·발열 문제 없음"
  echo "[CPU 속도] $(vcgencmd measure_clock arm | awk -F= '{printf "%d MHz", $2/1000000}')"
else
  echo "vcgencmd 없음 (라즈베리파이가 아니거나 패키지 없음)"
fi

G=/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
[ -f $G ] && echo "[CPU 모드] $(cat $G)   (performance 권장: README_v8_4 의 cpu-performance.service)"
echo "[부하] $(cut -d' ' -f1-3 /proc/loadavg)  (1분/5분/15분 평균, 코어 4개라 4 넘으면 과부하)"
free -m | awk '/Mem:/{printf "[메모리] 사용 %d MB / 전체 %d MB\n",$3,$2} /Swap:/{printf "[스왑] 사용 %d MB / 전체 %d MB\n",$3,$2}'
echo "[디스크] $(df -h / | awk 'NR==2{print $3" 사용 / "$2" ("$5")"}')"

echo "[서버] $(curl -s -m 2 http://localhost:8000/ || echo '응답 없음')"
echo "[CPU 많이 쓰는 프로그램 TOP 8]"
ps -eo pid,pcpu,pmem,ni,comm --sort=-pcpu | head -9
echo "[최근 서버 기록]"
journalctl -u kiosk-stt -n 5 --no-pager 2>/dev/null | cut -c1-160
