#!/bin/bash
# [V8.9.2] __V892__ 재부팅 때 와이파이 연결이 끝날 때까지 화면을 기다리지 않게 한다.
# 키오스크는 이 기기 주소(localhost)로 뜨고, 저장해 둔 와이파이는 뒤에서 붙는다.
# 와이파이 절전을 끄면 붙는 시간이 줄고, 붙은 뒤 화면이 끊기는 일도 줄어든다.
set +e
if [ "$(id -u)" -ne 0 ]; then
  if sudo -n true 2>/dev/null; then
    exec sudo -n bash "$0" "$@"
  else
    exec sudo bash "$0" "$@"
  fi
fi
systemctl disable NetworkManager-wait-online.service >/dev/null 2>&1
systemctl disable systemd-networkd-wait-online.service >/dev/null 2>&1
if command -v raspi-config >/dev/null 2>&1; then
  raspi-config nonint do_boot_wait 1
fi
mkdir -p /etc/NetworkManager/conf.d
cat > /etc/NetworkManager/conf.d/wifi-powersave-off.conf << 'EOF'
[connection]
wifi.powersave = 2
EOF
if command -v iw >/dev/null 2>&1; then
  iw dev wlan0 set power_save off
fi
if command -v nmcli >/dev/null 2>&1; then
  nmcli general reload >/dev/null 2>&1
  nmcli radio wifi on >/dev/null 2>&1
fi
echo "wifi: 부팅 대기 끔, 절전 끔"
exit 0
