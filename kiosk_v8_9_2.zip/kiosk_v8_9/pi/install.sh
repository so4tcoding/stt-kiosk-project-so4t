#!/bin/bash
# so4t 키오스크 자동 시작 설치 (라즈베리파이에서 so4t 사용자로 실행:  bash ~/kiosk_project/pi/install.sh)
set -e
PROJ="/home/so4t/kiosk_project"
if [ "$(id -un)" != "so4t" ]; then echo "so4t 사용자로 실행하세요 (sudo 없이)."; exit 1; fi
cd "$PROJ"

echo "[1/7] 필요한 프로그램 (sudo 비밀번호를 물을 수 있음)"
sudo apt-get update -y
sudo apt-get install -y python3-venv curl wlr-randr speech-dispatcher espeak-ng chromium || \
sudo apt-get install -y python3-venv curl wlr-randr speech-dispatcher espeak-ng chromium-browser

echo "[2/7] 파이썬 가상환경 (이미 있으면 그대로 사용)"
if [ ! -x "$PROJ/venv/bin/python" ]; then python3 -m venv "$PROJ/venv"; fi
"$PROJ/venv/bin/pip" install --upgrade pip
"$PROJ/venv/bin/pip" install fastapi "uvicorn[standard]" python-multipart faster-whisper

echo "[3/7] 서버 서비스 등록 (kiosk-stt.service, Restart=always)"
sudo cp "$PROJ/pi/kiosk-stt.service" /etc/systemd/system/kiosk-stt.service
sudo systemctl daemon-reload
sudo systemctl enable kiosk-stt.service
sudo systemctl restart kiosk-stt.service

echo "[4/7] 실행 권한"
chmod +x "$PROJ/pi/kiosk_launcher.sh"

echo "[5/7] 데스크톱 자동 실행"
mkdir -p "$HOME/.config/labwc"
LINE="$PROJ/pi/kiosk_launcher.sh &"
touch "$HOME/.config/labwc/autostart"
grep -qF "$PROJ/pi/kiosk_launcher.sh" "$HOME/.config/labwc/autostart" || echo "$LINE" >> "$HOME/.config/labwc/autostart"
echo "  labwc: $HOME/.config/labwc/autostart"
if [ -f "$HOME/.config/wayfire.ini" ]; then
  if ! grep -q "so4t_kiosk" "$HOME/.config/wayfire.ini"; then
    cp "$HOME/.config/wayfire.ini" "$HOME/.config/wayfire.ini.bak_so4t"
    if grep -q "^\[autostart\]" "$HOME/.config/wayfire.ini"; then
      sed -i "/^\[autostart\]/a so4t_kiosk = $PROJ/pi/kiosk_launcher.sh" "$HOME/.config/wayfire.ini"
    else
      printf "\n[autostart]\nso4t_kiosk = %s\n" "$PROJ/pi/kiosk_launcher.sh" >> "$HOME/.config/wayfire.ini"
    fi
    echo "  wayfire: $HOME/.config/wayfire.ini (백업 wayfire.ini.bak_so4t)"
  fi
fi

echo "[6/7] 부팅이 와이파이 연결을 기다리지 않게"
bash "$PROJ/pi/wifi_fast.sh" || true

echo "[7/7] 확인"
sleep 5
systemctl --no-pager --lines=5 status kiosk-stt.service || true
curl -s -m 5 http://localhost:8000/ && echo || echo "서버가 아직 모델을 불러오는 중일 수 있습니다: journalctl -u kiosk-stt -f"
echo
echo "끝. 자동 로그인(데스크톱)이 켜져 있어야 부팅 때 키오스크 화면이 뜹니다: sudo raspi-config → System Options → Boot / Auto Login → Desktop Autologin"
echo "지금 바로 띄우려면: $PROJ/pi/kiosk_launcher.sh &"
