/*
  [V8.4] 라즈베리파이 4 성능 층 (kiosk_pi.js 다음에 불러온다)
  - kiosk_pi.js의 lite 모드가 켜졌을 때만 동작 (파이 자동 / ?lite=1, 끄기 ?lite=0 또는 localStorage kiosk_perf_off=1)
  - 기능은 지우지 않고 "횟수·속도"만 줄인다
  1) 화면 그리기(requestAnimationFrame): 평소 초당 15번, TTS 말하는 중·절전 중·탭 숨김일 땐 초당 4번
  2) 마이크 파형 분석(AnalyserNode): TTS 중·절전 중에는 최근 값을 재사용(분석 쉬기)
  3) Web Speech(1차 인식) 오류 시 재시작 간격을 1→2→4→…→30초로 늘림(Error -2 폭주 방지).
     연속 실패 3회면 window.__webSpeechDegraded=true (Whisper가 계속 처리), 30초마다 1차 인식 재시도.
     성공(result)하면 바로 원래대로 돌아감. 하이브리드 구조는 그대로.
  4) 1초 미만 setInterval은 TTS 중·절전 중에 한 번씩 건너뜀(타이머 자체는 살아 있음)
  5) console.warn 폭주 제한(같은 메시지 초당 1회)
*/
(function () {
    "use strict";
    var W = window;
    if (W.__kioskPerfInstalled) return;
    W.__kioskPerfInstalled = true;
    try { if (localStorage.getItem("kiosk_perf_off") === "1") return; } catch (e) {}
    if (!W.__kioskLite) return;

    function ttsBusy() { try { return !!(W.speechSynthesis && W.speechSynthesis.speaking); } catch (e) { return false; } }
    function sleeping() {
        var b = document.body; if (!b) return false;
        var c = b.classList;
        return c.contains("sleep-mode") || c.contains("sleep-final-mode") || c.contains("simple-sleep-mode") || c.contains("button-sleep-mode"); // [V8.8] 실제 쓰는 버튼 절전도 포함
    }
    function quiet() { return document.hidden || ttsBusy() || sleeping(); }
    W.__kioskPerfQuiet = quiet;

    /* 1) rAF 간격: 평소 초당 15번, 조용할 때(TTS·절전·숨김) 초당 4번
       [V8.8] 예전엔 kiosk_pi.js의 제한 위에 한 겹 더 감싸서(이중 제한) 헛도는 재요청이 곱절로 늘었다.
       이제는 kiosk_pi.js의 묶음 스케줄러 간격만 바꾼다. __V88__ */
    if (W.__kioskRafSched) {
        W.__kioskRafSched.frameMs = function () { return quiet() ? 250 : 1000 / 15; };
    }

    /* 2) 분석기 쉬기 */
    try {
        var AP = W.AnalyserNode && W.AnalyserNode.prototype;
        ["getByteTimeDomainData", "getFloatTimeDomainData", "getByteFrequencyData", "getFloatFrequencyData"].forEach(function (name) {
            if (!AP || !AP[name]) return;
            var orig = AP[name];
            AP[name] = function (arr) {
                var key = "__v84_" + name;
                if (quiet() && this[key] && this[key].length === arr.length) { arr.set(this[key]); return; }
                orig.call(this, arr);
                try { this[key] = arr.slice(0); } catch (e) {}
            };
        });
    } catch (e) {}

    /* 3) Web Speech 재시작 지수 백오프 */
    try {
        var SR = W.SpeechRecognition || W.webkitSpeechRecognition;
        if (SR && SR.prototype && !SR.prototype.__v84) {
            var P = SR.prototype, oStart = P.start, oStop = P.stop, oAbort = P.abort;
            var fails = 0, nextOk = 0;
            function delay() { return fails <= 0 ? 0 : Math.min(30000, 1000 * Math.pow(2, fails - 1)); }
            function hook(r) {
                if (r.__v84h) return; r.__v84h = true;
                r.addEventListener("error", function (ev) {
                    var er = ev && ev.error;
                    if (er === "no-speech" || er === "aborted") return; // 정상적인 상황
                    fails++; nextOk = Date.now() + delay();
                    if (fails >= 3) W.__webSpeechDegraded = true;
                });
                r.addEventListener("result", function () { fails = 0; nextOk = 0; W.__webSpeechDegraded = false; });
            }
            P.start = function () {
                var r = this; hook(r);
                if (r.__v84t) { clearTimeout(r.__v84t); r.__v84t = null; }
                var wait = nextOk - Date.now();
                if (wait > 0) {
                    r.__v84t = setTimeout(function () {
                        r.__v84t = null;
                        try { oStart.call(r); } catch (e) {}
                    }, wait);
                    return;
                }
                return oStart.apply(r, arguments);
            };
            P.stop = function () { if (this.__v84t) { clearTimeout(this.__v84t); this.__v84t = null; } return oStop.apply(this, arguments); };
            P.abort = function () { if (this.__v84t) { clearTimeout(this.__v84t); this.__v84t = null; } return oAbort.apply(this, arguments); };
            P.__v84 = true;
        }
    } catch (e) {}

    /* 4) 짧은 타이머는 조용할 때 한 번씩 건너뛰기 */
    var baseSI = W.setInterval;
    W.setInterval = function (fn, ms) {
        var n = Number(ms) || 0;
        if (typeof fn !== "function" || n >= 1000) return baseSI.apply(W, arguments);
        var extra = Array.prototype.slice.call(arguments, 2), skip = false;
        return baseSI.call(W, function () {
            if (quiet()) { skip = !skip; if (skip) return; }
            return fn.apply(this, extra);
        }, ms);
    };

    /* 5) warn 폭주 제한 */
    try {
        var oWarn = console.warn.bind(console), seen = {};
        console.warn = function () {
            var k = String(arguments[0]).slice(0, 80), now = Date.now();
            if (seen[k] && now - seen[k] < 1000) return;
            seen[k] = now; oWarn.apply(null, arguments);
        };
    } catch (e) {}

    /* 절전 중에는 CSS 애니메이션 일시정지 */
    var css = "html.kiosk-lite body.sleep-final-mode *{animation-play-state:paused !important}" +
        /* [V8.8] __V88__ 버튼 절전(button-sleep-mode) 등 절전 화면에선 뒤에 가려진 로봇(#senior-robot)의 움직임도 쉼.
           시험: 이 움직임만으로 화면 스타일 계산이 초당 60번 일어남(가려져서 안 보이는데도). 절전에서 깨면 다시 움직임 */
        "html.kiosk-lite body.button-sleep-mode #senior-robot:not(#v88x),html.kiosk-lite body.button-sleep-mode #senior-robot:not(#v88x) *,html.kiosk-lite body.button-sleep-mode #senior-robot:not(#v88x) *::after," +
        "html.kiosk-lite body.sleep-mode #senior-robot:not(#v88x),html.kiosk-lite body.sleep-mode #senior-robot:not(#v88x) *,html.kiosk-lite body.sleep-mode #senior-robot:not(#v88x) *::after," +
        "html.kiosk-lite body.simple-sleep-mode #senior-robot:not(#v88x),html.kiosk-lite body.simple-sleep-mode #senior-robot:not(#v88x) *,html.kiosk-lite body.simple-sleep-mode #senior-robot:not(#v88x) *::after" +
        "{animation-play-state:paused !important}";
    try { var st = document.createElement("style"); st.textContent = css; (document.head || document.documentElement).appendChild(st); } catch (e) {}
})();
