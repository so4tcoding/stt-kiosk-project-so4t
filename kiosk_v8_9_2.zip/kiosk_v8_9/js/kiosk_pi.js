/*
  [V8.2] 라즈베리파이용 보정 (다른 스크립트보다 먼저 불러온다)  [V8.8] rAF 제한 방식 수정 __V88__
  1) TTS: 빈 cancel() 무시, cancel 직후 speak는 잠깐 띄워서(끊김·딱 소리 방지), 한국어 목소리 우선
  2) 가벼운 모드(lite): 리눅스 ARM(파이) 자동, 또는 ?lite=1 / 끄기 ?lite=0
     - 무거운 CSS 효과(흐림·그림자·애니메이션) 끄기, 너무 잦은 타이머 늦추기, console.log 줄이기
  기능은 하나도 지우지 않는다. 끄려면 localStorage.setItem("kiosk_pi_off","1")
*/
(function () {
    "use strict";
    var W = window;
    if (W.__kioskPiInstalled) return;
    W.__kioskPiInstalled = true;
    var off = false;
    try { off = localStorage.getItem("kiosk_pi_off") === "1"; } catch (e) {}
    if (off) return;

    var qs = "";
    try { qs = String(location.search || ""); } catch (e) {}
    var ua = String(navigator.userAgent || "") + " " + String(navigator.platform || "");
    var isPi = /Linux/i.test(ua) && /(aarch64|arm)/i.test(ua) && !/Android/i.test(ua);
    var lite = /[?&]lite=1/.test(qs) || (isPi && !/[?&]lite=0/.test(qs));
    // [V8.9] __V89__ 런처가 붙이는 ?pi=1 (파이 크롬이 UA에 aarch64를 안 보여줘도 확실히 파이 모드). kiosk.html 앞부분 판정과 같게 맞춤
    if (typeof W.__kioskPiMode === "boolean") { lite = W.__kioskPiMode; if (lite && /[?&]pi=1/.test(qs)) isPi = true; }
    var debug = /[?&]debug=1/.test(qs);
    W.__kioskLite = lite;
    W.__kioskIsPi = isPi;

    /* ---------------- 1) TTS 끊김 줄이기 ---------------- */
    var ss = W.speechSynthesis;
    if (ss && !ss.__piTtsPatched) {
        var nCancel = ss.cancel.bind(ss);
        var nSpeak = ss.speak.bind(ss);
        var lastCancelAt = 0;
        var pendingTimer = null;
        var GAP = isPi ? 140 : 40; // cancel 뒤 speak까지 쉬는 시간(ms)
        try { var g = parseInt(localStorage.getItem("kiosk_tts_gap_ms") || "", 10); if (g >= 0 && g <= 1000) GAP = g; } catch (e) {}

        function nativeBusy() {
            try {
                var proto = Object.getPrototypeOf(ss);
                return !!(Object.getOwnPropertyDescriptor(proto, "speaking").get.call(ss) || Object.getOwnPropertyDescriptor(proto, "pending").get.call(ss));
            } catch (e) { return true; }
        }
        var koVoice = null;
        function pickVoice() {
            try {
                var vs = ss.getVoices() || [];
                var ko = vs.filter(function (v) { return /^ko/i.test(String(v.lang || "")); });
                koVoice = ko.find(function (v) { return /Google/i.test(v.name); }) ||
                          ko.find(function (v) { return /Yuna|여성|Female|SunHi/i.test(v.name); }) ||
                          ko.find(function (v) { return v.localService; }) || ko[0] || null;
            } catch (e) {}
        }
        pickVoice();
        try { ss.addEventListener("voiceschanged", pickVoice); } catch (e) {}

        ss.cancel = function () {
            if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null; }
            // 아무것도 안 말하고 있는데 cancel을 보내면 speech-dispatcher가 멈춤/재시작을 반복해 '딱' 소리와 끊김이 난다
            if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null; }
            if (!nativeBusy()) return;
            lastCancelAt = Date.now();
            return nCancel();
        };
        ss.speak = function (u) {
            try {
                if (u && (!u.voice || !/^ko/i.test(String(u.voice.lang || "")))) {
                    if (!koVoice) pickVoice();
                    if (koVoice) u.voice = koVoice;
                }
                if (u && !u.lang) u.lang = "ko-KR";
            } catch (e) {}
            var since = Date.now() - lastCancelAt;
            if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null; }
            if (since < GAP) {
                // cancel 직후 바로 speak하면 오디오 장치가 닫혔다 열리며 버벅임. 잠깐 쉬었다가 말한다.
                pendingTimer = setTimeout(function () { pendingTimer = null; nSpeak(u); }, GAP - since);
                return;
            }
            return nSpeak(u);
        };
        // 잠깐 쉬는 동안에도 '말하는 중'으로 보이게 해서 마이크가 그 틈에 켜지지 않게 한다
        try {
            var proto = Object.getPrototypeOf(ss);
            var dS = Object.getOwnPropertyDescriptor(proto, "speaking");
            var dP = Object.getOwnPropertyDescriptor(proto, "pending");
            if (dS && dS.get) Object.defineProperty(ss, "speaking", { configurable: true, get: function () { return !!pendingTimer || dS.get.call(ss); } });
            if (dP && dP.get) Object.defineProperty(ss, "pending", { configurable: true, get: function () { return !!pendingTimer || dP.get.call(ss); } });
        } catch (e) {}
        ss.__piTtsPatched = true;
    }

    if (!lite) return;

    /* ---------------- 2) 가벼운 모드 ---------------- */
    // 2-1) console.log 줄이기 (warn/error는 그대로)
    if (!debug) {
        try {
            var noop = function () {};
            console.log = noop; console.debug = noop; console.info = noop;
        } catch (e) {}
    }

    // 2-2) 너무 잦은 setInterval 늦추기 (250ms 미만 → 250ms). 동작은 같고 횟수만 줄어든다.
    var MIN_IV = 250;
    var nSetInterval = W.setInterval;
    W.setInterval = function (fn, ms) {
        var args = Array.prototype.slice.call(arguments);
        var n = Number(ms) || 0;
        if (n < MIN_IV) args[1] = MIN_IV;
        return nSetInterval.apply(W, args);
    };

    // 2-3) requestAnimationFrame을 초당 약 20번으로 제한
    // [V8.8] 예전 방식은 모든 그리기 반복이 '마지막 시각' 하나를 같이 써서, 반복이 여러 개면 하나만 그려지고
    //        나머지는 매 프레임 헛돌며(재요청) CPU를 먹었다(시험: 절전·주문 반복 뒤 초당 469→4,977번 호출).
    //        이제는 기다리는 콜백을 모아 두었다가 정해진 간격마다 한 번에 모두 실행한다(진짜 rAF와 같은 방식).
    //        반복이 몇 개든 실제 rAF 요청은 프레임당 최대 1번. cancelAnimationFrame도 지원.
    var nRAF = W.requestAnimationFrame && W.requestAnimationFrame.bind(W);
    var nCAF = W.cancelAnimationFrame && W.cancelAnimationFrame.bind(W);
    if (nRAF) {
        var sched = { frameMs: function () { return 1000 / 20; }, q: [], seq: 1000000, pending: false, last: 0 };
        var request = function () {
            if (sched.pending) return;
            sched.pending = true;
            var wait = 0;
            try { wait = sched.frameMs() - (performance.now() - sched.last) - 17; } catch (e) {}
            if (wait > 4) setTimeout(function () { nRAF(pump); }, wait);   // 기다릴 시간이 길면 프레임마다 깨지 않고 잠깐 쉼
            else nRAF(pump);
        };
        var pump = function (t) {
            sched.pending = false;
            if (!sched.q.length) return;
            var fm = 50;
            try { fm = sched.frameMs(); } catch (e) {}
            if (t - sched.last < fm - 3) { request(); return; }
            sched.last = t;
            var list = sched.q; sched.q = [];
            for (var i = 0; i < list.length; i++) {
                var it = list[i];
                if (it.c) continue;
                try { it.cb(t); } catch (err) { setTimeout(function () { throw err; }, 0); }
            }
        };
        W.requestAnimationFrame = function (cb) {
            var id = ++sched.seq;
            sched.q.push({ id: id, cb: cb, c: false });
            request();
            return id;
        };
        W.cancelAnimationFrame = function (id) {
            for (var i = 0; i < sched.q.length; i++) if (sched.q[i].id === id) { sched.q[i].c = true; return; }
            if (nCAF && id < 1000000) try { nCAF(id); } catch (e) {}
        };
        W.__kioskRafSched = sched;   // kiosk_pi_perf.js가 간격(frameMs)만 바꾼다
    }

    // 2-4) 무거운 CSS 효과 끄기
    var css = [
        "html.kiosk-lite *, html.kiosk-lite *::before, html.kiosk-lite *::after {",
        "  backdrop-filter: none !important; -webkit-backdrop-filter: none !important;",
        "  filter: none !important; box-shadow: none !important; text-shadow: none !important;",
        "  animation-duration: 0.001s !important; animation-iteration-count: 1 !important;",
        "  transition-duration: 0.08s !important; scroll-behavior: auto !important; }",
        "html.kiosk-lite .arrow-indicator { animation: none !important; }",
        "html.kiosk-lite #boot-overlay { background: rgba(61,47,31,.96) !important; }",
        "html.kiosk-lite #boot-overlay p { display: none !important; }"
    ].join("\n");
    function addCss() {
        try {
            document.documentElement.classList.add("kiosk-lite");
            if (document.getElementById("kiosk-lite-css")) return;
            var st = document.createElement("style");
            st.id = "kiosk-lite-css";
            st.textContent = css;
            (document.head || document.documentElement).appendChild(st);
        } catch (e) {}
    }
    addCss();
    document.addEventListener("DOMContentLoaded", addCss);
})();

/* 첫 한 번 누르기: 버튼이 아니라 화면 어디를 눌러도 시작 (브라우저 소리·마이크 규칙 때문에 한 번은 필요) */
(function () {
    function hook() {
        var ov = document.getElementById("boot-overlay");
        var btn = document.getElementById("boot-btn");
        if (!ov || !btn || ov.__piTap) return;
        ov.__piTap = true;
        ov.addEventListener("click", function (e) {
            if (e.target === btn || btn.contains(e.target)) return;
            try { btn.click(); } catch (err) {}
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", hook);
    else hook();
})();
