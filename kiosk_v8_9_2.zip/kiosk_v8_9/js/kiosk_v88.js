/*
  [V8.8] 처음 켤 때 '음성 인식 준비 중' 표시 (__V88__)
  - 서버가 Whisper 모델을 뒤에서 불러오는 동안 첫 화면(시작하기) 아래에 진행 상황을 보여 준다.
  - 서버 / (상태 확인)의 model_ready 를 2초마다 확인, 준비되면 멈춤. 기능 변화 없음(표시만).
*/
(function () {
    "use strict";
    var W = window;
    if (W.__kioskV88Installed) return;
    W.__kioskV88Installed = true;
    var t0 = Date.now(), tries = 0;
    function set(txt, done) {
        var el = document.getElementById("v88-boot-status");
        if (el) { el.textContent = txt; if (done) el.style.color = "#bfe7c4"; }
    }
    function poll() {
        tries++;
        fetch("/", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (j) {
            W.__kioskServerState = j;
            if (j && j.model_error) { set("기기 음성 인식(Whisper) 준비 실패 — 인터넷 음성 인식으로 계속 동작해요", true); return; }
            if (j && j.model_ready === false) {
                set("음성 인식 준비 중… " + Math.round((Date.now() - t0) / 1000) + "초");
                setTimeout(poll, 2000);
                return;
            }
            W.__v88WhisperReady = true;
            set("준비 완료 ✓", true);
        }).catch(function () {
            set("서버 연결 기다리는 중…");
            if (tries < 600) setTimeout(poll, 2000);
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", poll);
    else poll();
})();
