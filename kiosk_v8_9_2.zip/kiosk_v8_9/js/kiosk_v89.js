/*
  [V8.9] 라즈베리파이 렉 줄이기 - 파이 모드 도우미 (__V89__)
  - 파이 모드: 파이 자동 감지(UA/platform에 aarch64·Linux arm) 또는 주소에 ?pi=1 (런처가 붙임) / ?lite=1
      끄기: ?pi=0  또는 localStorage.setItem("kiosk_pi_mode","0")   강제로 켜기: localStorage.setItem("kiosk_pi_mode","1")
  - 파이 모드에서만: 3D(three.js, 600KB)를 아예 불러오지 않고, 같은 효과를 가벼운 2D로 그린다.
      · 토핑 떨어지는 효과 → 2D 동그라미가 컵으로 떨어짐 (떨어지는 동안만 그림, 끝나면 그림판 비움)
      · 절전 화면 3D 로봇 → 같은 모양 2D 로봇을 한 번만 그림 (움직임 없음)
  - 노트북(파이 아님)에서는 예전과 똑같이 3D를 쓴다. 기능은 하나도 지우지 않는다.
*/
(function () {
    "use strict";
    var W = window;
    if (W.__kioskV89) return;
    var V = W.__kioskV89 = {};

    // ---- 2D 토핑 효과 (3D와 같은 좌표계: x -225~225, y -400~400) ----
    var T = null;
    function init2D() {
        if (T) return T;
        var cv = document.getElementById("three-canvas");
        if (!cv) return null;
        T = { cv: cv, ctx: null, parts: [], loop: false, last: 0 };
        return T;
    }
    function hex(c) { var s = (c >>> 0).toString(16); while (s.length < 6) s = "0" + s; return "#" + s; }
    function frame(t) {
        if (!T) return;
        var dt = T.last ? Math.min(4, (t - T.last) / (1000 / 60)) : 1;   // 초당 그리는 횟수가 적어도 같은 속도로 떨어짐
        T.last = t;
        var ctx = T.ctx, w = T.cv.width, h = T.cv.height;
        ctx.clearRect(0, 0, w, h);
        var sx = w / 450, sy = h / 800;
        for (var i = T.parts.length - 1; i >= 0; i--) {
            var p = T.parts[i];
            if (p.y > p.ty) { p.y = Math.max(p.ty, p.y + p.vy * dt); }
            else { p.life -= 4 * dt; }
            if (p.life <= 0) { T.parts.splice(i, 1); continue; }
            ctx.globalAlpha = Math.max(0, Math.min(1, p.life / 60));
            ctx.fillStyle = p.c;
            ctx.beginPath();
            ctx.arc((p.x + 225) * sx, (400 - p.y) * sy, Math.max(1.5, p.r * sx), 0, 6.2832);
            ctx.fill();
        }
        ctx.globalAlpha = 1;
        if (T.parts.length) requestAnimationFrame(frame);
        else { T.loop = false; T.last = 0; ctx.clearRect(0, 0, w, h); T.cv.width = 1; T.cv.height = 1; } // 다 떨어지면 그림판을 비우고 작게
    }
    V.use2D = function () { return !!W.__kioskPiMode || typeof W.THREE === "undefined"; };
    V.initTopping2D = function () { init2D(); };
    V.spawnTopping2D = function (color, level) {
        if (!init2D()) return 0;
        var count = Math.max(0, (level - 1) * 4);
        if (!count) return 0;
        if (!T.loop) {
            var r = T.cv.getBoundingClientRect();
            T.cv.width = Math.max(1, Math.round(r.width || T.cv.clientWidth || 450));
            T.cv.height = Math.max(1, Math.round(r.height || T.cv.clientHeight || 800));
            T.ctx = T.cv.getContext("2d");
        }
        var c = hex(color);
        for (var i = 0; i < count; i++) {
            T.parts.push({ x: (Math.random() - 0.5) * 70, y: 260 + Math.random() * 60, vy: -(6 + Math.random() * 4),
                ty: -190 + (Math.random() - 0.5) * 40, life: 60, r: 3 + Math.random() * 2.5, c: c });
        }
        if (!T.loop) { T.loop = true; requestAnimationFrame(frame); }
        return count;
    };
    V.toppingState = function () { return T ? { active: T.parts.length, loop: T.loop } : { active: 0, loop: false }; };

    // ---- 2D 절전 로봇 (3D 로봇과 같은 색·모양, 한 번만 그림) ----
    function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function dot(ctx, x, y, r, c) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill(); }
    V.drawRobot2D = function (canvas) {
        if (!canvas || canvas.__v89drawn) return false;
        canvas.width = 230; canvas.height = 210;
        var ctx = canvas.getContext("2d"); if (!ctx) return false;
        var cream = "#fff4df", orange = "#f4a261", brown = "#5c3a21", white = "#ffffff", green = "#86efac";
        ctx.strokeStyle = brown; ctx.lineWidth = 3; ctx.lineCap = "round";
        ctx.beginPath(); ctx.moveTo(115, 30); ctx.lineTo(115, 52); ctx.stroke();       // 안테나
        dot(ctx, 115, 24, 8, green);
        ctx.strokeStyle = orange; ctx.lineWidth = 9;                                   // 팔
        ctx.beginPath(); ctx.moveTo(78, 140); ctx.lineTo(56, 168); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(152, 140); ctx.lineTo(174, 168); ctx.stroke();
        ctx.fillStyle = orange; rr(ctx, 76, 122, 78, 56, 14); ctx.fill();                // 몸
        dot(ctx, 115, 148, 8, white);                                                    // 하트 자리
        dot(ctx, 44, 88, 12, orange); dot(ctx, 186, 88, 12, orange);                    // 귀
        ctx.fillStyle = cream; rr(ctx, 46, 52, 138, 80, 22); ctx.fill();                // 머리
        ctx.strokeStyle = "rgba(92,58,33,.25)"; ctx.lineWidth = 2; ctx.stroke();
        dot(ctx, 92, 88, 7, brown); dot(ctx, 138, 88, 7, brown);                         // 눈
        ctx.fillStyle = orange; rr(ctx, 97, 108, 36, 6, 3); ctx.fill();                 // 입
        canvas.__v89drawn = true;
        return true;
    };
    // ---- 파이 모드 CSS: 로봇 등 계속 도는 애니메이션·그림자·흐림을 확실히 끔 ----
    // (v8.8의 lite 규칙은 #senior-robot {... !important} 규칙에 져서 로봇이 계속 움직였음 → 우선순위를 더 높게)
    if (W.__kioskPiMode) {
        var P = "html.kiosk-pi body *:not(#v89a):not(#v89b):not(#v89c)";
        var st = document.createElement("style");
        st.id = "v89-pi-style";
        st.textContent = P + "," + P + "::before," + P + "::after{animation-duration:.001s!important;animation-iteration-count:1!important;animation-delay:0s!important;" +
            "filter:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;box-shadow:none!important;text-shadow:none!important;will-change:auto!important;}" +
            "html.kiosk-pi #three-canvas{will-change:auto!important;}" +
            // 마이크 동그라미: 움직이는 모양 대신 같은 물방울 모양으로 고정, 듣는 중엔 그림자 대신 테두리로 표시
            "html.kiosk-pi .liquid-orb:not(#v89a){border-radius:60% 40% 30% 70%/60% 30% 70% 40%!important;}" +
            "html.kiosk-pi .mic-listening:not(#v89a){outline:5px solid rgba(231,111,81,.45)!important;outline-offset:5px!important;}";
        (document.head || document.documentElement).appendChild(st);
        // 나중에 붙는 <style>들보다 뒤에 있도록 다 읽은 뒤 한 번 더 맨 끝으로
        document.addEventListener("DOMContentLoaded", function () { try { (document.head || document.documentElement).appendChild(st); } catch (e) {} });
    }
})();
