/* ==========================================================================
   KIOSK_SERIAL_BRIDGE_V83 (v8.5 직원호출 재시도 추가 · v8.3 추가 · 기존 Web Serial 코드 삭제 없음)
   - 서버(stt_server.py)가 아두이노(/dev/ttyUSB0 등)를 직접 열고, 버튼 신호를
     /api/button-events(SSE)로 보내준다 → 재부팅 후에도 포트 선택 없이 자동 연결.
   - 처리 방식은 기존 readSerialData와 같다:
       WAKE_BUTTON 등(짧게 누름) → __kioskSleepGate.press (절전일 때만 해제)
       STAFF_CALL(2초 길게)      → __kioskStaffCall("button")
   - 정확히 일치하는 줄만 처리. SLEEP/PERSON_LEFT/리셋 같은 동작은 이 경로로 절대 실행 안 함.
   - 브리지가 연결돼 있으면 Web Serial 포트 선택창을 띄우지 않는다.
   - LED 명령(sendCommandToArduino)은 Web Serial이 없을 때 /api/button-command로 보낸다.
   ========================================================================== */
(function KIOSK_SERIAL_BRIDGE_V83() {
    if (window.__kioskSerialBridge) return;
    const B = { connected: false, port: null, es: null, lastAt: {}, log: [] };
    window.__kioskSerialBridge = B;
    const WAKE = { WAKE_BUTTON: 1, START_BUTTON: 1, BUTTON_PRESSED: 1, TOGGLE_MIC: 1 };

    function setInd(on) {
        try {
            const el = document.getElementById("ind-arduino");
            if (!el) return;
            if (on) { el.classList.add("!border-emerald-500"); el.style.opacity = 1; el.title = "아두이노 연결됨 (서버 " + (B.port || "") + ")"; }
        } catch (e) {}
    }
    function handle(msg) {
        const t = Date.now();
        if (B.lastAt[msg] && t - B.lastAt[msg] < 300) return;   // 중복 방지
        B.lastAt[msg] = t;
        B.log.push({ at: t, msg: msg }); if (B.log.length > 40) B.log.shift();
        console.log("🔌 Arduino(서버):", msg);
        if (msg === "STAFF_CALL") {
            // v8.5: 직원 호출 함수가 아직 준비 안 됐으면 0.5초 간격 6번 재시도, 끝까지 없으면 서버에 직접 기록
            (function tryStaff(n) {
                try {
                    if (typeof window.__kioskStaffCall === "function") { window.__kioskStaffCall("button"); return; }
                } catch (e) { console.warn("[SERIAL_BRIDGE] 직원 호출 실패", e); }
                if (n < 6) { setTimeout(function () { tryStaff(n + 1); }, 500); return; }
                try { fetch("/staff_call", { method: "POST", headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ source: "button", stage: "unknown", items: [], at: new Date().toISOString() }) }).catch(function () {}); } catch (e) {}
            })(0);
            return;
        }
        if (WAKE[msg]) {
            if (window.__kioskSleepGate) { window.__kioskSleepGate.press("bridge:" + msg); return; }
            // 게이트가 없을 때도 절전일 때만 해제 (주문 중에는 아무것도 안 함)
            try {
                const sleeping = (typeof currentStageName !== "undefined" && currentStageName === "sleep") ||
                    (window.__kioskButtonSleep && window.__kioskButtonSleep.isActive());
                if (sleeping && typeof window.exitButtonSleepMode === "function") window.exitButtonSleepMode();
            } catch (e) {}
        }
    }

    // LED 명령: Web Serial이 안 열려 있으면 서버로 보냄 (serialWriter 자리에 대체 writer를 둠)
    const bridgeWriter = {
        __bridge: true,
        write: function (text) {
            const cmd = String(text || "").trim();
            if (!cmd) return Promise.resolve();
            return fetch("/api/button-command", { method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ cmd: cmd }) }).catch(function () {});
        }
    };
    function installWriter() {
        try { if (typeof serialWriter !== "undefined" && !serialWriter) serialWriter = bridgeWriter; } catch (e) {}
    }

    // Web Serial 연결 함수 감싸기: 브리지 연결 중이면 포트 선택창을 띄우지 않음
    try {
        if (typeof connectArduino === "function" && !connectArduino.__bridgeV83) {
            const orig = connectArduino;
            const wrapped = async function () {
                if (B.connected) { installWriter(); setInd(true); return true; }
                return orig.apply(this, arguments);
            };
            wrapped.__bridgeV83 = true;
            connectArduino = wrapped;
            window.connectArduino = wrapped;
        }
    } catch (e) { console.warn("[SERIAL_BRIDGE] connectArduino 감싸기 실패", e); }

    function connect() {
        if (!window.EventSource) return;
        try { if (B.es) B.es.close(); } catch (e) {}
        const es = new EventSource("/api/button-events");
        B.es = es;
        es.addEventListener("status", function (ev) {
            try {
                const d = JSON.parse(ev.data);
                B.connected = !!d.connected; B.port = d.port;
                if (B.connected) { installWriter(); setInd(true); }
            } catch (e) {}
        });
        es.onmessage = function (ev) {
            try { const d = JSON.parse(ev.data); if (d && d.event) handle(String(d.event)); } catch (e) {}
        };
        es.onerror = function () { B.connected = false; };   // EventSource가 자동 재접속
    }
    connect();
    console.log("✅ [SERIAL_BRIDGE_V83] 서버 시리얼 브리지 구독 시작");
})();
