/*
  [V8.9] __V89__ 목소리 특징 맞춤 (개인정보 안전한 음향 적응)
  ─────────────────────────────────────────────────────────────
  · 마이크 소리에서 "숫자 요약"만 계산한다. 녹음 파일·파형·스펙트로그램·사람 구별 정보(성문)는 만들지도 저장하지도 않는다.
      - 소리 크기: RMS → dB(절전 dB 측정기와 같은 기준, +100) 평균·범위(10%~90%)
      - 목소리 높이: 자기상관(autocorrelation)으로 F0(기본 주파수) 중앙값·범위, 말하는 동안에만 1초에 최대 10번
      - 말 길이·말 속도: 한 마디 길이(ms), 인식된 글자 수 ÷ 말한 시간 = 1초당 음절 수, 말 사이 쉼 길이
      - 주변 소음: 말 안 할 때 소리 크기(noise floor)
  · 이 숫자로 인식을 손님에게 맞춘다.
      - 작게 말하는 손님 → '말 시작' 기준 소리 크기를 낮춤 (주변 소음보다는 항상 크게)
      - 천천히/띄엄띄엄 말하는 손님 → '말 끝' 판정 쉼 시간을 늘림, Whisper로 보내는 최근 소리 길이를 늘림
      - 주문이 끝까지 완료되면(결제 완료) 그 주문의 메뉴 이름별로 길이·크기·높이 평균만 기억 →
        다음에 Web Speech 후보가 헷갈릴 때(관련 있는 후보가 여러 개) 살짝 가산점(동점 깨기)
  · 저장: localStorage "kiosk_acoustic_profile_v1" + 서버 kiosk_v8_data/acoustic_profile.json (숫자만, 16KB 이하, 메뉴 단어 최대 60개)
      지우기: __kioskAcoustic.reset()  또는  curl -X DELETE http://localhost:8000/api/acoustic-profile (키오스크 기기에서만)
      끄기: localStorage.setItem("kiosk_acoustic_off","1")  → v8.8과 똑같이 동작
*/
(function () {
    "use strict";
    var W = window;
    if (W.__kioskAcoustic) return;
    var KEY = "kiosk_acoustic_profile_v1", VER = 1, MAX_WORDS = 60, SR = 16000;
    var OFF = false;
    try { OFF = localStorage.getItem("kiosk_acoustic_off") === "1"; } catch (e) {}
    // v8.8 값(맞춤 정보가 없으면 이 값 그대로)
    var DEF = { startRms: 0.012, floorMul: 3.2, startMs: 150, endSilMs: 750, keepAudioMs: 7000 };
    var REF_RATE = 4.5;          // 이보다 느리면 '천천히 말하는 손님'(1초당 음절). 보통 4.5~6
    var A = W.__kioskAcoustic = { version: VER, DEF: DEF };

    function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
    function r1(x) { return Math.round(x * 10) / 10; }
    function r4(x) { return Math.round(x * 10000) / 10000; }
    function toDb(rms) { return Math.max(0, 20 * Math.log10(rms || 1e-6) + 100); }
    function fromDb(db) { return Math.pow(10, (db - 100) / 20); }
    function pct(arr, p) { if (!arr.length) return 0; var s = arr.slice().sort(function (a, b) { return a - b; }); return s[Math.min(s.length - 1, Math.max(0, Math.round((s.length - 1) * p)))]; }
    function syl(t) { var m = String(t || "").match(/[\uAC00-\uD7A3]/g); return m ? m.length : 0; }
    function compact(t) { return String(t || "").replace(/[^\uAC00-\uD7A3A-Za-z0-9]/g, ""); }

    /* ---------------- 저장된 숫자 요약 ---------------- */
    function emptyProfile() { return { v: VER, updated: "", global: { sessions: 0, utterances: 0, dbMean: 0, f0Med: 0, rate: 0, floorDb: 0 }, words: {} }; }
    var P = emptyProfile();
    function sanitize(p) {   // 숫자만 남김 (혹시 다른 값이 들어와도 버림)
        var out = emptyProfile();
        if (!p || typeof p !== "object") return out;
        if (typeof p.updated === "string") out.updated = p.updated.slice(0, 10);
        var g = p.global || {};
        Object.keys(out.global).forEach(function (k) { var v = +g[k]; out.global[k] = isFinite(v) ? v : 0; });
        var ws = p.words || {}, keys = Object.keys(ws).filter(function (k) { return /^[\uAC00-\uD7A3A-Za-z0-9 ]{1,20}$/.test(k); }).slice(0, MAX_WORDS);
        keys.forEach(function (k) {
            var w = ws[k] || {}, o = {};
            ["n", "msPerSyl", "db", "f0", "lo", "mid", "hi"].forEach(function (f) { var v = +w[f]; o[f] = isFinite(v) ? v : 0; });
            if (o.n > 0) out.words[k] = o;
        });
        return out;
    }
    function load() {
        try { var s = localStorage.getItem(KEY); if (s) { P = sanitize(JSON.parse(s)); return true; } } catch (e) {}
        return false;
    }
    var saveTimer = null, serverTimer = null;
    function save(toServer) {
        if (OFF) return;
        P.updated = new Date().toISOString().slice(0, 10);   // 날짜만 (시각·손님 정보 없음)
        try { localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) {}
        if (toServer) {
            clearTimeout(serverTimer);
            serverTimer = setTimeout(function () {
                try { fetch("/api/acoustic-profile", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(P) }).catch(function () {}); } catch (e) {}
            }, 1500);
        }
    }
    function saveSoon() { clearTimeout(saveTimer); saveTimer = setTimeout(function () { save(true); }, 1000); }

    /* ---------------- 지금 손님(세션) 상태: 메모리에만 ---------------- */
    var floor = 0.004;                 // 말 안 할 때 소리 크기(RMS)
    var S = null;                      // 세션 요약
    function newSession() { S = { utt: 0, dbs: [], dbLo: [], dbHi: [], f0s: [], f0Lo: [], f0Hi: [], durs: [], rates: [], pauses: [], lastEndAt: 0, recent: [] }; }
    newSession();
    var U = null;                      // 지금 말하는 한 마디
    var voicedRun = 0, silentRun = 0, lastPitchAt = 0, lastFeedSrc = "", lastFeedAt = 0;
    var lastUtt = null;
    var SESSION_GAP_MS = 90000;        // 90초 동안 말이 없으면 새 손님으로 봄

    function endSession() {
        if (S && S.utt > 0) {
            var g = P.global, n = g.sessions, k = 1 / Math.min(n + 1, 20);   // 최근 20명 정도 평균
            var sm = sessionSummary();
            g.sessions = n + 1; g.utterances += S.utt;
            g.dbMean = r1(n ? g.dbMean + (sm.dbMean - g.dbMean) * k : sm.dbMean);
            if (sm.f0Med) g.f0Med = r1(g.f0Med ? g.f0Med + (sm.f0Med - g.f0Med) * k : sm.f0Med);
            if (sm.rate) g.rate = r1(g.rate ? g.rate + (sm.rate - g.rate) * k : sm.rate);
            g.floorDb = r1(g.floorDb ? g.floorDb + (toDb(floor) - g.floorDb) * k : toDb(floor));
            save(true);
        }
        newSession(); U = null; lastUtt = null; invalidate();
    }
    A.endSession = endSession;

    function sessionSummary() {
        return {
            utterances: S.utt,
            dbMean: r1(S.dbs.length ? S.dbs.reduce(function (a, b) { return a + b; }, 0) / S.dbs.length : 0),
            dbRange: [r1(pct(S.dbLo, 0.5)), r1(pct(S.dbHi, 0.5))],
            f0Med: r1(pct(S.f0s, 0.5)),
            f0Range: [r1(pct(S.f0Lo, 0.5)), r1(pct(S.f0Hi, 0.5))],
            uttMs: Math.round(pct(S.durs, 0.5)),
            rate: r1(pct(S.rates, 0.5)),
            pauseP90Ms: Math.round(pct(S.pauses, 0.9)),
            floorDb: r1(toDb(floor))
        };
    }
    A.session = function () { return sessionSummary(); };

    /* ---------------- 소리 조각 받기 (16kHz, 하이브리드/오프라인 듣기에서 이미 만든 조각을 그대로 받음) ---------------- */
    var SUB = 320;   // 20ms
    function pitchOf(x, off) {     // 8kHz로 줄여 자기상관. 70~400Hz
        var N = 320, d = new Float32Array(N), i, mean = 0;
        if (off + N * 2 > x.length) off = Math.max(0, x.length - N * 2);
        if (x.length < N * 2) return 0;
        for (i = 0; i < N; i++) { d[i] = (x[off + 2 * i] + x[off + 2 * i + 1]) * 0.5; mean += d[i]; }
        mean /= N; var e0 = 0;
        for (i = 0; i < N; i++) { d[i] -= mean; e0 += d[i] * d[i]; }
        if (e0 <= 1e-9) return 0;
        var best = 0, bestLag = 0, minLag = 20, maxLag = 114, rs = [];
        for (var lag = minLag; lag <= maxLag; lag++) {
            var s = 0, e1 = 0, e2 = 0, M = N - lag;
            for (i = 0; i < M; i++) { s += d[i] * d[i + lag]; e1 += d[i] * d[i]; e2 += d[i + lag] * d[i + lag]; }
            var r = s / Math.sqrt(e1 * e2 + 1e-12); rs[lag] = r;
            if (r > best) { best = r; bestLag = lag; }
        }
        if (best < 0.55 || !bestLag) return 0;
        // 배음 실수 줄이기: 절반 주기에도 거의 같은 상관이면 그쪽(높은 F0)
        var half = Math.round(bestLag / 2);
        if (half >= minLag && rs[half] > best * 0.9) bestLag = half;
        var a = rs[bestLag - 1] || 0, b = rs[bestLag], c = rs[bestLag + 1] || 0, den = a - 2 * b + c;
        var lagF = bestLag + (den ? 0.5 * (a - c) / den : 0);
        return 8000 / lagF;
    }

    var onlySrc = "";
    A._only = function (src) { onlySrc = String(src || ""); };   // 시험용
    A.feed = function (x, src) {
        if (OFF || !x || !x.length) return;
        var now = Date.now();
        if (onlySrc && src !== onlySrc) return;                       // (시험용) 한 곳에서 온 소리만
        if (src !== lastFeedSrc && now - lastFeedAt < 300) return;   // 두 곳에서 같은 마이크를 동시에 주면 하나만
        lastFeedSrc = src || ""; lastFeedAt = now;
        if (S.lastEndAt && !U && now - S.lastEndAt > SESSION_GAP_MS) endSession();
        var dtSub = SUB / SR * 1000;
        for (var off = 0; off + SUB <= x.length; off += SUB) {
            var e = 0; for (var i = off; i < off + SUB; i++) e += x[i] * x[i];
            var rms = Math.sqrt(e / SUB);
            var on = rms > Math.max(floor * 2.5, 0.0025);
            if (on) { voicedRun += dtSub; silentRun = 0; } else { silentRun += dtSub; voicedRun = U ? voicedRun : 0; }
            if (!U) {
                if (!on) floor = floor * 0.97 + rms * 0.03;
                if (voicedRun >= 120) { U = { startAt: now - voicedRun, voicedMs: voicedRun, dbH: [], f0: [], pauses: [], curPause: 0 }; }
                continue;
            }
            if (on) {
                U.voicedMs += dtSub; U.dbH.push(toDb(rms));
                if (U.curPause >= 120) U.pauses.push(U.curPause);
                U.curPause = 0;
                if (now - lastPitchAt >= 100) {          // 1초에 최대 10번
                    lastPitchAt = now;
                    var f = pitchOf(x, off);
                    if (f) U.f0.push(f);
                }
            } else {
                U.curPause += dtSub;
                if (U.curPause >= 1200) finishUtt(now);
            }
        }
        if (U && now - U.startAt > 15000) finishUtt(now);
    };

    function finishUtt(now) {
        var u = U; U = null; voicedRun = 0;
        if (!u || u.voicedMs < 200 || u.dbH.length < 5) return;
        var durMs = Math.max(u.voicedMs, (now - u.startAt) - u.curPause);
        var sum = {
            durMs: Math.round(durMs), voicedMs: Math.round(u.voicedMs),
            dbMean: r1(u.dbH.reduce(function (a, b) { return a + b; }, 0) / u.dbH.length),
            dbLo: r1(pct(u.dbH, 0.1)), dbHi: r1(pct(u.dbH, 0.9)),
            f0Med: u.f0.length >= 2 ? r1(pct(u.f0, 0.5)) : 0, f0Lo: u.f0.length >= 2 ? r1(pct(u.f0, 0.1)) : 0, f0Hi: u.f0.length >= 2 ? r1(pct(u.f0, 0.9)) : 0,
            pauseMax: Math.round(u.pauses.length ? Math.max.apply(null, u.pauses) : 0), endAt: now - u.curPause
        };
        S.utt++; S.dbs.push(sum.dbMean); S.dbLo.push(sum.dbLo); S.dbHi.push(sum.dbHi); S.durs.push(sum.durMs);
        if (sum.f0Med) { S.f0s.push(sum.f0Med); S.f0Lo.push(sum.f0Lo); S.f0Hi.push(sum.f0Hi); }
        u.pauses.forEach(function (p) { S.pauses.push(p); });
        ["dbs", "dbLo", "dbHi", "durs", "f0s", "f0Lo", "f0Hi", "pauses", "rates"].forEach(function (k) { if (S[k].length > 30) S[k].splice(0, S[k].length - 30); });
        S.lastEndAt = now;
        lastUtt = sum; invalidate();
        if (pendingText && now - pendingText.at < 4000) { attachText(pendingText.text, sum); pendingText = null; }
    }

    /* ---------------- 인식된 글자와 짝짓기 (말 속도, 메뉴 단어 후보) ---------------- */
    var pendingText = null;
    function attachText(text, sum) {
        var n = syl(text);
        if (n >= 2 && sum.voicedMs >= 300) {
            var rate = n / (sum.durMs / 1000);
            if (rate > 0.8 && rate < 12) S.rates.push(rate);
        }
        S.recent.push({ c: compact(text), n: n, durMs: sum.durMs, db: sum.dbMean, f0: sum.f0Med });
        if (S.recent.length > 20) S.recent.shift();
        invalidate();
    }
    A.onText = function (text) {
        if (OFF || !text) return;
        var now = Date.now();
        if (U) { pendingText = { text: String(text), at: now }; return; }               // 아직 말하는 중 → 끝나면 짝짓기
        if (lastUtt && now - lastUtt.endAt < 4000 && !lastUtt.__used) { lastUtt.__used = true; attachText(text, lastUtt); return; }
        pendingText = { text: String(text), at: now };
    };

    /* ---------------- 맞춤 값 (인식에 쓰는 숫자) ---------------- */
    var pCache = null, pCacheAt = 0;
    A.params = function () {   // 1초 동안은 계산해 둔 값 재사용 (파이 부담 줄이기)
        var now = Date.now();
        if (pCache && now - pCacheAt < 1000) return pCache;
        pCache = calcParams(); pCacheAt = now;
        return pCache;
    };
    function invalidate() { pCache = null; }
    function calcParams() {
        var out = { startRms: Math.max(DEF.startRms, floor * DEF.floorMul), startMs: DEF.startMs, endSilMs: DEF.endSilMs, keepAudioMs: DEF.keepAudioMs, adapted: false, why: [] };
        if (OFF) return out;
        var g = P.global, haveS = S.utt > 0;
        // 1) 작게 말하는 손님: 말 시작 기준을 손님 목소리(작은 쪽 10%)의 절반까지 낮춤. 소음의 2.2배보다는 항상 큼
        if (haveS) {
            var speechLoRms = fromDb(pct(S.dbLo, 0.5));
            var lowered = Math.max(floor * 2.2, 0.004, Math.min(out.startRms, speechLoRms * 0.5));
            if (lowered < out.startRms - 1e-6) { out.startRms = lowered; out.adapted = true; out.why.push("quiet"); }
        }
        // 2) 천천히 말하는 손님: 말 끝 쉼 시간을 늘림 (최대 1.6초). 정보 없으면 지난 손님들 평균을 약하게 반영
        var rate = S.rates.length ? pct(S.rates, 0.5) : 0, w = 1;
        if (!rate && g.rate && g.sessions >= 3) { rate = g.rate; w = 0.5; }
        if (rate) {
            var f = clamp(REF_RATE / rate, 1, 2.2), end = DEF.endSilMs * (1 + (f - 1) * w);
            if (S.pauses.length >= 2) end = Math.max(end, pct(S.pauses, 0.9) * 1.3);
            end = Math.round(clamp(end, DEF.endSilMs, 1600));
            if (end > DEF.endSilMs) { out.endSilMs = end; out.adapted = true; out.why.push("slow"); }
            var keep = Math.round(clamp(DEF.keepAudioMs * (1 + (f - 1) * w * 0.6), DEF.keepAudioMs, 10000));
            if (keep > DEF.keepAudioMs) out.keepAudioMs = keep;
        } else if (S.pauses.length >= 2) {
            var e2 = Math.round(clamp(pct(S.pauses, 0.9) * 1.3, DEF.endSilMs, 1600));
            if (e2 > DEF.endSilMs) { out.endSilMs = e2; out.adapted = true; out.why.push("pauses"); }
        }
        out.startRms = r4(out.startRms);
        return out;
    }

    /* ---------------- 주문 완료 → 메뉴 단어별 숫자 평균 ---------------- */
    function band(f0) { return !f0 ? "" : (f0 < 140 ? "lo" : (f0 <= 220 ? "mid" : "hi")); }
    A.confirmWords = function (names) {
        if (OFF || !names || !names.length) return 0;
        var used = 0;
        names.forEach(function (name) {
            var key = String(name || "").replace(/\s+/g, " ").trim().slice(0, 20), c = compact(key), ns = syl(key);
            if (!c || !ns || !/^[\uAC00-\uD7A3A-Za-z0-9 ]{1,20}$/.test(key)) return;
            for (var i = S.recent.length - 1; i >= 0; i--) {
                var r = S.recent[i];
                if (r.c.indexOf(c) < 0 || !r.n) continue;
                var msPerSyl = r.durMs / r.n;
                var w = P.words[key] || { n: 0, msPerSyl: 0, db: 0, f0: 0, lo: 0, mid: 0, hi: 0 };
                var k = 1 / Math.min(w.n + 1, 30);
                w.msPerSyl = Math.round(w.n ? w.msPerSyl + (msPerSyl - w.msPerSyl) * k : msPerSyl);
                w.db = r1(w.n ? w.db + (r.db - w.db) * k : r.db);
                if (r.f0) { w.f0 = r1(w.f0 ? w.f0 + (r.f0 - w.f0) * k : r.f0); w[band(r.f0)]++; }
                w.n++;
                P.words[key] = w; used++;
                break;
            }
        });
        var keys = Object.keys(P.words);
        if (keys.length > MAX_WORDS) {   // 적게 쓰인 단어부터 버림
            keys.sort(function (a, b) { return P.words[a].n - P.words[b].n; }).slice(0, keys.length - MAX_WORDS).forEach(function (k) { delete P.words[k]; });
        }
        S.recent = [];
        if (used) saveSoon();
        return used;
    };

    /* ---------------- 후보가 헷갈릴 때 동점 깨기 ---------------- */
    // candidates: 이미 '관련 있는 말' 먼저로 정렬된 후보. 관련 있는 후보끼리만, 근거가 충분할 때만 순서를 바꿈
    A.rank = function (candidates, isRelated) {
        if (OFF || !candidates || candidates.length < 2) return candidates;
        var rel = candidates.filter(function (t) { try { return !isRelated || isRelated(t); } catch (e) { return false; } });
        if (rel.length < 2) return candidates;
        var u = U ? null : lastUtt, rate = S.rates.length ? pct(S.rates, 0.5) : (P.global.sessions >= 3 ? P.global.rate : 0);
        var keys = Object.keys(P.words).sort(function (a, b) { return compact(b).length - compact(a).length; });
        function score(t) {
            var c = compact(t), s = 0, word = "";
            for (var i = 0; i < keys.length; i++) if (c.indexOf(compact(keys[i])) >= 0) { word = keys[i]; break; }
            var wd = word ? P.words[word] : null;
            if (wd && wd.n >= 2) s += 0.15 * Math.min(1, Math.log(1 + wd.n) / Math.log(16));      // 이 키오스크에서 자주 확정된 메뉴
            var n = syl(t);
            if (u && u.durMs && n) {
                var exp = 0;
                if (wd && wd.msPerSyl) exp = wd.msPerSyl * n;
                else if (rate) exp = n / rate * 1000;
                if (exp) s += 0.25 * Math.exp(-2 * Math.abs(Math.log(u.durMs / exp)));        // 말한 길이와 후보 글자 수가 맞는 정도
                if (wd && wd.f0 && u.f0Med) s += Math.abs(u.f0Med - wd.f0) / wd.f0 < 0.25 ? 0.05 : 0;
            }
            return { t: t, s: s, word: word };
        }
        var sc = rel.map(score), first = sc[0], best = sc.slice().sort(function (a, b) { return b.s - a.s; })[0];
        A.lastRank = { first: first.t, best: best.t, firstScore: r4(first.s), bestScore: r4(best.s) };
        if (best.t === first.t || best.s - first.s < 0.12 || best.word === first.word) return candidates;
        var out = [best.t].concat(candidates.filter(function (t) { return t !== best.t; }));
        A.lastRank.changed = true;
        return out;
    };

    /* ---------------- 지우기 / 보기 ---------------- */
    A.reset = function () {
        P = emptyProfile(); newSession(); U = null; lastUtt = null; floor = 0.004; invalidate();
        try { localStorage.removeItem(KEY); } catch (e) {}
        try { fetch("/api/acoustic-profile", { method: "DELETE" }).catch(function () {}); } catch (e) {}
        return true;
    };
    A.profile = function () { return JSON.parse(JSON.stringify(P)); };
    A.stored = function () { try { return localStorage.getItem(KEY); } catch (e) { return null; } };
    A.isOff = function () { return OFF; };

    /* ---------------- 시작: 저장값 불러오기, 손님 바뀜(절전·주문 완료) 감지 ---------------- */
    if (!load() && !OFF) {
        try {
            fetch("/api/acoustic-profile", { cache: "no-store" }).then(function (r) { return r.ok ? r.json() : null; }).then(function (d) {
                if (d && d.words && !A.stored()) { P = sanitize(d); try { localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) {} }
            }).catch(function () {});
        } catch (e) {}
    }
    function hook() {
        // 주문 완료 화면('done')이 되면 → 그 주문의 메뉴 이름을 '확정 단어'로
        var prev = W.transitionTo;
        if (typeof prev === "function" && !prev.__v89Acoustic) {
            var wrapped = function (stageName) {
                if (stageName === "done") {
                    try {
                        var items = (typeof orderState !== "undefined" && orderState && orderState.items) ? orderState.items : [];
                        A.confirmWords(items.map(function (it) { return it && (it.item || it.name || (it.menu && it.menu.name)) || ""; }));
                    } catch (e) {}
                }
                return prev.apply(this, arguments);
            };
            wrapped.__v89Acoustic = true;
            try { W.transitionTo = wrapped; } catch (e) {}
        }
        // 절전에 들어가면 손님이 바뀐 것으로 보고 세션 요약을 저장
        try {
            var wasSleep = false;
            new MutationObserver(function () {
                var cl = document.body.className || "";
                var sl = /(^|\s)(sleep-mode|button-sleep-mode|simple-sleep-mode)(\s|$)/.test(cl);
                if (sl && !wasSleep) endSession();
                wasSleep = sl;
            }).observe(document.body, { attributes: true, attributeFilter: ["class"] });
        } catch (e) {}
    }
    if (document.readyState === "complete") setTimeout(hook, 0);
    else W.addEventListener("load", function () { setTimeout(hook, 0); });
})();
