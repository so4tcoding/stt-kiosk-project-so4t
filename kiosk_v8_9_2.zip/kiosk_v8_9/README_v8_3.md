# 키오스크 v8.3 — 아두이노 버튼 자동 연결 (기존 기능 삭제 없음)

## 바뀐 점
- 서버가 아두이노(/dev/ttyUSB0, ttyACM0 등)를 **자동으로 찾아 연결** (9600bps). 포트 선택창 필요 없음, 재부팅 후에도 자동.
- 아두이노를 뺐다 꽂아도 2초마다 다시 연결.
- 연결 직후 2초 동안 들어오는 데이터는 버림. `WAKE_BUTTON`, `STAFF_CALL` 등 **정확히 일치하는 줄만** 화면에 전달 → 연결 잡음으로 첫 화면 초기화되는 일 방지.
- 짧게 누름 = 절전일 때만 해제 / 2초 길게 = 직원 호출 (기존과 같음). LED 명령도 서버를 통해 전달.
- 기존 Web Serial 코드는 예비용으로 그대로 둠(서버 연결 중엔 선택창 안 뜸).
- `POST /api/use-metrics` 추가 (404 해결, `use_metrics.jsonl`에 저장).

## 1) PowerShell (내 PC)
```powershell
cd $HOME\Downloads\kiosk_v8_3
scp kiosk.html stt_server.py so4t@so4t.local:~/kiosk_project/
scp js/kiosk_serial_bridge.js so4t@so4t.local:~/kiosk_project/js/
```

## 2) 파이 (ssh so4t@so4t.local 로 접속 후)
```bash
~/kiosk_project/venv/bin/pip install pyserial
sudo usermod -aG dialout so4t
sudo systemctl restart kiosk-stt
sudo reboot     # dialout 권한 적용을 위해 한 번 재부팅
```

## 3) 확인
```bash
curl -s http://localhost:8000/api/button-status      # "connected": true 이면 성공
journalctl -u kiosk-stt -f | grep V83                # 버튼 누르면 "[V83 SERIAL] 버튼: WAKE_BUTTON"
```
- `connected:false` + last_error에 Permission denied → dialout 적용 안 됨(재부팅).
- 크롬이 Web Serial로 같은 포트를 잡고 있으면 서버가 못 엶 → 재부팅하면 해결.
