# 소4트 음성 키오스크 v8 (gen8) — 바뀐 점과 설치 방법

기존 기능은 지우지 않았습니다. 새 기능은 `</body>` 바로 앞의 `KIOSK_V8_FEATURES` 블록에 넣었고,
기존 코드에는 `// __V8__` 표시가 붙은 연결 줄 몇 개만 더했습니다(목록은 맨 아래).
기본 음성인식은 지금처럼 **하이브리드(Web Speech가 먼저 듣고 Whisper가 보정)** 그대로입니다.

## 파일
| 파일 | 내용 |
|---|---|
| `kiosk.html` | 파이용 오프라인 빌드 (서버가 `/kiosk`로 보여 주는 파일) |
| `kiosk_fixed_v8.html` | 원본(개발용) 쌍둥이 — 같은 v8 패치 |
| `stt_server.py` | 기존 서버 + 새 라우트 (기존 라우트는 한 글자도 안 바뀜, 줄바꿈 CRLF 그대로) |
| `menu.json` | 내장 메뉴 18개를 그대로 옮긴 기본 메뉴판 (관리자 화면에서 고침) |
| `static/twemoji/` | 메뉴 그림 90개 (svg + png, CC-BY 4.0, LICENSE.txt 포함) |
| `kiosk_button_led.ino` | 아두이노: 짧게 = WAKE_BUTTON(기존), **2초 길게 = STAFF_CALL**(새로) |
| `pi/` | 자동 시작: `kiosk-stt.service`, `kiosk_launcher.sh`, `labwc_autostart`, `wayfire_autostart.ini`, `install.sh` |
| `test/` | 자동 시험 스크립트 (가짜 음성인식·가짜 시리얼) |

## 관리자 PIN
- 정하는 순서: 환경변수 `KIOSK_ADMIN_PIN` → `~/kiosk_project/admin_pin.txt`의 첫 줄 → 기본값 **0302**
  (기본값은 기존 서버의 `ADMIN_PASSWORD`와 같습니다).
- 쓰는 곳: `/admin`(메뉴·가격·품절), `/dashboard?pin=…`(통계). `/staff`(직원 호출 화면)는 PIN 없이 열립니다.

## 새 주소
- `http://so4t.local:8000/staff` — 직원 호출 목록(3초마다 새로 고침, 새 호출이 오면 소리), [처리 완료] 버튼
- `http://so4t.local:8000/admin` — 메뉴 이름·종류·가격·설명·품절 고치기, 추가·삭제 → `menu.json`에 저장(이전 판은 `menu.json.bak`)
- `http://so4t.local:8000/dashboard` — 많이 팔린 메뉴, 평균 주문 시간, 막힌 단계, 날짜별 주문 수(그림은 SVG, 인터넷 필요 없음)
- API: `POST /staff_call`, `GET /staff_call`, `POST /staff_call/{id}/done`, `GET /menu.json`, `POST /admin/login`,
  `POST /admin/menu`(헤더 `X-Admin-Pin`), `POST /events`, `/static/...`
- 기록 파일: `~/kiosk_project/kiosk_v8_data/staff_calls.jsonl`, `~/kiosk_project/kiosk_v8_data/events.jsonl`

## 노트북(Windows)에서 파이로 올리기
PowerShell에서 gen8 폴더로 이동한 뒤:
```powershell
# 0) (처음 한 번) 파이의 지금 파일 백업
ssh so4t@so4t.local "cd ~/kiosk_project && mkdir -p backup_v7 && cp -n kiosk.html stt_server.py backup_v7/ 2>/dev/null; ls backup_v7"
# 1) 파일 올리기
scp kiosk.html stt_server.py so4t@so4t.local:~/kiosk_project/
scp -r static pi so4t@so4t.local:~/kiosk_project/
# 2) menu.json 은 처음 한 번만 (나중에 올리면 관리자 화면에서 고친 내용을 덮어씀)
scp menu.json so4t@so4t.local:~/kiosk_project/
# 3) 자동 시작 설치 (sudo 비밀번호를 물어봄)
ssh -t so4t@so4t.local "sed -i 's/\r$//' ~/kiosk_project/pi/*.sh && bash ~/kiosk_project/pi/install.sh"
# 4) 다시 켜서 확인
ssh so4t@so4t.local "sudo reboot"
```
- 이미 손으로 `uvicorn`을 켜 두었다면 먼저 끄세요(같은 8000번 포트).
- 서버 로그: `journalctl -u kiosk-stt -f`, 화면 실행 로그: `~/kiosk_project/kiosk_launcher.log`
- 부팅 때 자동으로 뜨려면 데스크톱 자동 로그인이 켜져 있어야 합니다(`sudo raspi-config` → System Options → Boot / Auto Login → Desktop Autologin).
- 인터넷 선이 기본 경로를 잡아 Web Speech가 안 되면: `sudo ip route del default dev eth0` (그래도 안 되면 v8이 자동으로 오프라인 모드로 바뀝니다).
- 아두이노 스케치는 노트북 Arduino IDE에서 보드 "Arduino Mega or Mega 2560"으로 올립니다(배선은 그대로).

## 기능별 동작
1. **오프라인 자동 전환**: Web Speech가 `network`/`service-not-allowed`/`not-allowed`/`language-not-supported` 오류를 10초 안에 3번 내거나 아예 없으면,
   화면 왼쪽 위에 "📴 오프라인 모드"가 뜨고 기기 안 Whisper만으로 듣습니다(말소리 크기로 한 마디를 잘라 `/transcribe`로 보냄 → 기존과 같은 길로 처리).
   60초마다 Web Speech를 4초 동안 시험해서 되면 하이브리드로 돌아갑니다. 오류 뒤 재시작은 80ms 반복 대신 2→3→4→5초 간격(평소 재시작은 그대로 80ms).
   LED는 마이크가 300ms 넘게 계속 켜졌을 때만 LISTEN.
2. **음성 장바구니 고치기**(기존 단일 라우터 `KIOSK_INTENTS.route` 앞단): "돼지국밥 빼줘", "하나 더/한 개 더/세 잔 더", "다섯 개로 바꿔줘",
   "아메리카노 말고 카페라떼로"(앞 메뉴가 장바구니에 있을 때만, 개수 유지·옵션은 기본), "장바구니 비워줘"(네/아니요로 한 번 더 확인).
   "아까 거 빼줘/방금 거 취소"는 기존 기능 그대로. 주문 내역·추가 주문·메뉴판·종류 고르기·매장/포장 화면에서 동작(결제 중·결제 뒤에는 안 함).
3. **결제 전 확인**(기존 주문 내역 화면 보강, 확인을 두 번 하지 않음): 평소 속도보다 0.2 느리게 "첫째, 돼지국밥 2개. 둘째, …, 총 금액은 …원" 전체를 읽고,
   "네/맞아요"(또는 화면 [확인]) → 결제 방법 화면, "아니요"(또는 [고치기]) → 주문 내역에 그대로 머물며 고치는 말 안내. "결제"라고 해도 기존처럼 넘어갑니다.
4. **직원 호출**: "직원 불러줘/사람 불러줘/도와주세요", 버튼 2초 길게, 화면 오른쪽 위 [🙋 직원 호출] → 큰 "직원을 부르고 있어요" 화면 + 차임 + 서버 기록.
   10초 안의 중복 호출은 화면만 다시 띄우고 한 번만 기록. 화면을 누르거나 20초 지나면 닫힘.
5. **접근성**: "천천히/빨리 말해줘"(저장), "다시 말해줘", "글씨 크게/작게"는 이미 있던 기능입니다. v7까지는 "글씨 크게" 한 마디에 2단계씩 커지고
   "글씨 작게 해줘"가 바로 원래 크기로 돌아가는 중복 처리가 있어서, 한 번에 한 단계(0~최대)만 움직이게 고쳤습니다(오프라인 모드에서도 동작).
6. **메뉴 관리**: 키오스크가 켜질 때와, 손님이 없을 때(첫 화면·절전) 2분마다 `/menu.json`을 읽어 가격·품절·추가 메뉴를 반영합니다.
   못 읽으면 내장 메뉴 그대로. 품절 메뉴는 메뉴판에 "품절" 도장, 음성으로 고르면 "죄송합니다. ○○는 지금 품절이에요…". G 관리자 창에서 직접 추가한 메뉴는 지우지 않습니다.
7. **통계**: 주문 시작~끝(완료/중간에 그만둠), 메뉴·개수, 화면별 머문 시간·말한 횟수, 막힌 단계(한 화면에서 3번 이상 말했거나 30초 넘게), 오프라인 모드 사용, 직원 호출 수를
   `/events`로 보냅니다. 서버가 꺼져 있으면 키오스크에 최대 200건 모아 두었다가 다시 보냅니다. 개인 음성·이름은 보내지 않습니다.
8. **파이 자동 시작**: `pi/` 폴더 참고 (서버는 systemd `Restart=always`, 화면은 Chromium이 꺼지면 5초 뒤 다시 실행, 두 번 겹쳐 실행 안 됨).
9. **메뉴 그림**: jsDelivr CDN 대신 `/static/twemoji/`에서 불러옵니다(인터넷 없이 그림 표시).

## 기존 코드에 더한 연결 줄 (`__V8__` 표시)
- 하이브리드 `onerror`: 오류 이름을 v8에 알림 / `onend`: 오프라인 모드면 재시작 안 함, 재시작 간격 80ms → v8 함수(평소 80ms, 오류 뒤 2~5초)
- `startHybrid` 첫 줄: 오프라인 모드면 Web Speech를 켜지 않음 / `routeText` 첫 줄: 원래 문장 기억('말고' 처리용) / `window.__hybridRouteText` 공개
- 시리얼 읽기 두 곳: `STAFF_CALL` 줄을 직원 호출로
- twemoji 주소 4곳: CDN → `window.KIOSK_TWEMOJI_BASE || "/static/twemoji/"`
- v7.3 LED 블록: Whisper 전용 듣기도 '듣는 중', 60초 시험용 인식은 제외, LISTEN은 300ms 안정 뒤
