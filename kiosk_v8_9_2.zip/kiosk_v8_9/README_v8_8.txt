키오스크 v8.8 (2026-10-24 KST) — 렉 줄이기 (기능 삭제 없음, 하이브리드 STT 그대로)

[처음 켤 때 렉 / 가끔 크게 멈추는 렉 — 찾은 원인과 고친 것]

1. (확인됨) 3D 토핑 그림판(three-canvas)이 주문 시작·절전 해제 때마다 새로 만들어졌음
   - initThreeJS()가 4군데에서 불려서, 주문을 시작할 때마다 '그리기 반복'이 하나씩 늘었음.
   - 그리고 토핑이 없어도 화면 전체 크기의 투명 3D 그림판을 매 프레임 계속 그렸음.
   → 이제 한 번만 만들고, 토핑이 떨어지는 동안에만 그림. 다 떨어지면 멈춤. (토핑 효과는 그대로)
   → 파이 가벼운 모드에서는 3D 계단 보정(antialias)만 끔.

2. (확인됨) 화면 그리기 제한 코드(kiosk_pi.js + kiosk_pi_perf.js)가 오히려 헛돌았음
   - 두 겹으로 감싸져 있고, 모든 그리기 반복이 '마지막 시각' 하나를 같이 써서
     하나만 그려지고 나머지는 매 프레임 헛도는 재요청을 반복했음.
   - 시험(헤드리스 크롬): 절전↔주문 반복 뒤 초당 호출 수 469 → 1,011 → 3,295 → 4,977번으로 계속 늘어남.
   → 기다리는 그리기를 모아서 정해진 간격(평소 초당 15번, TTS·절전 중 4번)에 한 번에 실행하도록 고침.
     v8.8 같은 시험: 초당 1~30번, 반복해도 늘지 않음.

3. (확인됨) 실제로 쓰는 절전 화면(버튼 절전)에서 '절전 중 가볍게' 기능이 안 켜졌음
   - v8.4의 절전 감지가 button-sleep-mode를 몰랐음. 그래서 절전 화면 뒤에 가려진 로봇이 계속 움직이며
     초당 60번 화면 계산을 했음.
   → 절전 화면에서는 가려진 로봇 움직임을 쉬고, 깨면 다시 움직임.
     시험(CPU 6배 느리게 한 헤드리스 크롬): 절전 화면 메인 스레드 사용 11% → 3%.

4. (확인됨) 서버가 Whisper 모델을 다 불러올 때까지 아예 응답을 안 했음 → 화면도 그만큼 늦게 뜸
   → 서버는 바로 뜨고, 모델은 뒤에서 불러온 뒤 1초 무음으로 '예열'(첫 인식이 느린 것 방지).
   → 모델 준비 전에 온 음성은 최대 25초 기다렸다가 처리. 처음 화면(시작하기) 아래에
     '음성 인식 준비 중… N초' → '준비 완료 ✓' 표시.

5. (확인됨) 서비스 파일이 Whisper에 CPU 코어 4개를 모두 주고 있었음 (WHISPER_CPU_THREADS=4)
   - v8.4에서 코드 기본값은 3으로 바꿨지만, 서비스 파일의 4가 그 값을 덮어쓰고 있었음.
   - Whisper가 인식하는 동안 크롬(화면·터치)이 멈춘 것처럼 느려지는 '가끔 큰 렉'의 유력한 원인.
   → 3으로 바꿈 (아래 '한 번만 할 일' 1번 필요).

6. 부팅할 때 바탕화면 대신 '키오스크를 준비하고 있어요' 화면(pi/loading.html)을 바로 띄우고,
   서버가 뜨면 자동으로 키오스크로 넘어감. 크롬 옵션 추가(GPU로 그리기, 번역·캐스트 등 안 쓰는 기능 끔).
   화면이 이상하면:  touch ~/kiosk_project/pi/SAFE_FLAGS  후 재부팅 → 예전 옵션으로 실행.

7. 음성 인식 요청은 한 번에 하나씩 차례대로. 화면이 연결을 끊었거나 20초 넘게 밀린 음성은 건너뜀.
8. 3D 토핑이 사라질 때 메모리 정리, 절전이 아닐 때는 소리 크기(dB) 계산을 쉼.
9. 새 점검 도구: pi/lag_check.sh (온도, 전원 부족·발열 제한, CPU 모드, 부하, CPU 많이 쓰는 프로그램)

[추측 — 확인 못 한 것]
- 파이 화면에서 전체 화면 3D 그림판이 GPU를 얼마나 먹었는지는 파이에서만 잴 수 있음(여기는 GPU 없음).
- 랜덤 렉의 흔한 원인인 전원 부족·발열은 파이에서 lag_check.sh로 확인해야 함.
- Whisper 모델 크기(models/whisper-kiosk-ct2-int8)는 그대로 둠. 직접 학습한 모델이라 정확도를 위해 안 바꿈.
  더 가볍게 하려면 서비스 파일에 Environment=WHISPER_MODEL=base 처럼 지정 가능(정확도 떨어질 수 있음, 처음엔 인터넷으로 내려받음).

[버전 확인]
  grep -c __V88__ ~/kiosk_project/kiosk.html      → 10 나오면 v8.8

[설치 (노트북에서 파이로 복사한 뒤, 파이 터미널에서)]
  kiosk_v8_8.zip 을 파이 홈 폴더(~)에 복사 (USB 또는 scp)
  cd ~
  cp -r ~/kiosk_project ~/kiosk_project_backup_v87
  unzip -o kiosk_v8_8.zip
  cp -r ~/kiosk_v8_8/* ~/kiosk_project/
  chmod +x ~/kiosk_project/pi/*.sh

[한 번만 할 일 — 서비스 파일이 바뀌어서 필요]
  1) sudo cp ~/kiosk_project/pi/kiosk-stt.service /etc/systemd/system/kiosk-stt.service
     sudo systemctl daemon-reload
     sudo systemctl restart kiosk-stt
  2) (권장, v8.4 때 안 했다면) CPU 항상 최고 속도:
     sudo cp ~/kiosk_project/pi/cpu-performance.service /etc/systemd/system/
     sudo systemctl enable --now cpu-performance
  3) sudo reboot
  (install.sh는 다시 안 돌려도 됨. labwc 자동 실행 줄은 그대로 kiosk_launcher.sh를 부르고, 그 파일이 이번에 바뀜)

[확인]
  curl -s localhost:8000/        → "model_ready":true 가 나오면 Whisper 준비 끝
  bash ~/kiosk_project/pi/lag_check.sh

[되돌리기]
  rm -rf ~/kiosk_project && mv ~/kiosk_project_backup_v87 ~/kiosk_project
  sudo cp ~/kiosk_project/pi/kiosk-stt.service /etc/systemd/system/ && sudo systemctl daemon-reload && sudo reboot

[손으로 해야 할 것]
- 전원: 라즈베리파이 4 정품 5V 3A USB-C 어댑터. 핸드폰 충전기·노트북 USB는 전압이 모자라 랜덤 렉이 남.
  lag_check.sh에 '전압 부족'이 나오면 어댑터부터 바꾸기.
- 발열: 방열판 + 팬(케이스 팬) 달기. 온도 80도 넘으면 스스로 느려짐. 아크릴 본체 안이면 공기 구멍 꼭.
- SD카드: 가능하면 빠른 카드(A1/A2 등급).
