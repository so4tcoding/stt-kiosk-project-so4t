# 키오스크 v8.4 — 라즈베리파이 4(8GB) 렉 줄이기

기능은 하나도 지우지 않았어요. 하이브리드(Web Speech 1차 + Whisper)도 그대로예요.

## 바뀐 것
1. **js/kiosk_pi_perf.js (새 파일)**: 파이 가벼운 모드일 때만 동작해요.
   - 화면 그리기: 초당 15번까지만. TTS가 말하는 중이거나 절전 중이면 초당 4번까지만.
   - 마이크 파형 분석: TTS 중이나 절전 중에는 쉬어요.
   - 1차 인식(Web Speech) 오류(Error -2 등)가 나면 다시 켜는 간격을 1→2→4→…→최대 30초로 늘려요. 3번 연속 실패하면 Whisper가 계속 맡고, 1차 인식은 30초마다 다시 시도해요. 인식에 성공하면 바로 원래대로 돌아가요.
   - 1초보다 짧은 반복 타이머는 TTS 중이나 절전 중에 한 번씩 건너뛰어요.
   - 같은 경고 로그는 1초에 한 번만 찍어요.
   - 끄기: 주소 뒤에 `?lite=0`을 붙이거나 `localStorage.setItem("kiosk_perf_off","1")`
2. **stt_server.py**
   - Whisper CPU 스레드 기본값을 4에서 3으로 바꿨어요(코어 하나는 크롬과 TTS용). 환경변수 `WHISPER_CPU_THREADS`로 바꿀 수 있어요.
   - beam_size 기본값을 3에서 1로 바꿨어요. `WHISPER_BEAM_SIZE=3`으로 되돌릴 수 있어요. 정확도에 영향이 있을 수 있으니 테스트해 보세요.
   - 음성 인식을 별도 스레드에서 돌려서, 인식 중에도 버튼·화면 요청이 막히지 않아요.
   - 서버 우선순위를 크롬보다 조금 낮췄어요(nice 5, `KIOSK_SERVER_NICE`로 바꿀 수 있어요).
3. **kiosk.html**: `kiosk_pi_perf.js`를 부르는 줄 하나만 추가했어요.

## 파이 설정 (선택, 권장)
### 1) 크롬 실행 옵션 (`~/.config/labwc/autostart`)
`--ozone-platform=wayland` 뒤에 아래를 붙여요(이미 있는 건 빼고요).
```
--enable-gpu-rasterization --ignore-gpu-blocklist --disable-smooth-scrolling --disable-features=Translate,MediaRouter --renderer-process-limit=2
```
### 2) CPU를 항상 최고 속도로 (`pi/cpu-performance.service`)
```
sudo cp ~/kiosk_project/pi/cpu-performance.service /etc/systemd/system/
sudo systemctl enable --now cpu-performance
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor   # performance 나오면 성공
```
발열이 늘 수 있으니 방열판이나 팬을 다는 게 좋아요. `vcgencmd measure_temp`로 80도가 넘지 않는지 보세요.
### 3) GPU 메모리
`sudo nano /boot/firmware/config.txt`에서 `dtoverlay=vc4-kms-v3d`가 있는지 확인하고, 맨 아래에 `gpu_mem=256`을 넣어요. (KMS 드라이버에선 효과가 작을 수 있어요.)
### 4) 안 쓰는 서비스 (선택만)
블루투스를 안 쓰면 `sudo systemctl disable --now bluetooth`. 쓰고 있으면 하지 마세요.
### 5) 스왑/가상 메모리
메모리가 6GB 넘게 남아 있어서 SD카드 스왑을 늘려도 빨라지지 않고, 오히려 SD카드가 느려지고 닳아요. 꼭 필요하면 SD카드 대신 메모리를 압축해 쓰는 zram이 낫지만, 지금은 필요 없어요.

## 되돌리기
v8.3 파일을 다시 복사하거나, `?lite=0` / 환경변수로 이전 값을 쓰면 돼요.
