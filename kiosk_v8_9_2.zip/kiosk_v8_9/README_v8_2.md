# 키오스크 v8.2 (라즈베리파이 보정판)

## 바뀐 것
1. **가게 종류를 관리자에서 정하기**: `/admin`(PIN 0302) → 맨 위 "가게 종류"에서 고르고 **가게 저장**. 키오스크를 새로고침/재부팅하면 "무슨 가게인가요?"를 묻지 않고 바로 그 가게로 시작합니다. "설정 안 함"이면 예전처럼 물어봅니다. 음성 "가게 바꿔"도 그대로 됩니다.
   - 저장 위치: `~/kiosk_project/kiosk_settings.json` (새 API: `GET /kiosk_settings`, `POST /admin/settings` — PIN 필요)
2. **첫 화면 한 번 누르기**: 브라우저 규칙상 꼭 한 번은 눌러야 해서 남겼고, 이제 버튼이 아니라 화면 아무 데나 눌러도 됩니다.
3. **TTS 끊김(새 파일 `js/kiosk_pi.js`)**: 아무것도 말하지 않을 때의 `cancel()`은 무시, `cancel()` 바로 뒤 `speak()`는 0.14초 쉬었다가 말하기(파이), 한국어 목소리(구글 한국어 우선) 자동 선택. 쉬는 시간 조절: 크롬 콘솔에서 `localStorage.setItem("kiosk_tts_gap_ms","200")`.
4. **가벼운 모드**: 파이(리눅스 ARM)에서 자동으로 켜짐. 흐림·그림자·애니메이션 끄기, 0.25초보다 잦은 타이머를 0.25초로, 3D 배경 초당 20장, `console.log` 끄기. 기능은 그대로입니다. 노트북에서 시험: `kiosk.html?lite=1`, 파이에서 끄기: `?lite=0`, 로그 보기: `?debug=1`. 파이 보정 전체 끄기: `localStorage.setItem("kiosk_pi_off","1")`.

## 설치 (노트북 Windows PowerShell)
zip을 풀고 그 폴더(`kiosk_v8_2`)에서:
```powershell
cd $HOME\Downloads\kiosk_v8_2
scp kiosk.html stt_server.py so4t@so4t.local:~/kiosk_project/
scp js/kiosk_pi.js js/kiosk_shop.js so4t@so4t.local:~/kiosk_project/js/
```
파이에서:
```bash
sudo systemctl restart kiosk-stt
sleep 10; curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8000/kiosk_pi.js   # 200 이면 성공
pkill -f chrome   # 자동 실행이면 다시 켜짐. 아니면 아래 크롬 명령으로 켜기
```

## 파이 소리 잡음 줄이기
```bash
# 1) PipeWire 버퍼 키우기 (지지직/끊김 감소)
mkdir -p ~/.config/pipewire/pipewire.conf.d
cat > ~/.config/pipewire/pipewire.conf.d/99-kiosk.conf << 'EOF2'
context.properties = {
    default.clock.rate        = 48000
    default.clock.quantum     = 1024
    default.clock.min-quantum = 1024
    default.clock.max-quantum = 2048
}
EOF2

# 2) 자브라가 잠들었다 깨며 '딱' 소리 내는 것 막기
mkdir -p ~/.config/wireplumber/wireplumber.conf.d
cat > ~/.config/wireplumber/wireplumber.conf.d/99-jabra-nosuspend.conf << 'EOF2'
monitor.alsa.rules = [
  {
    matches = [ { node.name = "~alsa_output.*Jabra*" }, { node.name = "~alsa_input.*Jabra*" } ]
    actions = { update-props = { session.suspend-timeout-seconds = 0, api.alsa.period-size = 1024, api.alsa.headroom = 1024 } }
  }
]
EOF2
systemctl --user restart wireplumber pipewire pipewire-pulse

# 3) 자브라를 기본 출력으로 (wpctl status 에서 Jabra 번호 확인 후)
wpctl status | sed -n '/Sinks/,/Sources/p'
# wpctl set-default <번호>

# 4) espeak-ng 쓰는 경우 (크롬 구글 한국어 목소리가 없을 때)
sudo apt install -y speech-dispatcher espeak-ng speech-dispatcher-espeak-ng
sudo sed -i 's/^#\? *DefaultModule .*/DefaultModule espeak-ng/; s/^#\? *DefaultLanguage .*/DefaultLanguage "ko"/; s/^#\? *DefaultRate .*/DefaultRate 0/' /etc/speech-dispatcher/speechd.conf
spd-say -l ko "안녕하세요"
```
(WirePlumber 0.4 이하라 `.conf`가 안 먹으면 알려 주세요. 버전 확인: `wireplumber --version`)

## 파이 크롬 권장 실행 옵션
```bash
google-chrome-stable --kiosk --ozone-platform=wayland --no-first-run --noerrdialogs --disable-infobars \
  --enable-features=VaapiVideoDecoder --ignore-gpu-blocklist --enable-gpu-rasterization \
  --disable-background-timer-throttling --disable-renderer-backgrounding --disable-smooth-scrolling \
  --autoplay-policy=no-user-gesture-required --use-fake-ui-for-media-stream \
  --enable-speech-dispatcher http://localhost:8000/kiosk.html
```
`--autoplay-policy=no-user-gesture-required`와 `--use-fake-ui-for-media-stream`(마이크 자동 허용)을 넣으면 "한 번 눌러주세요"를 누르지 않아도 소리가 날 수 있습니다(누르는 화면 자체는 남아 있음).
자동 실행으로 바꾸기: `~/.config/labwc/autostart`의 크롬 줄을 위 명령으로 바꾸세요.
