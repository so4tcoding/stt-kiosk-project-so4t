키오스크 v8.9.1 (2026-10-28 KST) — 켤 때 화면 방향이 90도로 되돌아가던 것만 고침
v8.9 의 다른 동작(파이 모드, 목소리 숫자 맞춤, 손님 녹음 저장 끄기)은 그대로입니다.

[무엇이 바뀌었나]
  pi/kiosk_launcher.sh 에서 아래 한 줄을 뺐습니다.
    wlr-randr --output DSI-1 --transform 90
  이 줄이 키오스크가 켜질 때마다 터치 화면을 90도로 덮어써서,
  화면 설정(Screen Configuration)에 저장한 180도가 풀렸습니다.
  이제는 저장해 둔 방향을 런처가 바꾸지 않습니다.
  외부 HDMI 를 끄는 줄(HDMI-A-1 --off)은 이전과 같습니다. 화면은 터치 화면(DSI)입니다.

[파이에서 확인하는 글자]
  grep __V891__ ~/kiosk_project/pi/kiosk_launcher.sh
  한 줄이라도 나오면 v8.9.1 실행기입니다.

[설치] kiosk_v8_9_1.zip 을 파이 홈 폴더(~)에 복사한 뒤:
  cd ~
  unzip -o kiosk_v8_9_1.zip
  cp -r ~/kiosk_v8_9/* ~/kiosk_project/
  if [ -f ~/kiosk_project_backup_v88/menu.json ]; then cp ~/kiosk_project_backup_v88/menu.json ~/kiosk_project/menu.json; fi
  chmod +x ~/kiosk_project/pi/*.sh
  sudo reboot

  서비스 파일은 v8.9 와 같아서 systemctl 은 다시 안 해도 됩니다.
  화면 방향은 재부팅 전에 한 번만 저장합니다.
    메뉴 → Preferences → Screen Configuration → 터치 화면 방향 180도 → 저장
  이미 180도로 저장해 두었다면 그 설정이 이번 재부팅부터 유지됩니다.

[아직 여기 컴퓨터에서는 파이 화면에 연결해 보지 못했습니다]
  방향이 맞는지, 예전보다 느린지는 파이에서만 확인할 수 있습니다.
