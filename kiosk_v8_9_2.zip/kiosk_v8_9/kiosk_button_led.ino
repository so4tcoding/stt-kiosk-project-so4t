/*
  kiosk_button_led.ino (v8.5: 내용은 v8과 동일 — 이 파일을 아두이노에 다시 업로드해야 STAFF_CALL이 나감 · v8: 버튼 2초 길게 = 직원 호출 추가 · v7.3 LED 상태 3단계 · 기존 동작 삭제 없음)
  원본 설명: kiosk_button.ino  —  음성 키오스크용 큰 아케이드 버튼 (v7.2 페이지와 맞춤)
  ---------------------------------------------------------------------------
  주 대상: Arduino Mega 2560 (호환보드 포함, USB로 PC 연결)
  보조:    ESP32-S3 UNO 보드 (아래 핀 설명 참고)

  ■ 통신 (Web Serial, 9600 baud, 줄 끝 '\n')
    아두이노 → 페이지
      WAKE_BUTTON        버튼을 눌렀을 때 한 번 (페이지는 절전 모드 + 안내가 끝난 뒤에만 받아들임)
                         ※ 페이지는 START_BUTTON / BUTTON_PRESSED / TOGGLE_MIC 도 같은 뜻으로 받음
      STAFF_CALL         (v8 추가) 버튼을 2초 이상 계속 누르고 있으면 한 번 → 페이지가 '직원 호출'
                         짧게 누르면 예전처럼 WAKE_BUTTON 만 갑니다 (누르는 순간 바로 보냄, 지연 없음).
                         길게 누르면 누르는 순간 WAKE_BUTTON, 2초가 되는 순간 STAFF_CALL 이 갑니다.
                         STAFF_CALL 을 보낸 순간 버튼 LED가 빠르게 3번 깜빡여 '호출됨'을 알려 줍니다.
    페이지 → 아두이노  (kiosk_fixed_v7_2.html 이 실제로 보내는 명령 전부)
      BUTTON_LED_BLINK   '버튼을 눌러주세요' 신호 → 빠르게 깜빡임  (절전 안내 TTS가 끝난 뒤에만 옴)
      LED_WAKE_PROMPT    위와 같음 (예전 안내용)
      LED_SLEEP          절전 시작 → 끔 (안내가 끝나기 전에는 깜빡이지 않음)
      LED_READY          절전 해제 → 켜짐
      BUTTON_LED_ON      켜짐
      LED_ON             켜짐
      LED_OFF            끔
      LED_BLINK          마이크 듣는 중 표시 → 천천히 숨쉬듯 밝아졌다 어두워짐
    ── v7.3 추가: 마이크 상태 3단계 명령 (kiosk_fixed_v7_3.html / gen7e/kiosk.html 이 보냄) ──
      LED:IDLE           대기 (깨어 있고 마이크는 꺼짐: 안내 말하는 중·처리 중) → 은은하게 천천히 숨쉬기
      LED:LISTEN         인식 중 (마이크가 듣는 중)                             → 밝게 계속 켜짐
      LED:SLEEP          절전 (안내가 끝나기 전)                                → 꺼짐
      LED:WAKE           절전 + '버튼을 눌러 주세요' 신호                       → 빠르게 깜빡임
      페이지는 상태가 바뀔 때마다, 그리고 2초마다 한 번 현재 상태를 다시 보냅니다
      (Mega가 시리얼을 열 때 리셋되어도 곧 맞춰짐).
      LED: 명령을 최근 8초 안에 받았으면 위의 예전 명령(LED_ON, LED_OFF, LED_BLINK 등)은 무시해서
      두 방식이 서로 LED를 뺏지 않게 합니다. 예전 페이지(v7.2)로 쓰면 예전 명령대로 그대로 동작합니다.
    ※ 주의: 페이지는 받은 줄에 'SLEEP' 이나 'PERSON_LEFT' 글자가 들어 있으면 절전 모드로 들어갑니다.
            그래서 이 스케치는 WAKE_BUTTON / STAFF_CALL 외에는 아무 글자도 보내지 않습니다 (디버그 출력 금지).

  ■ 배선 (Mega 2560)
    ※ 실제 키오스크 배선(코드 기준): 버튼 스위치 → 22번·50번 핀(50번은 LOW 출력 = GND 역할),
      버튼 LED(+) → D9(PWM), LED(−) → GND.  아래 D2 설명은 예전 안내이며 코드는 22번을 읽습니다.
    [버튼 스위치]
      버튼 스위치 한쪽 단자(COM)  → GND
      버튼 스위치 다른 단자(NO)   → D2   (내부 풀업 사용: 안 누르면 HIGH, 누르면 LOW)
      저항 필요 없음.
    [버튼 안에 있는 LED]  (없으면 연결 안 해도 됨 — 스케치는 그대로 동작)
      ● 5V용 LED(저항 내장형) 이고 20mA 이하일 때:
          D9 ──[220Ω]── LED(+)  ,  LED(−) → GND      (저항 내장형이면 220Ω 생략 가능)
      ● 12V용 LED 이거나 전류가 큰 경우: 아두이노 핀으로 직접 켜면 안 됨! 트랜지스터를 씁니다.
          D9 ──[1kΩ]── NPN 트랜지스터(2N2222 / BC337 등) 베이스
          트랜지스터 이미터 → GND (12V 전원의 GND와 아두이노 GND를 꼭 이어줌)
          트랜지스터 컬렉터 → LED(−)
          LED(+) → +12V (또는 LED 정격 전압)
          (로직 레벨 N-MOSFET, 예: IRLZ44N 도 가능: 게이트←D9(100Ω), 게이트-GND 10kΩ)
      ● 아두이노 보드의 내장 LED(13번)도 같이 깜빡여서 LED 없이도 확인할 수 있습니다.

  ■ ESP32-S3 UNO 보드로 쓸 때
      버튼: GPIO4 ↔ GND (INPUT_PULLUP)      LED: GPIO5 (트랜지스터 권장, ESP32는 3.3V·약 20mA)
      아래 #if 부분이 자동으로 핀을 바꿉니다. 보드 USB 포트가 'USB CDC On Boot: Enabled' 여야
      Serial 이 PC의 Web Serial 로 보입니다. 5V 를 GPIO 에 직접 넣지 마세요.

  ■ 참고
    - Mega 는 PC에서 시리얼을 열 때 자동으로 리셋되어 약 1~2초 동안 명령을 못 받습니다. 정상입니다.
    - 버튼 반복 입력 방지: 30ms 디바운스 + 누른 뒤 400ms 동안 다시 보내지 않음.
    - v8: 2초 길게 누름 = STAFF_CALL (한 번 누를 때 한 번만). 짧게 누름 동작은 그대로.
*/

#if defined(ARDUINO_ARCH_ESP32)
const uint8_t BUTTON_PIN = 4;     // ESP32-S3: GPIO4
const uint8_t LED_PIN    = 5;     // ESP32-S3: GPIO5
const int     STATUS_LED = -1;    // 보드마다 달라서 사용 안 함
#else
const uint8_t BUTTON_PIN = 22;    // Mega 2560: 버튼 한쪽 선 = 22번 핀
const uint8_t BUTTON_GND_PIN = 50; // 버튼 다른 쪽 선 = 50번 핀 (LOW로 출력해서 GND처럼 사용)
const uint8_t LED_PIN    = 9;     // Mega 2560: D9 (PWM)
const int     STATUS_LED = 13;    // Mega 내장 LED
#endif

const unsigned long BAUD          = 9600;
const unsigned long DEBOUNCE_MS   = 30;
const unsigned long REPRESS_MS    = 400;
const unsigned long LONG_PRESS_MS = 2000;   // v8: 이만큼 계속 누르면 STAFF_CALL
const unsigned long STAFF_FLASH_MS = 900;   // v8: STAFF_CALL 보낸 뒤 LED 빠른 깜빡임 시간
unsigned long pressStartAt = 0;
bool staffSentThisPress = false;
unsigned long staffFlashUntil = 0;

enum LedMode { LED_MODE_OFF, LED_MODE_ON, LED_MODE_BLINK, LED_MODE_BREATH, LED_MODE_IDLE_SOFT };

// v7.3: 새 상태 명령(LED:...)을 받은 시각. 최근 8초 안이면 예전 명령은 무시
const unsigned long NEW_PROTO_HOLD_MS = 8000;
unsigned long lastNewCmdAt = 0;
bool newProtoSeen = false;
LedMode ledMode = LED_MODE_OFF;

// 버튼 상태
int stableState = HIGH;
int lastRead = HIGH;
unsigned long lastChangeAt = 0;
unsigned long lastSentAt = 0;

// 들어오는 줄
char lineBuf[40];
uint8_t lineLen = 0;

void writeLed(uint8_t level) {   // 0~255
#if defined(ARDUINO_ARCH_ESP32)
  analogWrite(LED_PIN, level);
#else
  analogWrite(LED_PIN, level);
#endif
  if (STATUS_LED >= 0) digitalWrite(STATUS_LED, level > 127 ? HIGH : LOW);
}

void setMode(LedMode m) { ledMode = m; }

bool newProtoActive() {
  return newProtoSeen && (millis() - lastNewCmdAt) < NEW_PROTO_HOLD_MS;
}

void handleCommand(const char* cmd) {
  // ── v7.3 상태 명령 (대기 / 인식 중 / 절전 / 버튼 신호) ──
  if (!strncmp(cmd, "LED:", 4)) {
    const char* s = cmd + 4;
    bool known = true;
    if      (!strcmp(s, "IDLE"))   setMode(LED_MODE_IDLE_SOFT);   // 대기: 은은한 숨쉬기
    else if (!strcmp(s, "LISTEN")) setMode(LED_MODE_ON);          // 인식 중: 밝게 켜짐
    else if (!strcmp(s, "SLEEP"))  setMode(LED_MODE_OFF);         // 절전: 꺼짐
    else if (!strcmp(s, "WAKE"))   setMode(LED_MODE_BLINK);       // 절전 중 '버튼을 눌러 주세요': 빠른 깜빡임
    else known = false;
    if (known) { newProtoSeen = true; lastNewCmdAt = millis(); }
    return;                                                       // 응답은 보내지 않음
  }
  if (newProtoActive()) return;   // 새 방식으로 동작 중이면 예전 명령은 무시 (LED 다툼 방지)
  // ── 예전 명령 (v7.2 이하 페이지와 호환, 그대로 유지) ──
  if (!strcmp(cmd, "BUTTON_LED_BLINK") || !strcmp(cmd, "LED_WAKE_PROMPT")) setMode(LED_MODE_BLINK);
  else if (!strcmp(cmd, "LED_SLEEP") || !strcmp(cmd, "LED_OFF"))           setMode(LED_MODE_OFF);
  else if (!strcmp(cmd, "LED_READY") || !strcmp(cmd, "BUTTON_LED_ON") || !strcmp(cmd, "LED_ON")) setMode(LED_MODE_ON);
  else if (!strcmp(cmd, "LED_BLINK"))                                       setMode(LED_MODE_BREATH);
  // 모르는 명령은 조용히 무시 (응답을 보내지 않음)
}

void readSerialLines() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      lineBuf[lineLen] = '\0';
      if (lineLen > 0) handleCommand(lineBuf);
      lineLen = 0;
    } else if (lineLen < sizeof(lineBuf) - 1) {
      lineBuf[lineLen++] = c;
    } else {
      lineLen = 0;   // 너무 긴 줄은 버림
    }
  }
}

void readButton() {
  int r = digitalRead(BUTTON_PIN);
  unsigned long now = millis();
  if (r != lastRead) { lastRead = r; lastChangeAt = now; }
  if ((now - lastChangeAt) >= DEBOUNCE_MS && r != stableState) {
    stableState = r;
    if (stableState == LOW) { pressStartAt = now; staffSentThisPress = false; }   // v8: 누른 시각 기록
    if (stableState == LOW && (now - lastSentAt) >= REPRESS_MS) {   // 누르는 순간 한 번
      lastSentAt = now;
      Serial.print("WAKE_BUTTON\n");
    }
  }
  // v8: 2초 이상 계속 누르고 있으면 STAFF_CALL 한 번 (손을 뗐다 다시 눌러야 또 보냄)
  if (stableState == LOW && !staffSentThisPress && (now - pressStartAt) >= LONG_PRESS_MS) {
    staffSentThisPress = true;
    Serial.print("STAFF_CALL\n");
    staffFlashUntil = now + STAFF_FLASH_MS;
  }
}

void updateLed() {
  unsigned long t = millis();
  if ((long)(staffFlashUntil - t) > 0) { writeLed(((t / 75) % 2) ? 255 : 0); return; }   // v8: 직원 호출 알림 깜빡임
  switch (ledMode) {
    case LED_MODE_OFF:    writeLed(0); break;
    case LED_MODE_ON:     writeLed(255); break;
    case LED_MODE_BLINK:  writeLed(((t / 300) % 2) ? 255 : 0); break;          // 0.3초마다 깜빡
    case LED_MODE_IDLE_SOFT: {                                                  // 대기: 3초 주기, 밝기 15~90 사이로 은은하게
      unsigned long p = t % 3000;
      int v = p < 1500 ? (int)(p * 75 / 1500) : (int)((3000 - p) * 75 / 1500);
      writeLed((uint8_t)(15 + v));
      break;
    }
    case LED_MODE_BREATH: {                                                     // 2초 주기 숨쉬기
      unsigned long p = t % 2000;
      int v = p < 1000 ? (int)(p * 255 / 1000) : (int)((2000 - p) * 255 / 1000);
      writeLed((uint8_t)v);
      break;
    }
  }
}

void setup() {
#if !defined(ARDUINO_ARCH_ESP32)
  pinMode(BUTTON_GND_PIN, OUTPUT);
  digitalWrite(BUTTON_GND_PIN, LOW);
#endif
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  if (STATUS_LED >= 0) pinMode(STATUS_LED, OUTPUT);
  writeLed(0);
  Serial.begin(BAUD);
  // 아무 글자도 보내지 않음 (페이지가 'SLEEP' 등 글자에 반응하므로)
}

void loop() {
  readSerialLines();
  readButton();
  updateLed();
}
